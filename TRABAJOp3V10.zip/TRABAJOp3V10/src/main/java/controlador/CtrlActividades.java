package controlador;

import modelo.*;
import vista.ventanaActividades;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CtrlActividades implements ActionListener{
    private ventanaActividades vista;
    private CtrlPagos v5;
    private CtrlVentanaGeneral vg;
    private CtrlActividadPersonalizada v6;
    private Actividades actividad;
    private RegistroActividad registroActividad;
    private DefaultTableModel model;
    private Pago pago;
    private CtrlNotificaciones v7;
    private CtrlActividadesReservadas v8;
    private UsuarioActividad usuarioActividad;

    private Map<Integer, Integer> actividadReservadaAMap;

    public CtrlActividades(){
        this.vista=new ventanaActividades();
        this.registroActividad= new RegistroActividad();
        this.actividad = new Actividades();
        this.pago = new Pago();
        this.usuarioActividad= new UsuarioActividad();
        actividad = Actividades.getInstancia();
        model = new DefaultTableModel();

        vista.btnPago.addActionListener(this);
        vista.btnAgregar.addActionListener(this);
        vista.regresarButton.addActionListener(this);
        vista.personalizarActividadButton.addActionListener(this);
        vista.comboBoxRol.addActionListener(this);
        vista.comboBoxClase.addActionListener(this);
        vista.comboBoxHinicio.addActionListener(this);
        vista.comboBoxHfin.addActionListener(this);
        vista.siRadioButton.addActionListener(this);
        vista.modificarButton.addActionListener(this);
        vista.eliminarButton.addActionListener(this);
        vista.notificarCambiosHorarioButton.addActionListener(this);
        vista.actividadesReservadasButton.addActionListener(this);
        vista.limpiarButton.addActionListener(this);
        //vista.noRadioButton.addActionListener(this);
        /*vista.lunesAViernesRadioButton.addActionListener(this);
        vista.sabadoYDomingoRadioButton.addActionListener(this);*/

        ButtonGroup group = new ButtonGroup();
        group.add(vista.siRadioButton);
        group.add(vista.noRadioButton);

        ButtonGroup group2 = new ButtonGroup();
        group2.add(vista.lunesAViernesRadioButton);
        group2.add(vista.sabadoYDomingoRadioButton);

        ButtonGroup group3 = new ButtonGroup();
        group3.add(vista.siResevadoButton);
        group3.add(vista.noRadioButton2);

        actividadReservadaAMap = new HashMap<>();
        inicializarComponentes();
        recuperarDatos();

        // Añadir el ListSelectionListener a la tabla
        vista.table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.table1.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocarDatosEnCampos(filaSeleccionada);
                        colocar(filaSeleccionada);
                    }
                }
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==vista.regresarButton){
            vg=new CtrlVentanaGeneral();
            vista.dispose();
        }

        if(e.getSource()==vista.btnAgregar){
            if(CamposCompletados() && CamposValidos()){
                ingresoActividad();
                agregar();
            }else {
                JOptionPane.showMessageDialog(null, "Campos imcompletos");
            }
        }

        if(e.getSource()==vista.personalizarActividadButton){
            v6=new CtrlActividadPersonalizada();
            vista.dispose();
        }

        if(e.getSource()==vista.comboBoxRol){
            String opc = (String) vista.comboBoxRol.getSelectedItem();
            Descripcion(opc);
        }

        if (e.getSource() == vista.btnPago) {
           // double costoTotal = calcularCostoTotalActividades();
            //v5 = new CtrlPagos(costoTotal,this);
           // vista.setVisible(false); // Oculta la ventana de actividades
            v5 = new CtrlPagos();
            vista.dispose(); // Cierra la ventana de actividades
        }


        if (e.getSource() == vista.modificarButton) {
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                Modificar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla" +
                        "\n Edite los campos"+
                        "\n y luego modifique ");
            }
        }

        if (e.getSource() == vista.eliminarButton) {
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                Eliminar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla lo que desea eliminar");
            }
        }
        if(e.getSource()==vista.notificarCambiosHorarioButton){
            v7 = new CtrlNotificaciones();
            vista.dispose();
//            int filaSeleccionada = vista.table1.getSelectedRow();
//            if (filaSeleccionada != -1) {
//
//            }else{
//                JOptionPane.showMessageDialog(null,"Seleccione una actividad para notificar");
//            }

        }

        if(e.getSource()==vista.actividadesReservadasButton){
            v8 = new CtrlActividadesReservadas(actividadReservadaAMap);
            vista.dispose();
        }
    }

    public void Descripcion(String opc){

        if("Body Balance".equals(opc)){
            vista.textDescripcion.setText("Fusión de yoga, tai chi y pilates que mejora la flexibilidad y la fuerza.");
            vista.textCodigo.setText("2606");
            vista.textCosto.setText("10");
        }

        if("Body Combat".equals(opc)){
            vista.textDescripcion.setText("Entrenamiento cardiovascular basado en artes marciales.");
            vista.textCodigo.setText("2607");
            vista.textCosto.setText("8");
        }
        if("Body Pump".equals(opc)){
            vista.textDescripcion.setText("Clase con pesas que trabaja todos los grupos musculares.");
            vista.textCodigo.setText("2608");
            vista.textCosto.setText("9");
        }
        if("Zumba".equals(opc)){
            vista.textDescripcion.setText("Entrenamiento aeróbico con ritmos latinos.");
            vista.textCodigo.setText("2609");
            vista.textCosto.setText("7");
        }
        if("HBX Boxing".equals(opc)){
            vista.textDescripcion.setText("Entrenamiento de alta intensidad basado en técnicas de boxeo.");
            vista.textCodigo.setText("2610");
            vista.textCosto.setText("12");
       }
       if("Ciclo Indoor (Spinning)".equals(opc)){
            vista.textDescripcion.setText("Ejercicio cardiovascular en bicicletas estacionarias con resistencia ajustable.");
            vista.textCodigo.setText("2611");
           vista.textCosto.setText("8");
        }
       if("Circuito al aire libre".equals(opc)){
            vista.textDescripcion.setText("Entrenamiento funcional variado realizado en espacios abiertos.");
            vista.textCodigo.setText("2612");
            vista.textCosto.setText("7");
       }
       if("Body Attack".equals(opc)){
            vista.textDescripcion.setText("Clase de alta intensidad que combina ejercicios aeróbicos y de fuerza.");
            vista.textCodigo.setText("2613");
            vista.textCosto.setText("11");
       }

    }

    public boolean CamposCompletados(){
        if(vista.comboBoxRol.getSelectedItem().toString().isEmpty()
                || vista.textCupo.getText().isEmpty()
                || vista.lunesAViernesRadioButton.toString().isEmpty()
                || vista.sabadoYDomingoRadioButton.toString().isEmpty()
                || vista.siRadioButton.toString().isEmpty()
                || vista.siResevadoButton.toString().isEmpty()
                || vista.noRadioButton.toString().isEmpty()
                || vista.noRadioButton2.toString().isEmpty()
                || vista.comboBoxEntrenador.getSelectedItem().toString().isEmpty()
        ){
            return false;
        }else{
            return true;
        }
    }

    public boolean CamposValidos() {
        if (!registroActividad.CupoCorrecto(vista.textCupo.getText())) {
            JOptionPane.showMessageDialog(null, "Incorrecto,desde 1 hasta 100 ");
            return false;
        }
       /* String inicio=(String) vista.comboBoxHinicio.getSelectedItem();
        String fin = (String) vista.comboBoxHfin.getSelectedItem();
        if( inicio.equals(fin) ) {
            JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
            return false;
        }*/
        if(vista.comboBoxHfin.getSelectedItem().equals(vista.comboBoxHinicio.getSelectedItem()) ){
            JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
            return false;
           /* String domingoinicio=(String) vista.domingoInicio.getSelectedItem();
            String domingofin = (String) vista.domingoFin.getSelectedItem();
            if( domingoinicio.equals(domingofin) ) {

            }*/
        }
        return true;
    }

    public void ingresoActividad(){
        String disponible="";
        String dias="";
        String reservar="";

        RegistroActividad registroActividad1 = new RegistroActividad();

        registroActividad1.setNombre((String) vista.comboBoxRol.getSelectedItem());
        registroActividad1.setDescripcion(vista.textDescripcion.getText());
        registroActividad1.setCodigo(vista.textCodigo.getText());
        registroActividad1.setCupo(vista.textCupo.getText());
        registroActividad1.setCosto(vista.textCosto.getText());

        if(vista.siRadioButton.isSelected()){
             disponible ="Si";
        }else {
             disponible ="No";
        }

        if(vista.lunesAViernesRadioButton.isSelected()){
            dias="Lunes a Viernes";
        }else{
            dias="Sabado y Domingo";
        }

        if(vista.siResevadoButton.isSelected()){
            reservar="Si";
        }else{
            reservar="No";
        }

        registroActividad1.setClase((String) vista.comboBoxClase.getSelectedItem());
        registroActividad1.setEntrenador((String) vista.comboBoxEntrenador.getSelectedItem());
        registroActividad1.setHinicio((String) vista.comboBoxHinicio.getSelectedItem());
        registroActividad1.setHfin((String) vista.comboBoxHfin.getSelectedItem());

        /*Integer.parseInt(vista.textCodigo.getText()), Integer.parseInt(vista.textCupo.getText())*/
        actividad.agregarActividad(
                (String) vista.comboBoxRol.getSelectedItem(),
                vista.textDescripcion.getText(),
                vista.textCodigo.getText(),
                vista.textCupo.getText(),
                reservar,
                vista.textCosto.getText(),
                disponible,dias,
                (String) vista.comboBoxClase.getSelectedItem(),
                (String) vista.comboBoxEntrenador.getSelectedItem(),
                (String) vista.comboBoxHinicio.getSelectedItem(),
                (String) vista.comboBoxHfin.getSelectedItem()
        );
        grabar();
    }

    private void inicializarComponentes(){
        model.setColumnCount(12);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre", "Descripcion", "Codigo","Cupo",
                                                "Reservado","Costo $","Disponible", "Dias",
                                                "Clase","Entrenador","Hora-Inicio","Hora-Fin"});
        vista.table1.setModel(model);
    }

    private void agregar(){
        String nombre = (String) vista.comboBoxRol.getSelectedItem();
        String descripcion = vista.textDescripcion.getText();
        String codigo = vista.textCodigo.getText();
        String cupo = vista.textCupo.getText();
        String costo = vista.textCosto.getText();

        String disponible="";
        String dias="";
        String reservar="";

        if(vista.siRadioButton.isSelected()){
            disponible ="Si";
        }else {
            disponible ="No";
        }

        if(vista.siResevadoButton.isSelected()){
            reservar ="Si";
        }else {
            reservar ="No";
        }
        if(vista.lunesAViernesRadioButton.isSelected()){
            dias="Lunes a Viernes";
        }else{
            dias="Sabado y Domingo";
        }
        String clase= (String) vista.comboBoxClase.getSelectedItem();
        String entrenador= (String) vista.comboBoxEntrenador.getSelectedItem();
        String hInicio = (String) vista.comboBoxHinicio.getSelectedItem();
        String hFin= (String) vista.comboBoxHfin.getSelectedItem();

        model.addRow(new Object[]{nombre,descripcion,codigo,cupo,reservar,costo,disponible,dias,clase,entrenador,hInicio,hFin});
    }

    public void grabar(){
        actividad.grabar("Actividades");
    }

    public void recuperarDatos(){
        try {
            Actividades actividades = actividad.recuperar("Actividades");
            llenarTabla(actividades);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }

    private void llenarTabla(Actividades actividades) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        int rowIndex = 0;
        int reservedIndex = 0;
        for (RegistroActividad registroActividad1: actividades.getActividades()) {
            model.addRow(new Object[]{ registroActividad1.getNombre(),registroActividad1.getDescripcion(),
                                    registroActividad1.getCodigo(), registroActividad1.getCupo(),registroActividad1.getReservar(),
                registroActividad1.getCosto(),  registroActividad1.getDisponible(),registroActividad1.getDias(),
                registroActividad1.getClase(),registroActividad1.getEntrenador(), registroActividad1.getHinicio(), registroActividad1.getHfin()});

            if ("Si".equals(registroActividad.getReservar())) {
                actividadReservadaAMap.put(reservedIndex, rowIndex);
                reservedIndex++;
            }
            rowIndex++;
        }

    }

    private void colocarDatosEnCampos(int filaSeleccionada) {
        String nombreActividad = (String) vista.table1.getValueAt(filaSeleccionada, 0);
        String descripcion = (String) vista.table1.getValueAt(filaSeleccionada, 1);
        String codigo = (String) vista.table1.getValueAt(filaSeleccionada, 2);
        String cupo = (String) vista.table1.getValueAt(filaSeleccionada, 3);
        String reserva = (String) vista.table1.getValueAt(filaSeleccionada, 4);
        String costo = (String) vista.table1.getValueAt(filaSeleccionada, 5);
        String disponible = (String) vista.table1.getValueAt(filaSeleccionada, 6);
        String dias = (String) vista.table1.getValueAt(filaSeleccionada, 7);
        String clase = (String) vista.table1.getValueAt(filaSeleccionada, 8);
        String entrenador = (String) vista.table1.getValueAt(filaSeleccionada, 9);
        String hInicio = (String) vista.table1.getValueAt(filaSeleccionada, 10);
        String hFin = (String) vista.table1.getValueAt(filaSeleccionada, 11);

        vista.comboBoxRol.setSelectedItem(nombreActividad);
        vista.textDescripcion.setText(descripcion);
        vista.textCodigo.setText(codigo);
        vista.textCupo.setText(cupo);

        if ("Si".equals(reserva)) {
            vista.siResevadoButton.setSelected(true);
        } else {
            vista.noRadioButton2.setSelected(true);
        }

        vista.textCosto.setText(costo);

        if ("Si".equals(disponible)) {
            vista.siRadioButton.setSelected(true);
        } else {
            vista.noRadioButton.setSelected(true);
        }

        if ("Lunes a Viernes".equals(dias)) {
            vista.lunesAViernesRadioButton.setSelected(true);
        }else{
            vista.sabadoYDomingoRadioButton.setSelected(true);
        }
        vista.comboBoxClase.setSelectedItem(clase);
        vista.comboBoxEntrenador.setSelectedItem(entrenador);
        vista.comboBoxHinicio.setSelectedItem(hInicio);
        vista.comboBoxHfin.setSelectedItem(hFin);
    }

    public void colocar(int pos) {
        if(pos >= 0 && pos < Actividades.getInstancia().getActividades().size()) {
            RegistroActividad registroActividad1 = Actividades.getInstancia().getActividades().get(pos);
            //System.out.println("Persona encontrada: " + persona.getNombre()); // Depuración adicional
            vista.textArea1.setText("\n \tInformacion " +
                    "\n Nombre: "+registroActividad1.getNombre()+
                    "\n Descripcion: "+registroActividad1.getDescripcion()+
                    "\n Codigo: "+registroActividad1.getCodigo()+
                    "\n Cupo: "+registroActividad1.getCupo()+
                    "\n Reservado: "+registroActividad1.getReservar()+
                    "\n Costo: "+registroActividad1.getCosto()+
                    "\n Disponible: "+ registroActividad1.getDisponible()+
                    "\n Dias: "+ registroActividad1.getDias()+
                    "\n Clase: "+ registroActividad1.getClase()+
                    "\n Entrador : "+ registroActividad1.getEntrenador()+
                    "\n Hora incio: "+ registroActividad1.getHinicio()+
                    "\n Hora fin: "+ registroActividad1.getHfin()
            );

        } else {
            JOptionPane.showMessageDialog(null, "No hay informacion");
        }
    }

    private void Modificar(int filaSeleccionada) {
        if (CamposCompletados() && CamposValidos()) {
            String nombre = (String) vista.comboBoxRol.getSelectedItem();
            String descripcion = vista.textDescripcion.getText();
            String codigo = vista.textCodigo.getText();
            String cupo = vista.textCupo.getText();
            String reserva = vista.siResevadoButton.isSelected() ? "Si" : "No";
            String costo = vista.textCosto.getText();
            String disponible = vista.siRadioButton.isSelected() ? "Si" : "No";
            String dias = vista.lunesAViernesRadioButton.isSelected() ? "Lunes a Viernes" : "Sabado y Domingo";
            String clase = (String) vista.comboBoxClase.getSelectedItem();
            String entrenador = (String) vista.comboBoxEntrenador.getSelectedItem();
            String hInicio = (String) vista.comboBoxHinicio.getSelectedItem();
            String hFin = (String) vista.comboBoxHfin.getSelectedItem();

            model.setValueAt(nombre, filaSeleccionada, 0);
            model.setValueAt(descripcion, filaSeleccionada, 1);
            model.setValueAt(codigo, filaSeleccionada, 2);
            model.setValueAt(cupo, filaSeleccionada, 3);
            model.setValueAt(reserva, filaSeleccionada, 4);
            model.setValueAt(costo, filaSeleccionada, 5);
            model.setValueAt(disponible, filaSeleccionada, 6);
            model.setValueAt(dias, filaSeleccionada, 7);
            model.setValueAt(clase, filaSeleccionada, 8);
            model.setValueAt(entrenador, filaSeleccionada, 9);
            model.setValueAt(hInicio, filaSeleccionada, 10);
            model.setValueAt(hFin, filaSeleccionada, 11);

            actividad.modificarActividad( filaSeleccionada, nombre, descripcion,codigo,cupo,
                    reserva, costo, disponible, dias,
                    clase,entrenador, hInicio, hFin);
            grabar();
        }
    }

    private void Eliminar(int filaSeleccionada) {
        int response = JOptionPane.showConfirmDialog(null, "¿Desea eliminar esta actividad?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            actividad.eliminarActividad(filaSeleccionada);
            model.removeRow(filaSeleccionada);
            grabar();
        }
    }
}
