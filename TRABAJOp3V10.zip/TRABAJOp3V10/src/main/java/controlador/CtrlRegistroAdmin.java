package controlador;

import modelo.Administradores;
import modelo.RegistroAdministrador;
import vista.ventanaRegistroAdministrador;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

import static javax.swing.JOptionPane.showMessageDialog;

public class CtrlRegistroAdmin implements ActionListener {
    private ventanaRegistroAdministrador vista;
    private RegistroAdministrador admin;
    private Administradores nuevoAdminstrador;
    private CtrlAdministrador v1;
    public CtrlRegistroAdmin(){
        this.vista=new ventanaRegistroAdministrador();
        this.admin=new RegistroAdministrador();
        this.nuevoAdminstrador=new Administradores();
        vista.cancelButton.addActionListener(this);
        vista.regresarButton.addActionListener(this);
        vista.guardarButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.regresarButton){
            v1=new CtrlAdministrador();
            vista.dispose();
        }

        if(e.getSource()==vista.guardarButton){
            if(CamposCompletados()&& CamposValidos()){
                ingresoAdmin();
            }else{
                JOptionPane.showMessageDialog(null,"Campos imcompletos");
            }
        }
        if(e.getSource()==vista.cancelButton){
            borrar();
        }
    }
    
    public boolean CamposCompletados(){
        if(vista.textNombre.getText().isEmpty()
        || vista.textCedula.getText().isEmpty()
        || vista.textCorreo.getText().isEmpty()
        || vista.textDireccion.getText().isEmpty()
        || vista.passwordAdmin.toString().isEmpty()){
            //JOptionPane.showMessageDialog(null,"Campos imcompletos");
            return false;
        }else{
            return true;
        }
    }

    public void ingresoAdmin(){
        RegistroAdministrador nuevaRegistro= new RegistroAdministrador();
        nuevaRegistro.setNombre(vista.textNombre.getText());
        nuevaRegistro.setCedula(vista.textCedula.getText());
        nuevaRegistro.setDireccion(vista.textDireccion.getText());
        nuevaRegistro.setCorreo(vista.textCorreo.getText());
        nuevaRegistro.setContrasenia(new String(vista.passwordAdmin.getPassword()));
        //nuevaRegistro.setContrasenia(vista.passwordAdmin.toString());
       // nuevoAdminstrador.agregarAdmin(nuevaRegistro);
        nuevoAdminstrador.agregarAdmin2(vista.textNombre.getText(),vista.textCedula.getText(),
                vista.textDireccion.getText(),vista.textCorreo.getText(),new String(vista.passwordAdmin.getPassword()));
        // Guardar en archivo
        try (FileWriter writer = new FileWriter("Administradores", true)) {
            writer.write(vista.textNombre.getText() + "," + vista.textCedula.getText() + "," +
                    vista.textCorreo.getText() + "," + new String(vista.passwordAdmin.getPassword()) + "\n");
            JOptionPane.showMessageDialog(null, "Usuario registrado correctamente");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar el usuario");
            e.printStackTrace();
        }
    }

    public void borrar(){
        vista.textNombre.setText("");
        vista.textCedula.setText("");
        vista.textCorreo.setText("");
        vista.textDireccion.setText("");
        vista.passwordAdmin.setText("");
    }

    public boolean CamposValidos(){
        if(!admin.NombreCorrecto(vista.textNombre.getText())){
            JOptionPane.showMessageDialog(null,"Incorrecto \n Ingrese Nombre y Apellido ");
            return false;
        }
        if(!admin.CedulaCorrecta(vista.textCedula.getText())){
            JOptionPane.showMessageDialog(null,"Cedula Incorrecta");
            return false;
        }
        if(!admin.CorreoCorrecto(vista.textCorreo.getText())){
            JOptionPane.showMessageDialog(null,"Correo Incorrecto");
            return false;
        }
        if(!admin.DireccionCorrecta(vista.textDireccion.getText())){
            JOptionPane.showMessageDialog(null,"Password minimo 4 caracteres");
            return false;
        }
        if(!admin.ContraseniaCorrecta(new String(vista.passwordAdmin.getPassword()))){
            JOptionPane.showMessageDialog(null,"Password minimo 4 caracteres");
            return false;
        }
        return true;
    }
}
