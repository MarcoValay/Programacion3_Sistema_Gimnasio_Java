package controlador;

import modelo.*;
import vista.ventanaAccederAlGym;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CtrlAccederAlGym implements ActionListener {

    private DefaultTableModel model;
    private DefaultTableModel model2;
    private ventanaAccederAlGym vista;
    private Duenio duenio;
    private SociosGYM sociosGYM;
    private GestionAsignarGimnasios gestionGimnasios;
    private Gimnasio gimnasio;
    private List<Asignacion> asignaciones;
    private CtrlVentanaGeneral v1;

    public CtrlAccederAlGym(){
        model = new DefaultTableModel();
        model2 = new DefaultTableModel();

        duenio=Duenio.getInstancia();
        sociosGYM=SociosGYM.getInstancia();
        this.asignaciones = new ArrayList<>();
        this.gestionGimnasios= new GestionAsignarGimnasios();
        this.vista = new ventanaAccederAlGym();
        this.gimnasio =  new Gimnasio();
        vista.regresarButton.addActionListener(this);
        vista.asignarSocioButton.addActionListener(this);
        vista.cancelarButton.addActionListener(this);
        //vista.programacioDeActividadesButton.addActionListener(this);
        inicializarComponentes();
        cargar();
        cargarAsignaciones();

        vista.tablaGYM.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.tablaGYM.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        // vista.btnActiv.setEnabled(true);
                       // colocarDatosEnCampos(filaSeleccionada);
                        vista.asignarSocioButton.setEnabled(true);
                    }
                }
            }
        });

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.regresarButton){
            v1 = new CtrlVentanaGeneral();
            vista.dispose();
        }
        if (e.getSource() == vista.asignarSocioButton) {
            asignarSocio();
        }
    }

    private void inicializarComponentes(){
        model.setColumnCount(10);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre","Direccion","Telefono","Ubicacion","Codigo","Fecha-Inicio","Fecha-Fin","Hora-inicio","Hora-Fin","Ruc"});
        vista.tablaGYM.setModel(model);
    }

    public void cargar(){
        try {
            Duenio duenio1 = duenio.recuperar("GYMs");
            llenarTabla(duenio1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }

    private void llenarTabla(Duenio duenio) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Gimnasio gimnasio1: duenio.getGimnasios()) {
            model.addRow(new Object[]{gimnasio1.getNombre(),gimnasio1.getDireccion(), gimnasio1.getTelefono(),
                    gimnasio1.getNombreCalles(),gimnasio1.getCodigo(),
                    gimnasio1.getFechaInicio(),gimnasio1.getFechaFin(),
                    gimnasio1.getHoraInicio(),gimnasio1.getHoraFin(), gimnasio1.getRuc()});
        }
    }

    private void cargarAsignaciones() {
        asignaciones = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("asignaciones.txt"))) {
            String linea;
            Asignacion asignacion = null;
            while ((linea = br.readLine()) != null) {
                if (linea.startsWith("Socio:")) {
                    if (asignacion != null) {
                        asignaciones.add(asignacion);
                    }
                    asignacion = new Asignacion();
                    String[] partes = linea.split(", ");
                    asignacion.socio = partes[0].split(": ")[1];
                    asignacion.cedula = partes[1].split(": ")[1];
                } else if (linea.startsWith("Gimnasio:")) {
                    String[] partes = linea.split(", ");
                    asignacion.gimnasio = partes[0].split(": ")[1];
                }
            }
            if (asignacion != null) {
                asignaciones.add(asignacion);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void asignarSocio() {
        String cedula = JOptionPane.showInputDialog("Ingrese la cédula del socio:");
        if (cedula != null && !cedula.isEmpty()) {
            boolean asignado = false;
            for (Asignacion asignacion : asignaciones) {
                if (asignacion.cedula.equals(cedula)) {
                    asignado = true;
                    asignacion.asistencias++;
                    vista.textField1.setText(" "+asignacion.asistencias);
                    JOptionPane.showMessageDialog(vista, "Asignación exitosa. Asistencias: " + asignacion.asistencias);
                    guardarAsignaciones();
                    break;
                }
            }
            if (!asignado) {
                JOptionPane.showMessageDialog(vista, "Socio no asignado a ningún gimnasio.");
            }
        }
    }

    private void guardarAsignaciones() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("asistencias.txt"))) {
            for (Asignacion asignacion : asignaciones) {
                bw.write("Socio: " + asignacion.socio + ", Cedula: " + asignacion.cedula + "\n");
                bw.write("Gimnasio: " + asignacion.gimnasio + "\n");
                bw.write("Asistencias: " + asignacion.asistencias + "\n");
                // Aquí se pueden agregar más datos si es necesario
                bw.write("\n"); // Separador entre asignaciones
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class Asignacion {
        String socio;
        String cedula;
        String gimnasio;
        int asistencias = 0;
    }

}
