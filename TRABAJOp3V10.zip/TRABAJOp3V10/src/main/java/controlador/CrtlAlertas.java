package controlador;

import modelo.Correo;
import vista.ventanaAlertas;
import vista.ventanaNotificaciones;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CrtlAlertas implements ActionListener {
    private ventanaAlertas vista;
    private CtrlPagos v1;

    public CrtlAlertas() {
        this.vista = new ventanaAlertas();
        vista.regresarButton.addActionListener(this);
        vista.adjuntarButton.addActionListener(this);
        vista.cancelarButton.addActionListener(this);
        vista.configurarButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser archi = new JFileChooser("./");
        archi.setFileSelectionMode(JFileChooser.FILES_ONLY);

        if (e.getSource() == vista.regresarButton) {
            v1 = new CtrlPagos();
            vista.dispose();
        }
        if (e.getSource() == vista.configurarButton) {
            Correo correo = new Correo(vista.textDestinoCorreo.getText(),
                    vista.textAsuntoCorreo.getText(),
                    vista.textMensajeCorreo.getText()
            );
            if (!vista.ruta.getText().isEmpty()) {
                correo.setArchivoAdjunto(vista.ruta.getText());
            }
            Date selectedDate = vista.fecha.getDate();
            if(CamposCompletados()){
                if (selectedDate != null) {
                    SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
                    try {
                        // Aquí puedes formatear la fecha si es necesario
                        String fechaEnvioStr = formatoFecha.format(selectedDate);
                        Date fechaEnvio = formatoFecha.parse(fechaEnvioStr);
                        JOptionPane.showMessageDialog(null, "Alerta programada.");
                        correo.programarEnvio(fechaEnvio);
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fecha válida.");
                }
            }
        }
        if (e.getSource() == vista.cancelarButton) {
            limpiarSeccionCorreo();
        }
        if (e.getSource() == vista.adjuntarButton) {  // Evento para el segundo botón
            int returnVal = archi.showDialog(vista, "Recuperar");
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                try {
                    String recuperado = recuperar(archi.getSelectedFile().getAbsoluteFile().getPath());
                    vista.ruta.setText(recuperado);  // TextField adicional para el segundo archivo
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                JOptionPane.showMessageDialog(null, "Archivo  seleccionado");
            }
        }
    }
    private boolean CamposCompletados() {
        if (vista.textDestinoCorreo.getText().isEmpty()
                || vista.textAsuntoCorreo.getText().isEmpty()
                || vista.textMensajeCorreo.getText().isEmpty()
        ) {
            JOptionPane.showMessageDialog(null, "Destinario, asunto y mensaje son obligarotios.");
            return false;
        }
        return true;
    }
    public void limpiarSeccionCorreo() {
        vista.textDestinoCorreo.setText("");
        vista.textAsuntoCorreo.setText("");
        vista.textMensajeCorreo.setText("");
        vista.ruta.setText("");
        vista.fecha.setDate(null);
    }

    public String recuperar(String nombreArchivo) throws IOException {
        try {
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if (path.exists()) {
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                archivo.readObject();
                archivo.close();
            }
        } catch (ClassNotFoundException | IOException e) {
            System.out.println(e.getMessage());
        }
        System.out.println(nombreArchivo);
        return nombreArchivo;

    }
}
