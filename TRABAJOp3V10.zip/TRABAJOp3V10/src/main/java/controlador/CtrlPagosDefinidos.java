package controlador;

import vista.ventanaActividades;
import vista.ventanaPagosDefinidos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlPagosDefinidos implements ActionListener {
   private ventanaPagosDefinidos vista;
   private CtrlVentanaGeneral v1;
    public CtrlPagosDefinidos(){
        this.vista=new ventanaPagosDefinidos();
        vista.comboBox1Actividad.addActionListener(this);
        vista.comboBox2TipoPago.addActionListener(this);
        vista.regresarButton.addActionListener(this);
        //vista.personalizarActividadButton.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.regresarButton){
            v1=new CtrlVentanaGeneral();
            vista.dispose();
        }
    }
}
