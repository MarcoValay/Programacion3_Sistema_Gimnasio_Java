package controlador;

import modelo.Actividades;
import modelo.RegistroActividad;
import vista.ventanaActividadPersonalizada;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class CtrlActividadPersonalizada implements ActionListener {

    private ventanaActividadPersonalizada vista;
    private CtrlActividades v2;
    private DefaultTableModel model;
    private Actividades actividad;
    private RegistroActividad registroActividad;


    public CtrlActividadPersonalizada() {
        this.vista = new ventanaActividadPersonalizada();
        this.registroActividad = new RegistroActividad();

        actividad = Actividades.getInstancia();
        model = new DefaultTableModel();

        vista.crearButton.addActionListener(this);
        vista.regresarButton.addActionListener(this);
        vista.LimpiarButton.addActionListener(this);
        vista.modificarButton.addActionListener(this);
        vista.eliminarButton.addActionListener(this);

        vista.siRadioButton.addActionListener(this);
        vista.siRadioButton2.addActionListener(this);
        vista.noRadioButton.addActionListener(this);
        vista.noRadioButton2.addActionListener(this);

       // vista.comboBoxEntrenador.addActionListener(this);

        vista.lunesCheckBox.addActionListener(this);
        vista.martesCheckBox.addActionListener(this);
        vista.miercolesCheckBox.addActionListener(this);
        vista.juevesCheckBox.addActionListener(this);
        vista.viernesCheckBox.addActionListener(this);
        vista.sabadoCheckBox.addActionListener(this);
        vista.domingoCheckBox.addActionListener(this);

        vista.lunesInicio.addActionListener(this);
        vista.martesInicio.addActionListener(this);
        vista.miercolesInicio.addActionListener(this);
        vista.juevesInicio.addActionListener(this);
        vista.viernesInicio.addActionListener(this);
        vista.sabadoInicio.addActionListener(this);
        vista.domingoInicio.addActionListener(this);

        vista.lunesFin.addActionListener(this);
        vista.martesFin.addActionListener(this);
        vista.miercolesFin.addActionListener(this);
        vista.juevesFin.addActionListener(this);
        vista.viernesFin.addActionListener(this);
        vista.sabadoFin.addActionListener(this);
        vista.domingoFin.addActionListener(this);

        ButtonGroup group = new ButtonGroup();
        group.add(vista.siRadioButton);
        group.add(vista.noRadioButton);

        ButtonGroup group2 = new ButtonGroup();
        group2.add(vista.siRadioButton2);
        group2.add(vista.noRadioButton2);

        inicializarComponentes();
        recuperarDatos();

        vista.table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.table1.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocarDatosEnCampos(filaSeleccionada);
                    }
                }
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.regresarButton) {
            CtrlActividades v2 = new CtrlActividades();
            vista.dispose();
        }

        if (e.getSource() == vista.crearButton) {
            if (CamposCompletados() && CamposValidos()) {
                agregar();
            }
        }

        if(e.getSource()==vista.LimpiarButton){
            limpiar();
        }

        if (e.getSource() == vista.modificarButton) {
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                Modificar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla" +
                        "\n Edite los campos"+
                        "\n y luego modifique ");
            }
        }

        if (e.getSource() == vista.eliminarButton) {
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                Eliminar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla lo que desea eliminar");
            }
        }
    }

    public void limpiar(){
        vista.textNombre.setText("");
        vista.textDescripcion.setText("");
        vista.textCodigo.setText("");
        vista.textCupo.setText("");
        vista.textCosto.setText("");

        vista.siRadioButton.setSelected(false);
        vista.noRadioButton.setSelected(false);
        vista.siRadioButton2.setSelected(false);
        vista.noRadioButton2.setSelected(false);
        vista.lunesCheckBox.setSelected(false);
        vista.martesCheckBox.setSelected(false);
        vista.miercolesCheckBox.setSelected(false);
        vista.juevesCheckBox.setSelected(false);
        vista.viernesCheckBox.setSelected(false);
        vista.sabadoCheckBox.setSelected(false);
        vista.domingoCheckBox.setSelected(false);
    }


    private void inicializarComponentes() {
        model.setColumnCount(12);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre", "Descripcion", "Codigo", "Cupo",
                "Reservado","Costo", "Disponible","Dias",
                "Clase","Entrenador", "Hora-Inicio", "Hora-Fin"});
        vista.table1.setModel(model);
    }

    private void agregar() {
        String nombre = vista.textNombre.getText();
        String descripcion = vista.textDescripcion.getText();
        //int codigo = Integer.parseInt(vista.textCodigo.getText());
        String codigo = vista.textCodigo.getText();
        //int cupo = Integer.parseInt(vista.textCupo.getText());
        String cupo = vista.textCupo.getText();
        String costo = vista.textCosto.getText();

        String disponible = "";
        if (vista.siRadioButton.isSelected()) {
            disponible = "Si";
        } else {
            disponible = "No";
        }

        String reservado = "";
        if (vista.siRadioButton2.isSelected()) {
            reservado = "Si";
        } else {
            reservado = "No";
        }

        String dias = obtenerDiasSeleccionados();
        String clase= (String) vista.comboBox1.getSelectedItem();
        String entrnador =  (String) vista.comboBoxEntrenador.getSelectedItem();
        String hInicio = obtenerHorasInicio();
        String hFin = obtenerHorasFin();

        actividad.agregarActividad(nombre, descripcion, codigo, cupo,
                reservado,costo, disponible, dias
                ,clase,entrnador, hInicio, hFin);
        grabar();
        model.addRow(new Object[]{nombre, descripcion, codigo, cupo,
                reservado, costo, disponible, String.join(", ", dias),
                clase,entrnador, String.join(", ", hInicio), String.join(", ", hFin)});
    }

    public void grabar(){
        actividad.grabar("Actividades");
    }

    public void recuperarDatos(){
        try {
            Actividades actividades = actividad.recuperar("Actividades");
            llenarTabla(actividades);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }

    private void llenarTabla(Actividades actividades) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (RegistroActividad registroActividad1: actividades.getActividades()) {
            model.addRow(new Object[]{ registroActividad1.getNombre(),registroActividad1.getDescripcion(),
                    registroActividad1.getCodigo(), registroActividad1.getCupo(),registroActividad1.getReservar(),
                    registroActividad1.getCosto(),  registroActividad1.getDisponible(),registroActividad1.getDias(),
                    registroActividad1.getClase(),registroActividad1.getEntrenador(), registroActividad1.getHinicio(), registroActividad1.getHfin()});
        }
    }

    private void colocarDatosEnCampos(int filaSeleccionada) {
        Object nombre = vista.table1.getValueAt(filaSeleccionada, 0);
        Object descripcion = vista.table1.getValueAt(filaSeleccionada, 1);
        Object codigo = vista.table1.getValueAt(filaSeleccionada, 2);
        Object cupo = vista.table1.getValueAt(filaSeleccionada, 3);
        Object resevado = vista.table1.getValueAt(filaSeleccionada, 4);
        Object costo = vista.table1.getValueAt(filaSeleccionada, 5);
        Object disponible = vista.table1.getValueAt(filaSeleccionada, 6);
        Object dias = vista.table1.getValueAt(filaSeleccionada, 7);
        Object clase = vista.table1.getValueAt(filaSeleccionada, 8);

        Object entrenador = vista.table1.getValueAt(filaSeleccionada, 9);

        Object hinicio = vista.table1.getValueAt(filaSeleccionada, 10);
        Object hfin = vista.table1.getValueAt(filaSeleccionada, 11);

        vista.textNombre.setText(nombre != null ? nombre.toString() : "");
        vista.textDescripcion.setText(descripcion != null ? descripcion.toString() : "");
        vista.textCodigo.setText(codigo != null ? codigo.toString() : "");
        vista.textCupo.setText(cupo != null ? cupo.toString() : "");
        vista.textCosto.setText(costo != null ? costo.toString() : "");

        if ("Si".equals(disponible)) {
            vista.siRadioButton.setSelected(true);
        } else {
            vista.noRadioButton.setSelected(true);
        }

        if ("Si".equals(resevado)) {
            vista.siRadioButton2.setSelected(true);
        } else {
            vista.noRadioButton2.setSelected(true);
        }

        vista.comboBox1.setSelectedItem(clase != null ? clase.toString() : "");
        vista.comboBoxEntrenador.setSelectedItem(entrenador != null ? entrenador.toString() : "");

        if (dias != null) {
            setCheckBoxes(dias.toString().split(", "));
        }

        if (hinicio != null) {
            setHorasInicio(hinicio.toString().split(", "));
        }

        if (hfin != null) {
            setHorasFin(hfin.toString().split(", "));
        }
    }

    private boolean CamposCompletados() {
        if (vista.textNombre.getText().isEmpty()
                || vista.textDescripcion.getText().isEmpty()
                || vista.textCodigo.getText().isEmpty()
                || vista.textCosto.getText().isEmpty()
                || vista.textCupo.getText().isEmpty()
                || vista.siRadioButton.toString().isEmpty()
                || vista.siRadioButton2.toString().isEmpty()
                || vista.noRadioButton.toString().isEmpty()
                || vista.noRadioButton2.toString().isEmpty()
        ) {
            JOptionPane.showMessageDialog(null, "Por favor complete todos los campos.");
            return false;
        }
        return true;
    }

    public boolean CamposValidos() {
        if (!registroActividad.CupoCorrecto(vista.textCupo.getText())) {
            JOptionPane.showMessageDialog(null, "Incorrecto,desde 1 hasta 100 ");
            return false;
        }
        if(vista.lunesCheckBox.isSelected()){
            String lunesinicio=(String) vista.lunesInicio.getSelectedItem();
            String lunesfin = (String) vista.lunesFin.getSelectedItem();
            if( lunesinicio.equals(lunesfin) ) {
                JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
                return false;
            }
        }
        if(vista.martesCheckBox.isSelected()){
            String martesinicio=(String) vista.miercolesInicio.getSelectedItem();
            String martesfin = (String) vista.martesFin.getSelectedItem();
            if( martesinicio.equals(martesfin) ) {
                JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
                return false;
            }
        }
        if(vista.miercolesCheckBox.isSelected()){
            String miercolesinicio=(String) vista.miercolesInicio.getSelectedItem();
            String miercolesfin = (String) vista.miercolesFin.getSelectedItem();
            if( miercolesinicio.equals(miercolesfin) ) {
                JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
                return false;
            }
        }
        if(vista.juevesCheckBox.isSelected()){
            String juevesinicio=(String) vista.juevesInicio.getSelectedItem();
            String juevesfin = (String) vista.juevesFin.getSelectedItem();
            if( juevesinicio.equals(juevesfin) ) {
                JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
                return false;
            }
        }
        if(vista.viernesCheckBox.isSelected()){
            String viernesinicio=(String) vista.viernesInicio.getSelectedItem();
            String viernesfin = (String) vista.viernesFin.getSelectedItem();
            if( viernesinicio.equals(viernesfin) ) {
                JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
                return false;
            }
        }
        if(vista.sabadoCheckBox.isSelected()){
            String sabadoinicio=(String) vista.sabadoInicio.getSelectedItem();
            String sabadofin = (String) vista.sabadoInicio.getSelectedItem();
            if( sabadoinicio.equals(sabadofin) ) {
                JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
                return false;
            }
        }
        if(vista.domingoCheckBox.isSelected()){
            String domingoinicio=(String) vista.domingoInicio.getSelectedItem();
            String domingofin = (String) vista.domingoFin.getSelectedItem();
            if( domingoinicio.equals(domingofin) ) {
                JOptionPane.showMessageDialog(null, "La Hora inicio y fin no pueden ser iguales ");
                return false;
            }
        }

        return true;
    }

    private String obtenerDiasSeleccionados() {
        StringBuilder dias = new StringBuilder();
        if (vista.lunesCheckBox.isSelected()) dias.append("Lunes, ");
        if (vista.martesCheckBox.isSelected()) dias.append("Martes, ");
        if (vista.miercolesCheckBox.isSelected()) dias.append("Miércoles, ");
        if (vista.juevesCheckBox.isSelected()) dias.append("Jueves, ");
        if (vista.viernesCheckBox.isSelected()) dias.append("Viernes, ");
        if (vista.sabadoCheckBox.isSelected()) dias.append("Sábado, ");
        if (vista.domingoCheckBox.isSelected()) dias.append("Domingo, ");
        //return dias.toString().isEmpty() ? "" : dias.substring(0, dias.length() - 2);
        return dias.length() > 0 ? dias.substring(0, dias.length() - 2) : "";
    }

    private String obtenerHorasInicio() {
        StringBuilder horasInicio = new StringBuilder();
        if (vista.lunesCheckBox.isSelected()) horasInicio.append(vista.lunesInicio.getSelectedItem()).append(", ");
        if (vista.martesCheckBox.isSelected()) horasInicio.append(vista.martesInicio.getSelectedItem()).append(", ");
        if (vista.miercolesCheckBox.isSelected()) horasInicio.append(vista.miercolesInicio.getSelectedItem()).append(", ");
        if (vista.juevesCheckBox.isSelected()) horasInicio.append(vista.juevesInicio.getSelectedItem()).append(", ");
        if (vista.viernesCheckBox.isSelected()) horasInicio.append(vista.viernesInicio.getSelectedItem()).append(", ");
        if (vista.sabadoCheckBox.isSelected()) horasInicio.append(vista.sabadoInicio.getSelectedItem()).append(", ");
        if (vista.domingoCheckBox.isSelected()) horasInicio.append(vista.domingoInicio.getSelectedItem()).append(", ");
        return horasInicio.length() > 0 ? horasInicio.substring(0, horasInicio.length() - 2) : "";
    }

    private String obtenerHorasFin() {
        StringBuilder horasFin = new StringBuilder();
        if (vista.lunesCheckBox.isSelected()) horasFin.append(vista.lunesFin.getSelectedItem()).append(", ");
        if (vista.martesCheckBox.isSelected()) horasFin.append(vista.martesFin.getSelectedItem()).append(", ");
        if (vista.miercolesCheckBox.isSelected()) horasFin.append(vista.miercolesFin.getSelectedItem()).append(", ");
        if (vista.juevesCheckBox.isSelected()) horasFin.append(vista.juevesFin.getSelectedItem()).append(", ");
        if (vista.viernesCheckBox.isSelected()) horasFin.append(vista.viernesFin.getSelectedItem()).append(", ");
        if (vista.sabadoCheckBox.isSelected()) horasFin.append(vista.sabadoFin.getSelectedItem()).append(", ");
        if (vista.domingoCheckBox.isSelected()) horasFin.append(vista.domingoFin.getSelectedItem()).append(", ");
        return horasFin.length() > 0 ? horasFin.substring(0, horasFin.length() - 2) : "";
    }
    private void setCheckBoxes(String[] dias) {
        vista.lunesCheckBox.setSelected(false);
        vista.martesCheckBox.setSelected(false);
        vista.miercolesCheckBox.setSelected(false);
        vista.juevesCheckBox.setSelected(false);
        vista.viernesCheckBox.setSelected(false);
        vista.sabadoCheckBox.setSelected(false);
        vista.domingoCheckBox.setSelected(false);
        for (String dia : dias) {
            switch (dia.trim()) {
                case "Lunes":
                    vista.lunesCheckBox.setSelected(true);
                    break;
                case "Martes":
                    vista.martesCheckBox.setSelected(true);
                    break;
                case "Miércoles":
                    vista.miercolesCheckBox.setSelected(true);
                    break;
                case "Jueves":
                    vista.juevesCheckBox.setSelected(true);
                    break;
                case "Viernes":
                    vista.viernesCheckBox.setSelected(true);
                    break;
                case "Sábado":
                    vista.sabadoCheckBox.setSelected(true);
                    break;
                case "Domingo":
                    vista.domingoCheckBox.setSelected(true);
                    break;
            }
        }
    }
    private void setHorasInicio(String[] horasInicio) {
        int index = 0;
        if (vista.lunesCheckBox.isSelected()) vista.lunesInicio.setSelectedItem(horasInicio[index++]);
        if (vista.martesCheckBox.isSelected()) vista.martesInicio.setSelectedItem(horasInicio[index++]);
        if (vista.miercolesCheckBox.isSelected()) vista.miercolesInicio.setSelectedItem(horasInicio[index++]);
        if (vista.juevesCheckBox.isSelected()) vista.juevesInicio.setSelectedItem(horasInicio[index++]);
        if (vista.viernesCheckBox.isSelected()) vista.viernesInicio.setSelectedItem(horasInicio[index++]);
        if (vista.sabadoCheckBox.isSelected()) vista.sabadoInicio.setSelectedItem(horasInicio[index++]);
        if (vista.domingoCheckBox.isSelected()) vista.domingoInicio.setSelectedItem(horasInicio[index++]);
    }

    private void setHorasFin(String[] horasFin) {
        int index = 0;
        if (vista.lunesCheckBox.isSelected()) vista.lunesFin.setSelectedItem(horasFin[index++]);
        if (vista.martesCheckBox.isSelected()) vista.martesFin.setSelectedItem(horasFin[index++]);
        if (vista.miercolesCheckBox.isSelected()) vista.miercolesFin.setSelectedItem(horasFin[index++]);
        if (vista.juevesCheckBox.isSelected()) vista.juevesFin.setSelectedItem(horasFin[index++]);
        if (vista.viernesCheckBox.isSelected()) vista.viernesFin.setSelectedItem(horasFin[index++]);
        if (vista.sabadoCheckBox.isSelected()) vista.sabadoFin.setSelectedItem(horasFin[index++]);
        if (vista.domingoCheckBox.isSelected()) vista.domingoFin.setSelectedItem(horasFin[index++]);
    }

    private void Modificar(int filaSeleccionada) {
        if (CamposCompletados() && CamposValidos()) {
            String nombre = vista.textNombre.getText();
            String descripcion = vista.textDescripcion.getText();
            //int codigo = Integer.parseInt(vista.textCodigo.getText());
            String codigo = vista.textCodigo.getText();
            //int cupo = Integer.parseInt(vista.textCupo.getText());
            String cupo = vista.textCupo.getText();
            String reservadp = vista.siRadioButton2.isSelected() ? "Si" : "No";
            String costo = vista.textCosto.getText();
            String disponible = vista.siRadioButton.isSelected() ? "Si" : "No";
            String dias = obtenerDiasSeleccionados();
            String clase = (String) vista.comboBox1.getSelectedItem();
            String entrenador = (String) vista.comboBoxEntrenador.getSelectedItem();
            String hinicio = obtenerHorasInicio();
            String hfin = obtenerHorasFin();

            model.setValueAt(nombre, filaSeleccionada, 0);
            model.setValueAt(descripcion, filaSeleccionada, 1);
            model.setValueAt(codigo, filaSeleccionada, 2);
            model.setValueAt(cupo, filaSeleccionada, 3);
            model.setValueAt(reservadp, filaSeleccionada, 4);
            model.setValueAt(costo, filaSeleccionada, 5);
            model.setValueAt(disponible, filaSeleccionada, 6);
            model.setValueAt(dias, filaSeleccionada, 7);
            model.setValueAt(clase, filaSeleccionada, 8);
            model.setValueAt(entrenador, filaSeleccionada, 9);
            model.setValueAt(hinicio, filaSeleccionada, 10);
            model.setValueAt(hfin, filaSeleccionada, 11);

            actividad.modificarActividad(filaSeleccionada, nombre, descripcion, codigo,
                    cupo,reservadp,costo, disponible, dias,clase,entrenador, hinicio, hfin);
            grabar();
        }
    }

    private void Eliminar(int filaSeleccionada) {
        model.removeRow(filaSeleccionada);
        actividad.eliminarActividad(filaSeleccionada);
    }
}
