package controlador;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.element.Paragraph;
import modelo.*;
import vista.ventanaGestionPagos;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
public class CtrlPagos implements ActionListener {

    private ventanaGestionPagos vista;
    private Pago pago;
    private Gimnasio gimnasio;
    private CtrlCorreo v7;
    private CtrlHistorialPago v8;
    private DefaultTableModel model;
    private DefaultTableModel model2;
    private DefaultTableModel model3;
    private DefaultTableModel model4;
    private SociosGYM sociosGYM;
    private  Duenio duenio;
    private Actividades actividades1;
    private RegistroActividad registroActividad;
    private HistorialDePagos historialDePagos;
    private ArrayList<RegistroActividad> actividadesSeleccionadas;
    private GestionAsignarGimnasios gestionAsignarGimnasios;
    private GestionAsignarGimnasios gestionGimnasios;
    private List<Asignacion> asignacionesRealizadas;
    private CtrlCudsFacturas v1;
    private CrtlAlertas v9;
    private CtrlVentanaGeneral v11;

    public CtrlPagos(){
        this.vista = new ventanaGestionPagos();
        this.pago = new Pago();
        this.gimnasio= new Gimnasio();
        this.actividades1 =  new Actividades();
        this.registroActividad = new RegistroActividad();
        historialDePagos = HistorialDePagos.getInstancia();
       // this.historialDePagos =  new HistorialDePagos();
        this.gestionAsignarGimnasios = new GestionAsignarGimnasios();
       // this.ctrlHistorialPago = new CtrlHistorialPago();
        this.actividadesSeleccionadas = new ArrayList<>();
        this.gestionGimnasios = new GestionAsignarGimnasios();
        this.asignacionesRealizadas = new ArrayList<>();
       // sociosGYM=SociosGYM.getInstancia();

        model = new DefaultTableModel();
        model2 = new DefaultTableModel();
        model3 = new DefaultTableModel();
        model4 = new DefaultTableModel();

        vista.PagarButton.addActionListener(this);
        vista.asignarButton.addActionListener(this);
        vista.cancelButton.addActionListener(this);
        vista.configuracionDeAlertasButton.addActionListener(this);
        vista.enviarArchivosDePagoButton.addActionListener(this);
        vista.generarFacturaButton.addActionListener(this);
        vista.crudButton.addActionListener(this);
        vista.regresarButton.addActionListener(this);
        vista.historialPagoButton.addActionListener(this);
        vista.comboBox1.addActionListener(this);
        vista.comboBox2.addActionListener(this);
        vista.inicioButton.addActionListener(this);
        //this.historialDePagos.recuperar("HistorialPagos");
        //recuperar();

        inicializarComponentes();
        //rec();
        cargarSocios();
        vista.table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.table1.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocarDatosSocio(filaSeleccionada);
                    }
                }
            }
        });

        inicializarComponentes2();
        cargarActividades();
        //rec2();
        vista.table2.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        vista.table2.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.table2.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocarDatosActividad(filaSeleccionada);
                        calcularTotalActividadesSeleccionadas();
                    }
                }
            }
        });

        inicializarComponentes3();
        cargarGYMs();
        vista.table3.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.table3.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocarDatosGym(filaSeleccionada);
                    }
                }
            }
        });

        inicializarComponentes4();
        recuperar();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==vista.regresarButton){
            CtrlActividades v2 = new CtrlActividades();
            vista.dispose();
        }
        if(e.getSource()==vista.asignarButton){
            if(CamposCompletados()){
                asignarGimnasio();
            }
        }
        if(e.getSource() == vista.comboBox1) {
            String opc = (String) vista.comboBox1.getSelectedItem();
            double costoTotal = Double.parseDouble(vista.textValor.getText());
            costoCancelar(costoTotal, opc);
        }
        if(e.getSource()==vista.generarFacturaButton){
            int filaSeleccionada = vista.table1.getSelectedRow();
            int filaSeleccionada2 = vista.table2.getSelectedRow();
            int filaSeleccionada3 = vista.table2.getSelectedRow();
            if (filaSeleccionada != -1 && filaSeleccionada2 != -1 && filaSeleccionada3 != -1) {
                generarFactura();
                generarRecibo();
            }else {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione un socio, al menos una actividad y un gimnasio.");
            }
        }
        if(e.getSource()==vista.crudButton){
            v1 = new CtrlCudsFacturas();
            vista.dispose();
        }
        if(e.getSource()==vista.PagarButton){
            int filaSeleccionada = vista.table1.getSelectedRow();
            int filaSeleccionada2 = vista.table2.getSelectedRow();
            int filaSeleccionada3 = vista.table2.getSelectedRow();
            if (filaSeleccionada != -1 && filaSeleccionada2 != -1 && filaSeleccionada3 != -1) {
                realizarPago();
            }else {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione un socio, al menos una actividad y un gimnasio.");
            }

        }
        if(e.getSource()==vista.cancelButton){
            limpiarFormulario();
        }
        if(e.getSource()==vista.enviarArchivosDePagoButton){
            v7=new CtrlCorreo();
            vista.dispose();
        }
        if(e.getSource()==vista.historialPagoButton){
            v8 = new CtrlHistorialPago();
            vista.dispose();
        }
        if(e.getSource()==vista.configuracionDeAlertasButton){
            v9 = new CrtlAlertas();
            vista.dispose();
        }
        if(e.getSource()==vista.inicioButton){
            v11 = new CtrlVentanaGeneral();
            vista.dispose();
        }
    }
    private boolean CamposCompletados() {
        if (vista.textValor.equals("0.0")
                || vista.textValorCancelar.getText().isEmpty()
        ) {
            JOptionPane.showMessageDialog(null, "Seleccione la membresia \n para calcular el costo total.");
            return false;
        }
        return true;
    }
    private void limpiarFormulario() {
        vista.textValorCancelar.setText("");
        vista.table1.clearSelection();
        vista.table2.clearSelection();
        vista.table3.clearSelection();
    }
    private void calcularTotalActividadesSeleccionadas() {
        int[] filasSeleccionadas = vista.table2.getSelectedRows();
        double total = 0.0;
        for (int fila : filasSeleccionadas) {
            String costoStr = (String) vista.table2.getValueAt(fila, 5); // Suponiendo que el costo está en la columna 5
            double costo = Double.parseDouble(costoStr);
            total += costo;
        }
        vista.textValor.setText(String.valueOf(total));
    }
    public void costoCancelar(double valor, String opc) {
        double total = 0;
        switch (opc) {
            case "Diaria":
                total = valor * 2;
                break;
            case "Semanal":
                total = valor * 10;
                break;
            case "Mensual":
                total = valor * 30;
                break;
            case "Trimestral":
                total = valor * 80;
                break;
            case "Semestral":
                total = valor * 100;
                break;
            case "Anual":
                total = valor * 200;
                break;
        }
        vista.textValorCancelar.setText(String.valueOf(total));
    }
//    private void asignarGimnasio() {
//        Persona socioSeleccionado = obtenerPersonaSeleccionada();
//        List<RegistroActividad> actividadesSeleccionadas = obtenerActividadesSeleccionadas();
//        Gimnasio gimnasioSeleccionado = obtenerGimnasioSeleccionado();
//        if (socioSeleccionado != null && !actividadesSeleccionadas.isEmpty() && gimnasioSeleccionado != null) {
//            Asignacion asignacion = new Asignacion(socioSeleccionado, gimnasioSeleccionado);
//            asignacion.setActividades(actividadesSeleccionadas);
//            socioSeleccionado.getAsignaciones().add(asignacion);
//            historialDePagos.registrarAsignacion(asignacion);
//            JOptionPane.showMessageDialog(null, "Se ha asignado correctamente las actividades y gimnasio al socio.");
//        } else {
//            JOptionPane.showMessageDialog(null, "Por favor, seleccione un socio, al menos una actividad y un gimnasio.");
//        }
//    }
//    private Persona obtenerPersonaSeleccionada() {
//        int filaSeleccionada = vista.table1.getSelectedRow();
//        if (filaSeleccionada != -1) {
//            String nombre = (String) vista.table1.getValueAt(filaSeleccionada, 0);
//            String dni = (String) vista.table1.getValueAt(filaSeleccionada, 1);
//            return new Persona(nombre, dni);
//        }
//        return null;
//    }
//
//    private List<RegistroActividad> obtenerActividadesSeleccionadas() {
//        int[] filasSeleccionadas = vista.table2.getSelectedRows();
//        List<RegistroActividad> actividades = new ArrayList<>();
//        for (int fila : filasSeleccionadas) {
//            String nombre = (String) vista.table2.getValueAt(fila, 0);
//            String descripcion = (String) vista.table2.getValueAt(fila, 1);
//            String duracion = (String) vista.table2.getValueAt(fila, 2);
//            String horario = (String) vista.table2.getValueAt(fila, 3);
//            String dias = (String) vista.table2.getValueAt(fila, 4);
//            double costo = Double.parseDouble((String) vista.table2.getValueAt(fila, 5));
//            actividades.add(new RegistroActividad(nombre, descripcion, duracion, horario, dias, costo));
//        }
//        return actividades;
//    }
//
//    private Gimnasio obtenerGimnasioSeleccionado() {
//        int filaSeleccionada = vista.table3.getSelectedRow();
//        if (filaSeleccionada != -1) {
//            String nombre = (String) vista.table3.getValueAt(filaSeleccionada, 0);
//            String direccion = (String) vista.table3.getValueAt(filaSeleccionada, 1);
//            String telefono = (String) vista.table3.getValueAt(filaSeleccionada, 2);
//            return new Gimnasio(nombre, direccion, telefono);
//        }
//        return null;
//    }
    private void asignarGimnasio() {
        Persona socioSeleccionado = obtenerPersonaSeleccionada();
        List<RegistroActividad> actividadesSeleccionadas = obtenerActividadesSeleccionadas();
        Gimnasio gimnasioSeleccionado = obtenerGimnasioSeleccionado();
        System.out.println("++++++++++++++++++");
        System.out.println("Socio seleccionado: " + socioSeleccionado);
        System.out.println("Actividades seleccionadas: " + actividadesSeleccionadas);
        System.out.println("Gimnasio seleccionado: " + gimnasioSeleccionado);

        if (socioSeleccionado != null && !actividadesSeleccionadas.isEmpty() && gimnasioSeleccionado != null) {
            Asignacion asignacion = new Asignacion(socioSeleccionado, gimnasioSeleccionado);
            for (RegistroActividad actividad : actividadesSeleccionadas) {
                asignacion.agregarActividad(actividad);
            }
            asignacionesRealizadas.add(asignacion);
            gestionGimnasios.agregarAsignacion(gimnasioSeleccionado, asignacion);

            JOptionPane.showMessageDialog(null, "Asignación realizada correctamente.");
            limpiarFormulario();
            guardarAsignaciones("asignaciones");
        } else {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione un socio, al menos una actividad y un gimnasio.");
        }
    }
    public Persona obtenerPersonaSeleccionada() {
        int filaSeleccionada = vista.table1.getSelectedRow();
        if (filaSeleccionada != -1) {
            System.out.println(" Persona seleccionada: "+filaSeleccionada);
            String nombre = (String) vista.table1.getValueAt(filaSeleccionada, 0);
            for (Persona socio : sociosGYM.getPersonas()) {
                if (socio.getNombre().equals(nombre)) {
                    return socio;
                }
            }
        }
        return null;
    }
    public List<RegistroActividad> obtenerActividadesSeleccionadas() {
        int[] filasSeleccionadas = vista.table2.getSelectedRows();
        List<RegistroActividad> actividades = new ArrayList<>();

        System.out.println(" Actividades seleccionada: "+filasSeleccionadas);
        for (int fila : filasSeleccionadas) {
            String nombre = (String) vista.table2.getValueAt(fila, 0);
            for (RegistroActividad actividad : actividades1.getActividades()) {
                if (actividad.getNombre().equals(nombre)) {
                    actividades.add(actividad);
                }
            }
        }
        return actividades;
    }
    public Gimnasio obtenerGimnasioSeleccionado() {
        int filaSeleccionada = vista.table3.getSelectedRow();
        if (filaSeleccionada != -1) {
            System.out.println(" GYM seleccionada: "+filaSeleccionada);
            String nombre = (String) vista.table3.getValueAt(filaSeleccionada, 0);
            for (Gimnasio gym : duenio.getGimnasios())
                if (gym.getNombre().equals(nombre)) {
                    return gym;
                }
        }
        return null;
    }
    public void guardarAsignaciones(String nombreArchivo) {
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(nombreArchivo+".txt", true))) {

            for (Asignacion asignacion : asignacionesRealizadas) {
                Persona socio = asignacion.getPersona();
                Gimnasio gym = asignacion.getGimnasio();

                bufferedWriter.write("Socio: " + socio.getNombre() + ", Cedula: " + socio.getCedula()+ ", Dirección: " + socio.getDireccion() + ", Id: " + socio.getId()+ "\n");
                bufferedWriter.write("Gimnasio: " + gym.getNombre() + ", Dirección: " + gym.getDireccion() + ", Teléfono: " + gym.getTelefono() + "\n");
                bufferedWriter.write("Actividades:\n");
                for (RegistroActividad actividad : asignacion.getActividades()) {
                    bufferedWriter.write("- " + actividad.getNombre() + ", Descripción: " + actividad.getDescripcion() + ", Horario: " + actividad.getHinicio() +  ", Duración: " + actividad.getHfin() +", Profesor: " + actividad.getEntrenador() + ", Costo: " + actividad.getCosto() + "\n");
                }
                bufferedWriter.write("\n");
            }

            JOptionPane.showMessageDialog(null, "Asignaciones guardadas correctamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String obtenerFechaActual() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        return formatter.format(date);
    }


    private void realizarPago() {
        String monto = vista.textValorCancelar.getText();
        String fecha = obtenerFechaActual();

        //Pago nuevoPago = new Pago(pago.getNombre(), pago.getApellido(), pago.getCedula(),pago.getId(), pago.getDireccion(), pago.getTelefono(), monto,pago.getMembresia(), fecha);
        //historialDePagos.agregarPago(nuevoPago);
        historialDePagos.agregarPago2(pago.getNombre(), pago.getApellido(), pago.getCedula(), pago.getId(), pago.getDireccion(), pago.getTelefono(), pago.getMonto(), pago.getMembresia(), pago.getFecha());
        model4.addRow(new Object[]{pago.getNombre(),pago.getApellido(), pago.getCedula(),pago.getId(), pago.getDireccion(), pago.getTelefono(), monto,pago.getMembresia(), fecha});
        grabarPagos();
        JOptionPane.showMessageDialog(vista, "Pago realizado y registrado en el historial.");
    }

    public void grabarPagos() {
        historialDePagos.grabar("HistorialPagos");
    }

    private void inicializarComponentes4() {
        model4.setColumnCount(9);
        model4.setRowCount(0);
        model4.setColumnIdentifiers(new Object[]{"Nombre", "Apellido", "Cedula","Id", "Direccion", "Telefono", "Monto","Membresia", "Fecha/Hora"});
        vista.table4.setModel(model4);
    }

    public void recuperar(){
        try {
            HistorialDePagos historialDePagos1 = historialDePagos.recuperar("HistorialPagos");
            llenarTabla4(historialDePagos1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        //JOptionPane.showMessageDialog(null,"Datos Recuperados");
        System.out.println("Datos recuperados");
    }

    private void llenarTabla4(HistorialDePagos historialDePagos1) {
        model4.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Pago pago: historialDePagos1.getPagos()) {
            model4.addRow(new Object[]{
                    pago.getNombre(),
                    pago.getApellido(),
                    pago.getCedula(),
                    pago.getId(),
                    pago.getDireccion(),
                    pago.getTelefono(),
                    pago.getMonto(),
                    pago.getMembresia(),
                    pago.getFecha()
            });
        }
    }

    private void inicializarComponentes() {
        model.setColumnCount(7);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre", "Apellido", "Cedula","Id", "Direccion", "Telefono", "Rol"});
        vista.table1.setModel(model);
    }

//    public void rec(){
//        try {
//            SociosGYM sociosGYM1 = sociosGYM.recuperar("SociosGYM");
//            //llenarTablaS(sociosGYM1);
//        } catch (IOException ex) {
//            throw new RuntimeException(ex);
//        }
//        //JOptionPane.showMessageDialog(null,"Datos Recuperados");
//        System.out.println("Datos Recuperados");
//    }

//    private void llenarTablaS(SociosGYM sociosGYM) {
//        model.setRowCount(0); // Limpiar la tabla antes de llenarla
//        for (Persona persona: sociosGYM.getPersonas()) {
//            if ("Miembro".equals(persona.getRol())) {
//                model.addRow(new Object[]{persona.getNombre(), persona.getApellido(),
//                        persona.getCedula(), persona.getId(), persona.getDireccion(),
//                        persona.getTelefono(), persona.getRol()});
//            }
//        }
//    }
    private void cargarSocios() {
        sociosGYM = SociosGYM.getInstancia();
        for (Persona persona : sociosGYM.getPersonas()) {
            if ("Miembro".equals(persona.getRol())) {
                model.addRow(new Object[]{persona.getNombre(), persona.getApellido(),
                        persona.getCedula(),persona.getId(), persona.getDireccion(), persona.getTelefono(), persona.getRol()});
            }
        }
    }

    private void colocarDatosSocio(int filaSeleccionada) {
        String monto = vista.textValorCancelar.getText();
        String fecha = obtenerFechaActual();
        String membresia = (String) vista.comboBox1.getSelectedItem();

        String nombre = (String) vista.table1.getValueAt(filaSeleccionada, 0);
        String apellido = (String) vista.table1.getValueAt(filaSeleccionada, 1);
        String cedula = (String) vista.table1.getValueAt(filaSeleccionada, 2);
        String id = (String) vista.table1.getValueAt(filaSeleccionada, 3);
        String direccion = (String) vista.table1.getValueAt(filaSeleccionada, 4);
        String telefono = (String) vista.table1.getValueAt(filaSeleccionada, 5);

        pago.setNombre(nombre);
        pago.setApellido(apellido);
        pago.setCedula(cedula);
        pago.setId(id);
        pago.setDireccion(direccion);
        pago.setTelefono(telefono);
        pago.setMonto(monto);
        pago.setFecha(fecha);
        pago.setMembresia(membresia);
    }
    private void inicializarComponentes2(){
        model2.setColumnCount(12);
        model2.setRowCount(0);
        model2.setColumnIdentifiers(new Object[]{"Nombre", "Descripcion", "Codigo","Cupo",
                "Reservado","Costo $","Disponible", "Dias",
                "Clase","Entrenador","Hora-Inicio","Hora-Fin"});
        vista.table2.setModel(model2);
    }

//    public void rec2(){
//        try {
//            Actividades actividades= actividades1.recuperar("Actividades");
//            llenarTablaA(actividades);
//        } catch (IOException ex) {
//            throw new RuntimeException(ex);
//        }
//        //JOptionPane.showMessageDialog(null,"Datos Recuperados");
//        System.out.println("Datos Recuperados");
//    }
//    private void llenarTablaA(Actividades actividades){
//        for (RegistroActividad registroActividad : actividades.getActividades()) {
//            model2.addRow(new Object[]{
//                    registroActividad.getNombre(),registroActividad.getDescripcion(),registroActividad.getCodigo(),
//                    registroActividad.getCupo(),registroActividad.getReservar(),registroActividad.getCosto(),
//                    registroActividad.getDisponible(),registroActividad.getDias(),registroActividad.getClase(),
//                    registroActividad.getEntrenador(),registroActividad.getHinicio(),registroActividad.getHfin()
//            });
//        }
//        calcularTotalActividadesSeleccionadas();
//    }
    private void cargarActividades() {
        actividades1 = Actividades.getInstancia();
        for (RegistroActividad registroActividad : actividades1.getActividades()) {
            model2.addRow(new Object[]{
                    registroActividad.getNombre(),registroActividad.getDescripcion(),registroActividad.getCodigo(),
                    registroActividad.getCupo(),registroActividad.getReservar(),registroActividad.getCosto(),
                    registroActividad.getDisponible(),registroActividad.getDias(),registroActividad.getClase(),
                    registroActividad.getEntrenador(),registroActividad.getHinicio(),registroActividad.getHfin()
            });
        }
        calcularTotalActividadesSeleccionadas();
    }
    private void colocarDatosActividad(int filaSeleccionada) {
        String nombre = (String) vista.table2.getValueAt(filaSeleccionada, 0);
        String Descripcion = (String) vista.table2.getValueAt(filaSeleccionada, 1);
        String Codigo = (String) vista.table2.getValueAt(filaSeleccionada, 2);
        String Cupo = (String) vista.table2.getValueAt(filaSeleccionada, 3);
        String Reservado = (String) vista.table2.getValueAt(filaSeleccionada, 4);
        String Costo = (String) vista.table2.getValueAt(filaSeleccionada, 5);
        String Disponible = (String) vista.table2.getValueAt(filaSeleccionada, 6);
        String Dias = (String) vista.table2.getValueAt(filaSeleccionada, 7);
        String Clase = (String) vista.table2.getValueAt(filaSeleccionada, 8);
        String Entrenador = (String) vista.table2.getValueAt(filaSeleccionada, 9);
        String HoraInicio = (String) vista.table2.getValueAt(filaSeleccionada, 10);
        String HoraFin = (String) vista.table2.getValueAt(filaSeleccionada, 11);

        registroActividad.setNombre(nombre);
        registroActividad.setDescripcion(Descripcion);
        registroActividad.setCodigo(Codigo);
        registroActividad.setCupo(Cupo);
        registroActividad.setReservar(Reservado);
        registroActividad.setCosto(Costo);
        registroActividad.setDisponible(Disponible);
        registroActividad.setDias(Dias);
        registroActividad.setClase(Clase);
        registroActividad.setEntrenador(Entrenador);
        registroActividad.setHinicio(HoraInicio);
        registroActividad.setHfin(HoraFin);

    }
    private void inicializarComponentes3(){
        model3.setColumnCount(10);
        model3.setRowCount(0);
        model3.setColumnIdentifiers(new Object[]{"Nombre","Direccion","Telefono","Ubicacion",
                "Codigo","Fecha-Inicio","Fecha-Fin","Hora-inicio","Hora-Fin","Ruc"});
        vista.table3.setModel(model3);
    }
    private void cargarGYMs() {
        duenio = Duenio.getInstancia();
        for (Gimnasio gimnasio : duenio.getGimnasios()) {
                model3.addRow(new Object[]{gimnasio.getNombre(), gimnasio.getDireccion(),
                        gimnasio.getTelefono(), gimnasio.getNombreCalles(), gimnasio.getCodigo(),
                        gimnasio.getFechaInicio(),gimnasio.getFechaFin(),
                        gimnasio.getHoraInicio(),gimnasio.getHoraFin(),gimnasio.getRuc()});
        }
    }
    private void colocarDatosGym(int filaSeleccionada) {
        String nombre = (String) vista.table3.getValueAt(filaSeleccionada, 0);
        String Direccion = (String) vista.table3.getValueAt(filaSeleccionada, 1);
        String Telefono = (String) vista.table3.getValueAt(filaSeleccionada, 2);
        String Ubicacion = (String) vista.table3.getValueAt(filaSeleccionada, 3);
        String Codigo = (String) vista.table3.getValueAt(filaSeleccionada, 4);
        String fechainicio = (String) vista.table3.getValueAt(filaSeleccionada, 5);
        String fechaFin = (String) vista.table3.getValueAt(filaSeleccionada, 6);
        String horaInico = (String) vista.table3.getValueAt(filaSeleccionada, 7);
        String horaFin = (String) vista.table3.getValueAt(filaSeleccionada, 8);
        String ruc = (String) vista.table3.getValueAt(filaSeleccionada, 9);

        gimnasio.setNombre(nombre);
        gimnasio.setDireccion(Direccion);
        gimnasio.setTelefono(Telefono);
        gimnasio.setNombreCalles(Ubicacion);
        gimnasio.setCodigo(Codigo);
        gimnasio.setFechaInicio(fechainicio);
        gimnasio.setFechaFin(fechaFin);
        gimnasio.setHoraInicio(horaInico);
        gimnasio.setHoraFin(horaFin);
        gimnasio.setRuc(ruc);
    }
    private void generarFactura() {

        String nombreArchivo = JOptionPane.showInputDialog("Factura nombre del archivo ?");
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El nombre del archivo no puede estar vacío.");
            return;
        }

        List<RegistroActividad> actividades =  actividades1.obtenerActividades();
        Random random = new Random();
        int numeroFactura = 1000 + random.nextInt(2001); // 1000 + (0 a 2000)

        String fecha = obtenerFechaActual();
        StringBuilder factura = new StringBuilder();

        factura.append("\t    Factura\n");

        factura.append("    Número de Factura: ").append(numeroFactura).append("\n");
        factura.append("    Fecha: ").append(fecha).append("\n\n");

        factura.append("\t    Datos del Gimnasio\n\n");
        factura.append("    Nombre:  ").append(gimnasio.getNombre()).append("\n");
        factura.append("    Direccion:  ").append(gimnasio.getDireccion()).append("\n");
        factura.append("    Telefono:  ").append(gimnasio.getTelefono()).append("\n");
        factura.append("    Ubicacion:  ").append(gimnasio.getNombreCalles()).append("\n");
        factura.append("    Codigo:  ").append(gimnasio.getCodigo()).append("\n");
        factura.append("    Ruc:  ").append(gimnasio.getRuc()).append("\n");

        factura.append("\t    Datos del socio\n\n");
        factura.append("    Nombre: ").append(pago.getNombre()).append("\n");
        factura.append("    Apellido: ").append(pago.getApellido()).append("\n");
        factura.append("    Cedula: ").append(pago.getCedula()).append("\n");
        factura.append("    Direccion: ").append(pago.getDireccion()).append("\n");
        factura.append("    Telefono: ").append(pago.getTelefono()).append("\n");
        factura.append("\n  Actividades : Precio  \n");

        double totalCosto = 0;
        for (RegistroActividad actividad : actividades) {
            factura.append(actividad.getNombre()).append(" : ").append(actividad.getCosto()).append("\n");
            totalCosto += Double.parseDouble(actividad.getCosto());
        }

        factura.append("  Total Actividades : ").append(totalCosto).append("\n");
        factura.append("  Forma de pago : ").append((String) vista.comboBox2.getSelectedItem()).append("\n");
        factura.append("  Iva : 15% ").append("\n");
        factura.append("  Valor Total: ").append(vista.textValorCancelar.getText()).append("\n");

        try {
            PdfWriter writer = new PdfWriter("Factura "+nombreArchivo + ".pdf");
            PdfDocument pdfDoc = new PdfDocument(writer);
            com.itextpdf.layout.Document document = new com.itextpdf.layout.Document(pdfDoc);
            document.add(new Paragraph(factura.toString()));
            document.close();
            System.out.println("Factura: "+nombreArchivo +"¡PDF de factura  creada!");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private void generarRecibo() {

        String nombreArchivo = JOptionPane.showInputDialog("Recibo nombre del archivo ?");
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El nombre del archivo no puede estar vacío.");
            return;
        }

        Random random = new Random();
        int numeroRecibo = 1000 + random.nextInt(2001); // 1000 + (0 a 2000)

        String fecha = obtenerFechaActual();
        StringBuilder recibo = new StringBuilder();

        recibo.append("\t    Recibo\n");
        recibo.append("    Número de Recibo: ").append(numeroRecibo).append("\n");
        recibo.append("    Fecha: ").append(fecha).append("\n\n");

        recibo.append(" \t   Datos del Gimnasio\n");
        recibo.append("    Nombre:  ").append(gimnasio.getNombre()).append("\n");
        recibo.append("    Direccion:  ").append(gimnasio.getDireccion()).append("\n");
        recibo.append("    Telefono:  ").append(gimnasio.getTelefono()).append("\n");
        recibo.append("    Ruc:  ").append(gimnasio.getRuc()).append("\n");

        recibo.append("\t    Datos del socio\n");
        recibo.append("    Nombre: ").append(pago.getNombre()).append("\n");
        recibo.append("    Apellido: ").append(pago.getApellido()).append("\n");
        recibo.append("    Cedula: ").append(pago.getCedula()).append("\n");
        recibo.append("    Direccion: ").append(pago.getDireccion()).append("\n");
        recibo.append("    Telefono: ").append(pago.getTelefono()).append("\n");

        recibo.append("\n    Cantidad Pagada: ").append(vista.textValorCancelar.getText()).append("\n");
        recibo.append("    Forma de Pago: ").append((String) vista.comboBox2.getSelectedItem()).append("\n");


        // Crear el archivo PDF
        try {
            PdfWriter writer = new PdfWriter("Recibo "+nombreArchivo + ".pdf");
            PdfDocument pdfDoc = new PdfDocument(writer);
            com.itextpdf.layout.Document document = new com.itextpdf.layout.Document(pdfDoc);
            // Añadir el contenido del recibo al PDF
            document.add(new Paragraph(recibo.toString()));
            document.close();
            System.out.println("Recibo: "+nombreArchivo+"¡PDF de recibo creado!");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}