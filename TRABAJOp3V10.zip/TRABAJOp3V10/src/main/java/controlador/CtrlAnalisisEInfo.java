package controlador;

import vista.ventanaInformeAnalisis;

import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CtrlAnalisisEInfo implements ActionListener {

    private ventanaInformeAnalisis vista;
    private DefaultTableModel model;
    private List<Asignacion> asignaciones;

    public CtrlAnalisisEInfo() {
        this.vista = new ventanaInformeAnalisis();
        vista.btnregresar.addActionListener(this);
        this.asignaciones = new ArrayList<>();
        model = new DefaultTableModel();
        inicializarComponentes();
        cargarAsignaciones();
        llenarTablaAsignaciones();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnregresar) {
            vista.dispose();
        }
    }

    private void cargarAsignaciones() {
        asignaciones = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("asistencias.txt"))) {
            String linea;
            Asignacion asignacion = null;
            while ((linea = br.readLine()) != null) {
                if (linea.startsWith("Socio:")) {
                    if (asignacion != null) {
                        asignaciones.add(asignacion);
                    }
                    asignacion = new Asignacion();
                    String[] partes = linea.split(", ");
                    asignacion.socio = partes[0].split(": ")[1];
                    asignacion.cedula = partes[1].split(": ")[1];
                } else if (linea.startsWith("Gimnasio:")) {
                    String[] partes = linea.split(", ");
                    asignacion.gimnasio = partes[0].split(": ")[1];
                } else if (linea.startsWith("Asistencias:")) {
                    asignacion.asistencias = Integer.parseInt(linea.split(": ")[1]);
                }
            }
            if (asignacion != null) {
                asignaciones.add(asignacion);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        model.setColumnCount(4);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Socio", "Cedula", "Gimnasio", "Asistencias"});
        vista.table1.setModel(model);
    }

    private void llenarTablaAsignaciones() {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Asignacion asignacion : asignaciones) {
            model.addRow(new Object[]{asignacion.socio, asignacion.cedula, asignacion.gimnasio, asignacion.asistencias});
        }
    }

    private static class Asignacion {
        String socio;
        String cedula;
        String gimnasio;
        int asistencias = 0;
    }
}
/*
package controlador;

import modelo.Asignacion;
import vista.VentanaGeneral;
import vista.ventanaInformeAnalisis;

import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CtrlAnalisisEInfo implements ActionListener {

    private ventanaInformeAnalisis vista;
    private VentanaGeneral v1;
    private DefaultTableModel model;
    private CtrlVentanaGeneral vg;
    private List<Asignacion> asignaciones;
    public CtrlAnalisisEInfo(){
        this.vista= new ventanaInformeAnalisis();
       // vista.informeAsistenciaButton.addActionListener(this);
        //vista.analisisDeRegistroButton.addActionListener(this);
        vista.btnregresar.addActionListener(this);
        this.asignaciones = new ArrayList<>();
        model = new DefaultTableModel();
        inicializarComponentes();
        cargarAsignaciones();
        llenarTablaAsignaciones();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnregresar){
//            v1=new VentanaGeneral();
//            vista.setVisible(false);
            vg=new CtrlVentanaGeneral();
            vista.dispose();
        }
    }

    private void cargarAsignaciones() {
        asignaciones = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("asignaciones.txt"))) {
        String linea;
        CtrlAccederAlGym.Asignacion asignacion = null;
        while ((linea = br.readLine()) != null) {
            if (linea.startsWith("Socio:")) {
                if (asignacion != null) {
                    asignaciones.add(asignacion);
                }
                asignacion = new CtrlAccederAlGym.Asignacion();
                String[] partes = linea.split(", ");
                asignacion.socio = partes[0].split(": ")[1];
                asignacion.cedula = partes[1].split(": ")[1];
            } else if (linea.startsWith("Gimnasio:")) {
                String[] partes = linea.split(", ");
                asignacion.gimnasio = partes[0].split(": ")[1];
            } else if (linea.startsWith("Asistencias:")) {
                asignacion.asistencias = Integer.parseInt(linea.split(": ")[1]);
            }
        }
        if (asignacion != null) {
            asignaciones.add(asignacion);
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    private void inicializarComponentes(){
//        model.setColumnCount(10);
//        model.setRowCount(0);
//        model.setColumnIdentifiers(new Object[]{"Nombre","Direccion","Telefono","Ubicacion","Codigo","Fecha-Inicio","Fecha-Fin","Hora-inicio","Hora-Fin","Ruc"});
//        vista.table1.setModel(model);

        model.setColumnCount(4);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Socio", "Cedula", "Gimnasio", "Asistencias"});
        vista.table1.setModel(model);
    }
    private void llenarTablaAsignaciones() {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Asignacion asignacion : asignaciones) {
            model.addRow(new Object[]{asignacion.socio, asignacion.cedula, asignacion.gimnasio, asignacion.asistencias});
        }
    }

    private class Asignacion {
        String socio;
        String cedula;
        String gimnasio;
        int asistencias = 0;
    }
}


*/
