package controlador;

import modelo.HistorialDePagos;
import modelo.Pago;
import modelo.Persona;
import modelo.SociosGYM;
import vista.ventanaHistorialPago;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class CtrlHistorialPago implements ActionListener {

    private ventanaHistorialPago vista;
    private HistorialDePagos historialDePagos;
    private CtrlPagos v1;
    private DefaultTableModel model;
    private List<Pago> pagosOriginales;

    public CtrlHistorialPago(){
        this.vista= new ventanaHistorialPago();
        historialDePagos = HistorialDePagos.getInstancia();
        pagosOriginales = new ArrayList<>();
        vista.regresarButton.addActionListener(this);
        vista.buscarButton.addActionListener(this);
        vista.eliminarButton.addActionListener(this);
        vista.actualizarButton.addActionListener(this);
        vista.comboBox1.addActionListener(this);
        model = new DefaultTableModel();
        inicializarComponentes();
        recuperar();

        vista.table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.table1.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocar(filaSeleccionada);
                    }
                }
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.regresarButton){
            v1 = new CtrlPagos();
            vista.dispose();
        }
        if (e.getSource() == vista.comboBox1) {
            ordenarTabla(vista.comboBox1.getSelectedItem().toString());
        }
        if(e.getSource()==vista.actualizarButton){
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
              guardarDesdeTextArea(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla" +
                        "\n Edite los campos en el TextArea"+
                        "\n y luego actualizar ");
            }
        }
        if(e.getSource()==vista.eliminarButton){
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                Eliminar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla lo que desea eliminar");
            }
        }
        if(e.getSource()==vista.buscarButton){
            String BuscarDato=(String) JOptionPane.showInputDialog(null,"Ingrese el dato a buscar");
            int i=historialDePagos.buscar(BuscarDato);
            System.out.println(i);
            colocar(i);
        }
    }

    private void inicializarComponentes() {
        model.setColumnCount(9);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre", "Apellido", "Cedula","Id", "Direccion", "Telefono", "Monto","Membresia", "Fecha/Hora"});
        vista.table1.setModel(model);
    }

    public void recuperar(){
        try {
            HistorialDePagos historialDePagos1 = historialDePagos.recuperar("HistorialPagos");
            pagosOriginales = new ArrayList<>(historialDePagos1.getPagos()); // Guardar una copia del orden original
            llenarTabla(historialDePagos1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }

    private void llenarTabla(HistorialDePagos historialDePagos1) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Pago pago: historialDePagos1.getPagos()) {
            model.addRow(new Object[]{
                    pago.getNombre(),
                    pago.getApellido(),
                    pago.getCedula(),
                    pago.getId(),
                    pago.getDireccion(),
                    pago.getTelefono(),
                    pago.getMonto(),
                    pago.getMembresia(),
                    pago.getFecha()
            });
        }
    }
    private void ordenarTabla(String criterio) {
        Comparator<Pago> comparador = null;
        switch (criterio) {
            case "Nombre":
                comparador = Comparator.comparing(Pago::getNombre, String.CASE_INSENSITIVE_ORDER);
                break;
            case "Apellido":
                comparador = Comparator.comparing(Pago::getApellido, String.CASE_INSENSITIVE_ORDER);
                break;
            case "Cedula":
                comparador = Comparator.comparing(Pago::getCedula);
                break;
            case "Id":
                comparador = Comparator.comparingInt(p -> Integer.parseInt(p.getId()));
                break;
            case "Direccion":
                comparador = Comparator.comparing(Pago::getDireccion, String.CASE_INSENSITIVE_ORDER);
                break;
            case "Telefono":
                comparador = Comparator.comparing(Pago::getTelefono);
                break;
            case "Monto":
                comparador = Comparator.comparingDouble(p -> Double.parseDouble(p.getMonto()));
                break;
            case "Membresia":
                comparador = Comparator.comparing(Pago::getMembresia);
                break;
            case "Fecha":
                comparador = Comparator.comparing(Pago::getFecha);
                break;
            case "Orden de ingreso":
               // historialDePagos.setPagos(new ArrayList<>(pagosOriginales)); // Restaurar el orden original
                llenarTabla2(pagosOriginales);
                return;
        }
        if (comparador != null) {
            historialDePagos.ordenarPagos(comparador);
            llenarTabla(historialDePagos);
        }
    }
    private void llenarTabla2(List<Pago> pagos) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Pago pago : pagos) {
            model.addRow(new Object[]{
                    pago.getNombre(),
                    pago.getApellido(),
                    pago.getCedula(),
                    pago.getId(),
                    pago.getDireccion(),
                    pago.getTelefono(),
                    pago.getMonto(),
                    pago.getMembresia(),
                    pago.getFecha()
            });
        }
    }

    private void guardarDesdeTextArea(int filaSeleccionada) {
        String[] lineas = vista.textArea1.getText().split("\n");
        if (lineas.length < 9) {
            JOptionPane.showMessageDialog(null, "Los datos del textArea no son válidos");
            return;
        }

        String nombre = lineas[2].split(": ")[1];
        String apellido = lineas[3].split(": ")[1];
        String cedula = lineas[4].split(": ")[1];
        String id = lineas[5].split(": ")[1];
        String direccion = lineas[6].split(": ")[1];
        String telefono = lineas[7].split(": ")[1];
        String monto = lineas[8].split(": ")[1];
        String membresia = lineas[9].split(": ")[1];
        String fecha = lineas[10].split(": ")[1];

        model.setValueAt(nombre, filaSeleccionada, 0);
        model.setValueAt(apellido, filaSeleccionada, 1);
        model.setValueAt(cedula, filaSeleccionada, 2);
        model.setValueAt(id, filaSeleccionada, 3);
        model.setValueAt(direccion, filaSeleccionada, 4);
        model.setValueAt(telefono, filaSeleccionada, 5);
        model.setValueAt(monto, filaSeleccionada, 6);
        model.setValueAt(membresia, filaSeleccionada, 7);
        model.setValueAt(fecha, filaSeleccionada, 8);

        historialDePagos.modificarHistorial(filaSeleccionada, nombre, apellido, cedula, id, direccion, telefono, monto, membresia, fecha);
        grabar();
    }
    private void Eliminar(int filaSeleccionada) {
        int response = JOptionPane.showConfirmDialog(null, "¿Desea eliminar este pago?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            historialDePagos.eliminarHistorial(filaSeleccionada);
            model.removeRow(filaSeleccionada);
            grabar();
        }
    }

    public void grabar() {
        historialDePagos.grabar("HistorialPagos");
    }

    public void colocar(int pos) {
        if(pos >= 0 && pos < HistorialDePagos.getInstancia().getPagos().size()) {
            Pago pago = HistorialDePagos.getInstancia().getPagos().get(pos);
            //System.out.println("Persona encontrada: " + pago.getNombre()); // Depuración adicional

            vista.textArea1.setText("\n \tInformacion Socio " +
                    "\n Nombre: "+pago.getNombre()+
                    "\n Apellido: "+pago.getApellido()+
                    "\n Cedula: "+pago.getCedula()+
                    "\n Id: "+pago.getId()+
                    "\n Direccion: "+pago.getDireccion()+
                    "\n Telefono: "+pago.getTelefono()+
                    "\n Monto: "+pago.getMonto()+
                    "\n Membresia: "+pago.getMembresia()+
                    "\n Fecha: "+pago.getFecha()
            );
        } else {
            JOptionPane.showMessageDialog(null, "Persona no encontrada");
        }
    }
    private void mostrarHistorialPagos() {
        List<Pago> pagos = historialDePagos.getPagos();
        StringBuilder historial = new StringBuilder();

        for (Pago pago : pagos) {
            historial.append("Nombre: ").append(pago.getNombre()).append("\n");
            historial.append("Apellido: ").append(pago.getApellido()).append("\n");
            historial.append("Cedula: ").append(pago.getCedula()).append("\n");
            historial.append("Direccion: ").append(pago.getDireccion()).append("\n");
            historial.append("Telefono: ").append(pago.getTelefono()).append("\n");
            historial.append("Monto: ").append(pago.getMonto()).append("\n");
            historial.append("Fecha: ").append(pago.getFecha()).append("\n\n");
        }
    }
}
