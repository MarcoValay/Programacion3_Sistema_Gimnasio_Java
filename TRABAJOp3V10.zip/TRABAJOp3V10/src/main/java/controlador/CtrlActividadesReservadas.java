package controlador;

import modelo.Actividades;
import modelo.Persona;
import modelo.RegistroActividad;
import modelo.SociosGYM;
import vista.ventanaActividadesReservadas;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CtrlActividadesReservadas implements ActionListener {
    private Map<Integer, Integer> actividadReservadaAMap;
    private Map<Integer, Integer> actividadAMap; // Mapa para todas las actividades
    private ventanaActividadesReservadas vista;
    private DefaultTableModel model;
    private Actividades actividades;
    private CtrlActividades v1;
    //private Actividades actividad;
    private CtrlNotificaciones v2;

    public CtrlActividadesReservadas(Map<Integer, Integer> actividadReservadaAMap){

        if (actividadAMap == null) {
            this.actividadAMap = new HashMap<>();
        } else {
            this.actividadAMap = actividadAMap;
        }
        this.actividadReservadaAMap = new HashMap<>();
        this.vista= new ventanaActividadesReservadas();
        this.actividades= new Actividades();
        actividades = Actividades.getInstancia();
        vista.Regresar.addActionListener(this);
        vista.cancelarButton.addActionListener(this);
        vista.notificarButton.addActionListener(this);
        model = new DefaultTableModel();
        inicializarComponentes();
        recuperarDatos();


        // Añadir el ListSelectionListener a la tabla
        vista.table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.table1.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocar(filaSeleccionada);
                    }
                }
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vista.Regresar){
            v1= new CtrlActividades();
            vista.dispose();
        }
        if (e.getSource() == vista.cancelarButton) {
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                Eliminar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la actividad para eliminar la reserva");
            }
        }
        if(e.getSource()==vista.notificarButton){
            v2 = new CtrlNotificaciones();
            vista.dispose();
        }

    }

    public void colocar(int pos) {
        if(pos >= 0 && pos < Actividades.getInstancia().getActividades().size()) {
            RegistroActividad registroActividad1 = Actividades.getInstancia().getActividades().get(pos);
            //System.out.println("Persona encontrada: " + persona.getNombre()); // Depuración adicional
            vista.textArea1.setText("\n \tInformacion " +
                    "\n Nombre: "+registroActividad1.getNombre()+
                    "\n Descripcion: "+registroActividad1.getDescripcion()+
                    "\n Codigo: "+registroActividad1.getCodigo()+
                    "\n Cupo: "+registroActividad1.getCupo()+
                    "\n Reservado: "+registroActividad1.getReservar()+
                    "\n Costo: "+registroActividad1.getCosto()+
                    "\n Disponible: "+ registroActividad1.getDisponible()+
                    "\n Dias: "+ registroActividad1.getDias()+
                    "\n Clase: "+ registroActividad1.getClase()+
                    "\n Entrador : "+ registroActividad1.getEntrenador()+
                    "\n Hora incio: "+ registroActividad1.getHinicio()+
                    "\n Hora fin: "+ registroActividad1.getHfin()
            );

        } else {
            JOptionPane.showMessageDialog(null, "No hay informacion");
        }
    }
    private void inicializarComponentes(){
        model.setColumnCount(12);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre", "Descripcion", "Codigo","Cupo",
                "Reservado","Costo $","Disponible", "Dias",
                "Clase","Entrenador","Hora-Inicio","Hora-Fin"});
        vista.table1.setModel(model);
    }
    public void recuperarDatos(){
        try {
            Actividades actividades = new Actividades().recuperar("Actividades");
            cargarActividades(actividades);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }

    private void cargarActividades(Actividades actividades) {
        model.setRowCount(0);
        actividadAMap.clear();
        actividadReservadaAMap.clear();
        int rowIndex = 0;
        int reservedIndex = 0;
        for (RegistroActividad registroActividad : actividades.getActividades()) {
            if ("Si".equals(registroActividad.getReservar())) {
                model.addRow(new Object[]{
                        registroActividad.getNombre(),
                        registroActividad.getDescripcion(),
                        registroActividad.getCodigo(),
                        registroActividad.getCupo(),
                        registroActividad.getReservar(),
                        registroActividad.getCosto(),
                        registroActividad.getDisponible(),
                        registroActividad.getDias(),
                        registroActividad.getClase(),
                        registroActividad.getEntrenador(),
                        registroActividad.getHinicio(),
                        registroActividad.getHfin(),
                });
                actividadReservadaAMap.put(reservedIndex, rowIndex);
                reservedIndex++;
            }
            actividadAMap.put(rowIndex, rowIndex);
            rowIndex++;
        }
    }
    public void grabar(){
        actividades.grabar("Actividades");
    }
    private void Eliminar(int filaSeleccionada) {
        int response = JOptionPane.showConfirmDialog(null, "¿Desea eliminar esta actividad?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            int filaOriginal = actividadReservadaAMap.get(filaSeleccionada);
            actividades.eliminarActividad(filaOriginal);
            model.removeRow(filaSeleccionada);
            actividadAMap.remove(filaOriginal);
            actividadReservadaAMap.remove(filaSeleccionada);
            actualizarMapaIndices();
            grabar();
        }
    }

    private void actualizarMapaIndices() {
        Map<Integer, Integer> nuevoMapa = new HashMap<>();
        int reservedIndex = 0;
        for (Map.Entry<Integer, Integer> entry : actividadReservadaAMap.entrySet()) {
            nuevoMapa.put(reservedIndex, entry.getValue());
            reservedIndex++;
        }
        actividadReservadaAMap = nuevoMapa;
    }
}