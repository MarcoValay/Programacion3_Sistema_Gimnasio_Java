package controlador;

import modelo.Gimnasio;
import modelo.RegistroAdministrador;
import vista.ventanaAdministrador;


import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CtrlAdministrador implements ActionListener {
    private ventanaAdministrador vistaLogin;
    private CtrlGimnasio v1;
    private CtrlRegistroAdmin v2;

    //CtrlRegistroAdmin v3=null;
    ///private Administrador admin;
    private RegistroAdministrador admin;
    private Gimnasio gimnasio;

    public CtrlAdministrador(){
        this.vistaLogin=new ventanaAdministrador();
        this.admin=new RegistroAdministrador();
        this.gimnasio = new Gimnasio();
        vistaLogin.okBtnAdmin.addActionListener(this);
        vistaLogin.registrarBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vistaLogin.okBtnAdmin){
            if(CamposCompletados() && CamposValidos()){
                login();
            }else{
                JOptionPane.showMessageDialog(null,"Campos imcompletos");
            }
        }

        if(e.getSource()==vistaLogin.registrarBtn){
            v2=new CtrlRegistroAdmin();
            vistaLogin.dispose();
        }
    }

    public boolean CamposValidos() {

        if(!admin.CorreoCorrecto(vistaLogin.textFieldUsuario.getText())){
            JOptionPane.showMessageDialog(null,"Correo Incorrecto");
            return false;
        }
       /* if(!admin.ContraseniaCorrecta(new String(vistaLogin.passwordField.getPassword()))){
            JOptionPane.showMessageDialog(null,"Password minimo 4 caracteres");
            return false;
        }*/
        return true;
    }
    public boolean CamposCompletados(){
        if(vistaLogin.textFieldUsuario.getText().isEmpty()
                || vistaLogin.passwordField.toString().isEmpty()){
            //JOptionPane.showMessageDialog(null,"Campos imcompletos");
            return false;
        }else{
            return true;
        }
    }
    public void login() {
        String correo = vistaLogin.textFieldUsuario.getText();
        String contrasenia = new String(vistaLogin.passwordField.getPassword());
         //CtrlRegistroAdmin v3=new CtrlRegistroAdmin();

        if (verificarLogin(correo, contrasenia)) {
            JOptionPane.showMessageDialog(null, "Login exitoso");
            String cedula = obtenerCedula(correo);  // Obtener la cédula del usuario
            //SessionContext.setCedulaUsuario(cedula);
            gimnasio.setRuc(cedula);
            v1=new CtrlGimnasio(cedula);
            vistaLogin.dispose();
        } else {

            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
        }
    }

    private String obtenerCedula(String correo) {
        try (BufferedReader reader = new BufferedReader(new FileReader("Administradores"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datos = linea.split(",");
                String correoGuardado = datos[2];

                if (correoGuardado.equals(correo)) {
                    return datos[1];  // Retornar la cédula (segundo campo)
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al leer el archivo de usuarios");
            e.printStackTrace();
        }
        return null;
    }

    public boolean verificarLogin(String correo, String contrasenia) {
        try (BufferedReader reader = new BufferedReader(new FileReader("Administradores"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datos = linea.split(",");
                String correoGuardado = datos[2];
                String contraseniaGuardada = datos[3];

                if (correoGuardado.equals(correo) && contraseniaGuardada.equals(contrasenia)) {
                    return true;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al leer el archivo de usuarios");
            e.printStackTrace();
        }
        return false;
    }

}