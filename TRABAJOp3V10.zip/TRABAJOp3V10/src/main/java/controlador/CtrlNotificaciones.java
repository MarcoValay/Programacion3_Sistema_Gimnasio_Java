package controlador;

import modelo.Correo;
import modelo.Whatsapp;
import vista.ventanaNotificaciones;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class CtrlNotificaciones implements ActionListener {

   private ventanaNotificaciones vista;
   private Correo correo;
   private CtrlActividades v1;

   public CtrlNotificaciones(){
       this.vista = new ventanaNotificaciones();
       vista.enviarCorreoButton.addActionListener(this);
       vista.enviarWhastAppButton.addActionListener(this);
       vista.cancelarButton.addActionListener(this);
       //vista.cancelarButton1.addActionListener(this);
       vista.regresarButton.addActionListener(this);
       vista.adjuntarButton.addActionListener(this);
   }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser archi= new JFileChooser("./");
        archi.setFileSelectionMode(JFileChooser.FILES_ONLY);

        if(e.getSource()==vista.regresarButton){
            v1 = new CtrlActividades();
            vista.dispose();
        }
        if (e.getSource() == vista.adjuntarButton) {  // Evento para el segundo botón
            int returnVal = archi.showDialog(vista, "Recuperar");
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                try {
                    String recuperado = recuperar(archi.getSelectedFile().getAbsoluteFile().getPath());
                    vista.ruta.setText(recuperado);  // TextField adicional para el segundo archivo
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                JOptionPane.showMessageDialog(null, "Archivo  seleccionado");
            }
        }

        if(e.getSource()==vista.enviarCorreoButton){
            if(CamposCompletados2()){
                Correo correo = new Correo(vista.textDestinoCorreo.getText(),
                        vista.textAsuntoCorreo.getText(),
                        vista.textMensajeCorreo.getText()
                );
                if (!vista.ruta.getText().isEmpty()) {
                    correo.setArchivoAdjunto(vista.ruta.getText());
                }
                correo.envioDeCorreos();
            }else{
                JOptionPane.showMessageDialog(null,"Destino,asunto y mensaje estan vacios");
            }

        }
        if(e.getSource()==vista.cancelarButton){
            limpiarSeccionCorreo();
        }

       /* if(e.getSource()==vista.enviarWhastAppButton){

            Whatsapp wpp=new Whatsapp(vista.textDestinoWhastapp.getText().toString(),vista.textMensajeW.getText().toString());
            wpp.envioMensajeWpp();
        }*/
        if (e.getSource()==vista.enviarWhastAppButton){
            if(CamposCompletados()){
                Whatsapp wpp=new Whatsapp(vista.textDestinoCorreo.getText().toString(),vista.textMensajeCorreo.getText().toString());
                wpp.envioMensajeWpp();
            }else{
                JOptionPane.showMessageDialog(null,"Destino y mensaje estan vacios");
            }

        }
        if(e.getSource()==vista.cancelarButton1){
           //limpiarSeccionWpp();
        }
    }
    public boolean CamposCompletados() {
        if (vista.textDestinoCorreo.getText().isEmpty()
                || vista.textMensajeCorreo.getText().isEmpty()
        ) {
            return false;
        }
            return true;
    }

    public boolean CamposCompletados2() {
        if (vista.textDestinoCorreo.getText().isEmpty()
                || vista.textMensajeCorreo.getText().isEmpty()
                || vista.textAsuntoCorreo.getText().isEmpty()
        ) {
            return false;
        }
        return true;
    }
    public void limpiarSeccionCorreo(){
        vista.textDestinoCorreo.setText("");
        vista.textAsuntoCorreo.setText("");
        vista.textMensajeCorreo.setText("");
    }

//    public void limpiarSeccionWpp(){
//        vista.textMensajeW.setText("");
//        vista.textDestinoWhastapp.setText("");
//        vista.textField4.setText("");
//    }

    public String recuperar (String nombreArchivo) throws IOException {
        try {
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if (path.exists()) {
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                archivo.readObject();
                archivo.close();
            }
        } catch (ClassNotFoundException | IOException e) {
            System.out.println(e.getMessage());
        }
        System.out.println(nombreArchivo);
        return nombreArchivo;
    }
}
