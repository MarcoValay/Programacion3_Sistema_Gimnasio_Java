package controlador;

import vista.ventanaMantenimiento;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlMantenimiento implements ActionListener {

    private ventanaMantenimiento vista;


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
