package controlador;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.text.PDFTextStripper;
import vista.ventanaCrudsFacturas;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CtrlCudsFacturas implements ActionListener {
   private ventanaCrudsFacturas vista;
   private CtrlPagos v1;
    private DefaultTableModel model;
    private String archivoActualFactura = "";
    private String archivoActualRecibo = "";

   public CtrlCudsFacturas(){
       this.vista= new ventanaCrudsFacturas();
       vista.regresarButton.addActionListener(this);
       vista.leerButton.addActionListener(this);
       vista.buscarButton.addActionListener(this);
       vista.eliminarButton.addActionListener(this);
       vista.modificarButton.addActionListener(this);
       model = new DefaultTableModel();

       inicializarComponentes();
       cargarPDFs();

       vista.table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
           @Override
           public void valueChanged(ListSelectionEvent e) {
               if (!e.getValueIsAdjusting()) {
                   int filaSeleccionada = vista.table1.getSelectedRow();
                   if (filaSeleccionada != -1) {
                       //colocarNombres(filaSeleccionada);
                   }
               }
           }
       });
   }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.regresarButton){
            v1 = new CtrlPagos();
            vista.dispose();
        }
        if(e.getSource()==vista.leerButton){
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                String factura = (String) model.getValueAt(filaSeleccionada, 0);
                String recibo = (String) model.getValueAt(filaSeleccionada, 1);
                if (!factura.isEmpty()) {
                    mostrarContenidoPDFfactura(factura);
                }
                if (!recibo.isEmpty()) {
                    mostrarContenidoPDFrecibo(recibo);
                }
            }else {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione una factura o recibo de la tabla.");
            }
        }
        if(e.getSource()==vista.eliminarButton){
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                String factura = (String) model.getValueAt(filaSeleccionada, 0);
                String recibo = (String) model.getValueAt(filaSeleccionada, 1);
                eliminarPDF(factura);
                eliminarPDF(recibo);
                model.removeRow(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla lo que desea eliminar");
            }
        }
        if(e.getSource()==vista.modificarButton){
            boolean modified = false;
//            if (!archivoActualFactura.isEmpty()) {
//                guardarContenidoPDFfactura(archivoActualFactura, vista.textArea1.getText());
//            }
//            if (!archivoActualRecibo.isEmpty()) {
//                guardarContenidoPDFrecibo(archivoActualRecibo, vista.textArea2.getText());
//            }
//            if (modified) {
//                JOptionPane.showMessageDialog(vista, "Los datos se han modificado correctamente.", "Modificación exitosa", JOptionPane.INFORMATION_MESSAGE);
//            }
            if (!archivoActualFactura.isEmpty() || !archivoActualRecibo.isEmpty()) {
                guardarContenidoPDFfactura(archivoActualFactura, vista.textArea1.getText());
                guardarContenidoPDFrecibo(archivoActualRecibo, vista.textArea2.getText());
                JOptionPane.showMessageDialog(null, "Los datos se han modificado correctamente.");
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla" +
                        "\n Proceda a leer"+
                        "\n Edite los campos en el TextArea"+
                        "\n y luego modificar");
            }
        }

        if (e.getSource() == vista.buscarButton) {
            String nombreArchivo = vista.buscartextField.getText().trim();
            buscarPDF(nombreArchivo);
        }
    }

    private void inicializarComponentes() {
        model.setColumnCount(6);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Facturas", "Recibo"});
        vista.table1.setModel(model);
    }

    private void cargarPDFs() {

        String projectRoot = System.getProperty("user.dir");
        //C:\Users\ferna\OneDrive\Documentos\2Ciclo4\P3\ClasesP3
        // Ruta relativa a la carpeta que contiene los PDFs
        File folder = new File(projectRoot);
       //File folder = new File("ruta/al/directorio/de/pdfs"); // Cambia esta ruta al directorio donde están tus PDFs
        File[] listOfFiles = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".pdf"));

        List<String> facturas = new ArrayList<>();
        List<String> recibos = new ArrayList<>();

        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    if (esFactura(file)) {
                        facturas.add(file.getName());
                    } else if (esRecibo(file)) {
                        recibos.add(file.getName());
                    }
                }
            }
        }

        // Limpiar la tabla antes de agregar los nuevos datos
        model.setRowCount(0);

        // Agregar las facturas y recibos a la tabla
        int maxSize = Math.max(facturas.size(), recibos.size());
        for (int i = 0; i < maxSize; i++) {
            String factura = i < facturas.size() ? facturas.get(i) : "";
            String recibo = i < recibos.size() ? recibos.get(i) : "";
            model.addRow(new Object[]{factura, recibo});
        }
    }

    private boolean esFactura(File file) {
        // Implementa tu lógica para determinar si un archivo es una factura
        //return file.getName().toLowerCase().contains("Factura ");
        return file.getName().toLowerCase().startsWith("factura");
    }

    private boolean esRecibo(File file) {
        // Implementa tu lógica para determinar si un archivo es un recibo
        //return file.getName().toLowerCase().contains("Recibo ");
        return file.getName().toLowerCase().startsWith("recibo");
    }

    private void buscarPDF(String nombreArchivo) {
        for (int i = 0; i < model.getRowCount(); i++) {
            String factura = (String) model.getValueAt(i, 0);
            String recibo = (String) model.getValueAt(i, 1);
            if (nombreArchivo.equalsIgnoreCase(factura) || nombreArchivo.equalsIgnoreCase(recibo)) {
                vista.table1.setRowSelectionInterval(i, i);
                return;
            }
        }
    }

    public static String recuperar2(String nombreArchivo) {
        StringBuilder contenido = new StringBuilder();
        try {
            FileReader fr = new FileReader(nombreArchivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            while ((linea = br.readLine()) != null) {
                contenido.append(linea).append("\n");
            }

            br.close();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
        return contenido.toString();
    }

    private void mostrarContenidoPDFfactura(String nombreArchivo) {
        archivoActualFactura = nombreArchivo; // Actualiza el archivo actual de la factura
        String projectRoot = System.getProperty("user.dir");
        File file = new File(projectRoot, nombreArchivo);
        try {
            String contenido = leerPDFfactura(file);
            vista.textArea1.setText(contenido); // Asumiendo que tienes un JTextArea en tu vista llamado textArea
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarContenidoPDFrecibo(String nombreArchivo) {
        archivoActualRecibo = nombreArchivo; // Actualiza el archivo actual del recibo
        String projectRoot = System.getProperty("user.dir");
        File file = new File(projectRoot, nombreArchivo);
        try {
            String contenido = leerPDFrecibo(file);
            vista.textArea2.setText(contenido); // Asumiendo que tienes un JTextArea en tu vista llamado textArea
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String leerPDFfactura(File file) throws IOException {
        try (PDDocument document = PDDocument.load(file)) {
            PDFTextStripper pdfStripper = new PDFTextStripper();
            return pdfStripper.getText(document);
        }
    }
    private String leerPDFrecibo(File file) throws IOException {
        try (PDDocument document = PDDocument.load(file)) {
            PDFTextStripper pdfStripper = new PDFTextStripper();
            return pdfStripper.getText(document);
        }
    }

    private void guardarContenidoPDFfactura(String nombreArchivo, String contenido) {
        contenido = contenido.replace("\r", ""); // Eliminar caracteres de retorno de carro
       String projectRoot = System.getProperty("user.dir");
        File file = new File(projectRoot, nombreArchivo);
        try (PDDocument document = PDDocument.load(file)) {
            if (document.getNumberOfPages() > 0) {
                PDPage firstPage = document.getPage(0);
                PDRectangle mediaBox = firstPage.getMediaBox();
                PDPageContentStream contentStream = new PDPageContentStream(document, firstPage, PDPageContentStream.AppendMode.OVERWRITE, true, true);


                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 12);
                contentStream.setLeading(14.5f);
                contentStream.newLineAtOffset(25, mediaBox.getHeight() - 25);
                ///contentStream.newLineAtOffset(25, 725);

                String[] lines = contenido.split("\n");
                for (String line : lines) {
                    contentStream.showText(line);
                    contentStream.newLine();
                }

                contentStream.endText();
                contentStream.close();
                document.save(file);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void guardarContenidoPDFrecibo(String nombreArchivo, String contenido) {
        contenido = contenido.replace("\r", ""); // Eliminar caracteres de retorno de carro
       String projectRoot = System.getProperty("user.dir");
        File file = new File(projectRoot, nombreArchivo);
        try (PDDocument document = PDDocument.load(file)) {
            if (document.getNumberOfPages() > 0) {
                PDPage firstPage = document.getPage(0);
                PDRectangle mediaBox = firstPage.getMediaBox();
                PDPageContentStream contentStream = new PDPageContentStream(document, firstPage, PDPageContentStream.AppendMode.OVERWRITE, true, true);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 12);
                contentStream.setLeading(14.5f);
                contentStream.newLineAtOffset(25, mediaBox.getHeight() - 25);

                String[] lines = contenido.split("\n");
                for (String line : lines) {
                    contentStream.showText(line);
                    contentStream.newLine();
                }

                contentStream.endText();
                contentStream.close();
                document.save(file);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void eliminarPDF(String nombreArchivo) {
        if (nombreArchivo != null && !nombreArchivo.isEmpty()) {
            String projectRoot = System.getProperty("user.dir");
            File file = new File(projectRoot, nombreArchivo);
            if (file.exists()) {
                file.delete();
            }
        }
    }
}
