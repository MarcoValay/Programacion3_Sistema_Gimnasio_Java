package controlador;

import modelo.*;
import vista.ventanaGimnasio;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class CtrlGimnasio implements ActionListener {

    private ventanaGimnasio vista;
    private CtrlVentanaGeneral v1;
    private Duenio duenio;
    private Gimnasio gimnasio;
    private DefaultTableModel model;
    private String cedulaUsuario;

    public CtrlGimnasio(String cedulaUsuario){
        this.vista=new ventanaGimnasio();
        this.gimnasio =  new Gimnasio();
        duenio=Duenio.getInstancia();

        this.cedulaUsuario = cedulaUsuario;


        vista.cancelButton.addActionListener(this);
        vista.agregarGYMButton.addActionListener(this);
        vista.continuarButton.addActionListener(this);
        vista.ModificarButton.addActionListener(this);
//        vista.regresarButton.addActionListener(this);
        vista.eliminarButton.addActionListener(this);

        model=new DefaultTableModel();
        inicializarComponentes();
        cargar();

        vista.textRuc.setText(cedulaUsuario);

        // Añadir el ListSelectionListener a la tabla
        vista.tablaGYMs.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.tablaGYMs.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocarDatosEnCampos(filaSeleccionada);
                    }
                }
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.agregarGYMButton){
            if(CamposCompletados() && CamposValidos()){
                ingresoGYM();
                agregar();
            }else{
                JOptionPane.showMessageDialog(null,"Campos imcompletos");
            }
        }

//        if(e.getSource()==vista.regresarButton){
//            v1=new CtrlVentanaGeneral();
//            vista.dispose();
//        }

        if (e.getSource() == vista.ModificarButton) {
            int filaSeleccionada = vista.tablaGYMs.getSelectedRow();
            if (filaSeleccionada != -1) {
                if(CamposCompletados() && CamposValidos()){
                    Modificar(filaSeleccionada);
                }else{
                    JOptionPane.showMessageDialog(null,"Campos imcompletos");
                }
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla" +
                        "\n Edite los campos"+
                        "\n y luego modifique ");
            }

        }

        if (e.getSource() == vista.eliminarButton) {
            int filaSeleccionada = vista.tablaGYMs.getSelectedRow();
            if (filaSeleccionada != -1) {
                Eliminar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla lo que desea eliminar");
            }
        }

        if(e.getSource()==vista.cancelButton){
            limpiar();
        }
        if(e.getSource()==vista.continuarButton){
            v1=new CtrlVentanaGeneral();
            vista.dispose();
        }

    }

    public boolean CamposCompletados(){
        if(     vista.textNombre.getText().isEmpty()
                || vista.textDireccion.getText().isEmpty()
                || vista.textTelefono.getText().isEmpty()
                || vista.textFieldNomCalles.getText().isEmpty()
                || vista.textCodigo.toString().isEmpty()
                || vista.fechaInicio.getDate() == null
                || vista.fechafin.getDate() == null
                ){
            //|| vista.fechafin.getDate().toString().isEmpty()
            return false;
        }else{
            return true;
        }
    }

    public boolean CamposValidos(){

        if(!gimnasio.NombreCorrecto(vista.textNombre.getText())){
            JOptionPane.showMessageDialog(null,"Incorrecto, min 3 caracteres para el nombre ");
            return false;
        }
        if(!gimnasio.DireccionCorrecto(new String(vista.textDireccion.getText()))){
            JOptionPane.showMessageDialog(null,"Incorrecto, min 3 caracteres para la direccion");
            return false;
        }
        if (!gimnasio.TelefonoCorrecto(vista.textTelefono.getText())) {
            JOptionPane.showMessageDialog(null, "Teléfono no válido.", "ERROR", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if(!gimnasio.NombreCallesCorrecto(vista.textFieldNomCalles.getText())){
            JOptionPane.showMessageDialog(null,"Incorrecto, min 3 caracteres para la Ubicacion");
            return false;
        }
        if (!gimnasio.CodigoCorrecto(vista.textCodigo.getText())) {
            JOptionPane.showMessageDialog(null, "Incorrecto, min 3 caracteres para el codigo.");
            return false;
        }

        return true;
    }
    public void ingresoGYM() {
        String nombre = vista.textNombre.getText();
        String direccion = vista.textDireccion.getText();
        String telefono = vista.textTelefono.getText();
        String nombreCalles = vista.textFieldNomCalles.getText();
        String codigo = vista.textCodigo.getText();
        String ruc = cedulaUsuario;

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaInicioDate = vista.fechaInicio.getDate();
        Date fechaFinDate = vista.fechafin.getDate();
        String fechaInicioStr = dateFormat.format(fechaInicioDate);
        String fechaFinStr = dateFormat.format(fechaFinDate);
        String horaInicio = vista.comboBox1.getSelectedItem().toString();
        String horaFin = vista.comboBox2.getSelectedItem().toString();

        if (duenio.existeGimnasio(nombre, direccion, telefono, nombreCalles, codigo, ruc)) {
            JOptionPane.showMessageDialog(null, "El gimnasio ya está registrado.");
            return; // Salir del método si el gimnasio ya existe
        }

        Gimnasio gimnasio = new Gimnasio(nombre, direccion, telefono, nombreCalles, codigo, fechaInicioStr, fechaFinStr, horaInicio, horaFin, ruc);
        duenio.agregarGYM2(nombre, direccion, telefono, nombreCalles, codigo, fechaInicioStr, fechaFinStr, horaInicio, horaFin, ruc);
        grabar();
    }

    /*public void ingresoGYM(){
        Gimnasio gimnasio =new Gimnasio();
        gimnasio.setNombre(vista.textNombre.getText());
        gimnasio.setDireccion(vista.textNombre.getText());
        gimnasio.setTelefono(vista.textNombre.getText());
        gimnasio.setNombreCalles(vista.textFieldNomCalles.getText());
        gimnasio.setCodigo(vista.textCodigo.getText());
        *//*gimnasio.setFechaInicio(vista.FechaInicioPanel.toString());
        gimnasio.setFechaFin(vista.FEchaFinPanel.toString());*//*
        gimnasio.setHoraInicio(vista.comboBox1.getSelectedItem().toString());
        gimnasio.setHoraFin(vista.comboBox2.getSelectedItem().toString());
        //gimnasio.setRuc(vista.textRuc.getText());
        gimnasio.setRuc(cedulaUsuario);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaInicioDate = vista.fechaInicio.getDate();
        Date fechaFinDate = vista.fechafin.getDate();
        String fechaInicioStr = dateFormat.format(fechaInicioDate);
        String fechaFinStr = dateFormat.format(fechaFinDate);
        gimnasio.setFechaInicio(fechaInicioStr);
        gimnasio.setFechaFin(fechaFinStr);

        duenio.agregarGYM2(vista.textNombre.getText(),vista.textDireccion.getText(),vista.textTelefono.getText(),
                    vista.textFieldNomCalles.getText(),vista.textCodigo.getText(),fechaInicioStr,fechaFinStr,
                vista.comboBox1.getSelectedItem().toString(),vista.comboBox2.getSelectedItem().toString(),cedulaUsuario);
        grabar();
    }*/

    public void grabar(){
        duenio.grabar("GYMs");
    }

    public void limpiar(){
        vista.textNombre.setText("");
        vista.textDireccion.setText("");
        vista.textTelefono.setText("");
        vista.textFieldNomCalles.setText("");
        vista.textCodigo.setText("");
        vista.fechafin.setDate(null);
        vista.fechaInicio.setDate(null);
        vista.comboBox1.setSelectedItem(0);
        vista.comboBox2.setSelectedItem(0);
    }


    private void inicializarComponentes(){
        model.setColumnCount(10);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre","Direccion","Telefono","Ubicacion","Codigo","Fecha-Inicio","Fecha-Fin","Hora-inicio","Hora-Fin","Ruc"});
        vista.tablaGYMs.setModel(model);

    }
    private void agregar() {
        String nombre = vista.textNombre.getText();
        String direccion = vista.textDireccion.getText();
        String telefono = vista.textTelefono.getText();
        String nombreCalles = vista.textFieldNomCalles.getText();
        String codigo = vista.textCodigo.getText();
        String ruc = cedulaUsuario;

        // Verificar si el gimnasio ya existe en la tabla
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 0).equals(nombre) &&
                    model.getValueAt(i, 1).equals(direccion) &&
                    model.getValueAt(i, 2).equals(telefono) &&
                    model.getValueAt(i, 3).equals(nombreCalles) &&
                    model.getValueAt(i, 4).equals(codigo) &&
                    model.getValueAt(i, 9).equals(ruc)) {
                JOptionPane.showMessageDialog(null, "El gimnasio ya está registrado en la tabla.");
                return; // Salir del método si el gimnasio ya existe en la tabla
            }
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaInicioDate = vista.fechaInicio.getDate();
        Date fechaFinDate = vista.fechafin.getDate();
        String fechaInicioStr = dateFormat.format(fechaInicioDate);
        String fechaFinStr = dateFormat.format(fechaFinDate);
        String horaInicio = vista.comboBox1.getSelectedItem().toString();
        String horaFin = vista.comboBox2.getSelectedItem().toString();

        model.addRow(new Object[]{nombre, direccion, telefono, nombreCalles, codigo, fechaInicioStr, fechaFinStr, horaInicio, horaFin, ruc});
    }

/*    private void agregar(){
        String nombre = vista.textNombre.getText();
        String dir = vista.textDireccion.getText();
        String telf = vista.textTelefono.getText();

        String ubi = vista.textFieldNomCalles.getText();
        String cog = vista.textCodigo.getText();

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaInicioDate = vista.fechaInicio.getDate();
        Date fechaFinDate = vista.fechafin.getDate();

        String fechaInicioStr = dateFormat.format(fechaInicioDate);
        String fechaFinStr = dateFormat.format(fechaFinDate);

        String Hini = vista.comboBox1.getSelectedItem().toString();
        String Hfin = vista.comboBox2.getSelectedItem().toString();
        //String ruc = vista.textRuc.getText();
        String ruc = cedulaUsuario;

        model.addRow(new Object[]{nombre,dir,telf,ubi,cog,fechaInicioStr,fechaFinStr,Hini,Hfin,ruc});
    }*/


    public void cargar(){
        try {
            Duenio duenio1 = duenio.recuperar("GYMs");
            llenarTabla(duenio1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }

   /* private void cargarSocios() {
        try (BufferedReader reader = new BufferedReader(new FileReader("Administradores"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datos = linea.split(",");
                String ruc = datos[1];
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al leer el archivo de usuarios");
            e.printStackTrace();
        }
    }*/
    private void llenarTabla(Duenio duenio) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Gimnasio gimnasio1: duenio.getGimnasios()) {
            model.addRow(new Object[]{gimnasio1.getNombre(),gimnasio1.getDireccion(), gimnasio1.getTelefono(),
                    gimnasio1.getNombreCalles(),gimnasio1.getCodigo(),
                    gimnasio1.getFechaInicio(),gimnasio1.getFechaFin(),
                    gimnasio1.getHoraInicio(),gimnasio1.getHoraFin(), gimnasio1.getRuc()});
        }
    }

    private void colocarDatosEnCampos(int filaSeleccionada) {
        String nombreActividad = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 0);
        String direccion = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 1);
        String telefono = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 2);
        String nombreCalles = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 3);
        String codigo = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 4);
        String fechaIncio = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 5);
        String fechaFin = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 6);
        String hInicio = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 7);
        String hFin = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 8);
        String ruc = (String) vista.tablaGYMs.getValueAt(filaSeleccionada,9);


        vista.textNombre.setText(nombreActividad);
        vista.textDireccion.setText(direccion);
        vista.textTelefono.setText(telefono);

        vista.textFieldNomCalles.setText(nombreCalles);
        vista.textCodigo.setText(codigo);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaInicioDate = vista.fechaInicio.getDate();
        Date fechaFinDate = vista.fechafin.getDate();

        /*String fechaInicioStr = dateFormat.format(fechaInicioDate);
        String fechaFinStr = dateFormat.format(fechaFinDate);*/

        /*vista.fechaInicio.setDate(fechaInicioStr);
        vista.fechafin.setDate(fechaInicioDate);*/

        vista.fechaInicio.setDate(fechaInicioDate);
        vista.fechafin.setDate(fechaFinDate);

        vista.comboBox1.setSelectedItem(hInicio);
        vista.comboBox2.setSelectedItem(hFin);
        vista.textRuc.setText(ruc);

    }

    private void Modificar(int filaSeleccionada) {
        if (CamposCompletados() && CamposValidos()) {

            String nombreActividad = vista.textNombre.getText();
            String direccion = vista.textDireccion.getText();
            String telefono = vista.textTelefono.getText();
            String nombreCalles = vista.textFieldNomCalles.getText();
            String codigo = vista.textCodigo.getText();
//            String fechaIncio = (String) vista.tablaGYMs.getValueAt(filaSeleccionada, 5);
//            String fechaFin =vista.textNombre.getText();

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date fechaInicioDate = vista.fechaInicio.getDate();
            Date fechaFinDate = vista.fechafin.getDate();
            String fechaInicioStr = dateFormat.format(fechaInicioDate);
            String fechaFinStr = dateFormat.format(fechaFinDate);

            String hInicio = (String) vista.comboBox1.getSelectedItem();
            String hFin = (String) vista.comboBox2.getSelectedItem();
//            String ruc= vista.textRuc.getText();
            String ruc= vista.textRuc.getText();

            model.setValueAt(nombreActividad, filaSeleccionada, 0);
            model.setValueAt(direccion, filaSeleccionada, 1);
            model.setValueAt(telefono, filaSeleccionada, 2);
            model.setValueAt(nombreCalles, filaSeleccionada, 3);
            model.setValueAt(codigo, filaSeleccionada, 4);
            model.setValueAt(fechaInicioStr, filaSeleccionada, 5);
            model.setValueAt(fechaFinStr, filaSeleccionada, 6);
            model.setValueAt(hInicio, filaSeleccionada, 7);
            model.setValueAt(hFin, filaSeleccionada, 8);
            model.setValueAt(ruc, filaSeleccionada, 9);


            duenio.modificarGyms(filaSeleccionada,nombreActividad,direccion,telefono,
                                        nombreCalles,codigo,fechaInicioStr,fechaFinStr,
                                        hInicio, hFin,ruc);
            grabar();
        }
    }

    private void Eliminar(int filaSeleccionada) {
        int response = JOptionPane.showConfirmDialog(null, "¿Desea eliminar esta actividad?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
           duenio.eliminarGyms(filaSeleccionada);
            model.removeRow(filaSeleccionada);
            grabar();
        }
    }
}

