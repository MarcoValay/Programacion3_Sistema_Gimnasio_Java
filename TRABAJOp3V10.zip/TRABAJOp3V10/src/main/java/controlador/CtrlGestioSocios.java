package controlador;

import modelo.Persona;
import modelo.SociosGYM;
import vista.ventanaGestionSocios;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Comparator;

public class CtrlGestioSocios implements ActionListener {

    private ventanaGestionSocios vista;
    private ventanaGestionSocios ventanaGestionSocios;
    private CtrlVentanaGeneral v2;
    private CtrlRegistroMiembro v4;
    //private CtrlActividades v5;
    private DefaultTableModel model;
    private DefaultTableModel model2;
    private SociosGYM sociosGYM;
    private Persona persona;
    //private CtrlAccederAlGym v3;
    private CtrlActividades v3;

    public CtrlGestioSocios() {
        this.vista = new ventanaGestionSocios();
        this.persona = new Persona();
        model = new DefaultTableModel();
        model2 = new DefaultTableModel();
        vista.btnActualizar.addActionListener(this);
        //vista.btnBuscar.addActionListener(this);
        vista.btnCancel.addActionListener(this);
        vista.btnRegistrar.addActionListener(this);
        vista.buscarButton.addActionListener(this);
        vista.progActividadesMButton.addActionListener(this);

        vista.btnRegresar.addActionListener(this);
        vista.comboBox1.addActionListener(this);
//        vista.comboBox2.addActionListener(this);
        vista.eliminarButton.addActionListener(this);
        vista.seleccionarFotografiaButton.addActionListener(this);
        sociosGYM = SociosGYM.getInstancia();

        inicializarComponentes();
        rec();

        // Añadir el ListSelectionListener a la tabla
        vista.table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.table1.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        // vista.btnActiv.setEnabled(true);
                        colocarDatosEnCampos(filaSeleccionada);
                    }
                }
            }
        });
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnRegresar) {
            v2 = new CtrlVentanaGeneral();
            vista.dispose();
        }
        if (e.getSource() == vista.seleccionarFotografiaButton) {
            vista.setPathFotoUsuario();
        }
        if (e.getSource() == vista.btnRegistrar) {
            if (CamposCompletados() && CamposValidos()) {
                ingresoSocios2();
                agregar();
            } else {
                JOptionPane.showMessageDialog(null, "Campos imcompletos");
            }
        }

        if (e.getSource() == vista.btnActualizar) {
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                Modificar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla" +
                        "\n Edite los campos"+
                        "\n y luego modifique ");
            }
        }

        if (e.getSource() == vista.eliminarButton) {
            int filaSeleccionada = vista.table1.getSelectedRow();
            if (filaSeleccionada != -1) {
                Eliminar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null,"Seleccione la fila de la tabla lo que desea eliminar");
            }
        }
        if (e.getSource() == vista.buscarButton) {
            String BuscarDato = (String) JOptionPane.showInputDialog(null, "Buscar \n Ingrese el dato");
            int i = sociosGYM.buscarCed(BuscarDato);
            System.out.println(i);
            colocar(i);
        }
//        if (e.getSource() == vista.comboBox2) {
//            ordenarTabla(vista.comboBox2.getSelectedItem().toString());
//        }
        if (e.getSource() == vista.btnCancel) {
            limpiar();
        }
        if (e.getSource() == vista.progActividadesMButton) {
            v3 = new CtrlActividades();
            vista.dispose();
        }
    }


    public void limpiar() {
        vista.textNombre.setText("");
        vista.textApellido.setText("");
        vista.textCedula.setText("");
        vista.textId.setText("");
        vista.textDireccion.setText("");
        vista.textTelefono.setText("");
        vista.fechaInicio.setDate(null);
        vista.fechafin.setDate(null);
    }

    private void inicializarComponentes() {
        model.setColumnCount(7);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre", "Apellido", "Cedula", "Id", "Direccion", "Telefono", "Rol"});
        vista.table1.setModel(model);
    }

    private void agregar() {

        String cedula = vista.textCedula.getText();

        // Verificar si la cédula ya existe en la tabla
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 2).equals(cedula)) {
                JOptionPane.showMessageDialog(null, "La persona con esta cédula ya está registrada en la tabla.");
                return; // Salir del método si ya existe la persona en la tabla
            }
        }

        String nombre = vista.textNombre.getText();
        String apellido = vista.textApellido.getText();
        //String cedula = vista.textCedula.getText();
        String id = vista.textId.getText();
        String dir = vista.textDireccion.getText();
        String telf = vista.textTelefono.getText();
        String Rol = (String) vista.comboBox1.getSelectedItem();
        model.addRow(new Object[]{nombre, apellido, cedula, id, dir, telf, Rol});
    }


    public boolean CamposCompletados() {
        if (vista.textNombre.getText().isEmpty()
                || vista.textCedula.getText().isEmpty()
                || vista.textApellido.getText().isEmpty()
                || vista.textCedula.getText().isEmpty()
                || vista.textId.getText().isEmpty()
                || vista.textDireccion.getText().isEmpty()
                || vista.textTelefono.getText().isEmpty()) {
            return false;
        } else {
            return true;
        }
    }

    public void ingresoSocios2() {
        String cedula = vista.textCedula.getText();

        if (sociosGYM.existePersona(cedula)) {
            JOptionPane.showMessageDialog(null, "La persona con esta cédula ya está registrada.");
            return; // Salir del método si ya existe la persona
        }

        Persona nuevaPersona = new Persona();
        nuevaPersona.setNombre(vista.textNombre.getText());
        nuevaPersona.setApellido(vista.textApellido.getText());
        nuevaPersona.setCedula(vista.textCedula.getText());
        nuevaPersona.setCedula(vista.textId.getText());
        nuevaPersona.setDireccion(vista.textDireccion.getText());
        nuevaPersona.setTelefono(vista.textTelefono.getText());
        nuevaPersona.setRol((String) vista.comboBox1.getSelectedItem());
        sociosGYM.agregarPersona2(vista.textNombre.getText(), vista.textApellido.getText(),
                vista.textCedula.getText(), vista.textId.getText(), vista.textDireccion.getText(),
                vista.textTelefono.getText(), (String) vista.comboBox1.getSelectedItem()
        );
        grabar();
    }

    public boolean CamposValidos() {
        if (!persona.NombreCorrecto(vista.textNombre.getText())) {
            JOptionPane.showMessageDialog(null, "Incorrecto, min 3 caracteres para el nombre ");
            return false;
        }
        if (!persona.ApellidoCorrecto(new String(vista.textApellido.getText()))) {
            JOptionPane.showMessageDialog(null, "Incorrecto, min 3 caracteres para el apellido");
            return false;
        }
        if (!persona.CedulaCorrecta(vista.textCedula.getText())) {
            JOptionPane.showMessageDialog(null, "Cedula Incorrecta");
            return false;
        }
        if (!persona.DireccionCorrecta(vista.textDireccion.getText())) {
            JOptionPane.showMessageDialog(null, "Minimo 4 caracteres para la direccion");
            return false;
        }
        if (!persona.TelefonoCorrecto(vista.textTelefono.getText())) {
            JOptionPane.showMessageDialog(null, "Teléfono no válido.", "ERROR", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public void grabar() {
        sociosGYM.grabar("SociosGYM");
    }

    public void rec() {
        try {
            SociosGYM sociosGYM1 = sociosGYM.recuperar("SociosGYM");
            llenarTabla(sociosGYM1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null, "Datos Recuperados");
    }

    private void llenarTabla(SociosGYM sociosGYM) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Persona persona : sociosGYM.getPersonas()) {
            model.addRow(new Object[]{persona.getNombre(), persona.getApellido(),
                    persona.getCedula(), persona.getId(), persona.getDireccion(),
                    persona.getTelefono(), persona.getRol()});
        }
    }


    private void colocarDatosEnCampos(int filaSeleccionada) {
        String nombre = (String) vista.table1.getValueAt(filaSeleccionada, 0);
        String apellido = (String) vista.table1.getValueAt(filaSeleccionada, 1);
        String cedula = (String) vista.table1.getValueAt(filaSeleccionada, 2);
        String id = (String) vista.table1.getValueAt(filaSeleccionada, 3);
        String direccion = (String) vista.table1.getValueAt(filaSeleccionada, 4);
        String telefono = (String) vista.table1.getValueAt(filaSeleccionada, 5);
        String rol = (String) vista.table1.getValueAt(filaSeleccionada, 6);

        vista.textNombre.setText(nombre);
        vista.textApellido.setText(apellido);
        vista.textCedula.setText(cedula);
        vista.textId.setText(id);
        vista.textDireccion.setText(direccion);
        vista.textTelefono.setText(telefono);
        vista.comboBox1.setSelectedItem(rol);

    }

    private void Modificar(int filaSeleccionada) {
        if (CamposCompletados() && CamposValidos()) {

            String nombre = vista.textNombre.getText();
            String apellido = vista.textApellido.getText();
            String cedula = vista.textCedula.getText();
            String id = vista.textId.getText();
            String direccion = vista.textDireccion.getText();
            String telefono = vista.textTelefono.getText();
            String rol = (String) vista.comboBox1.getSelectedItem();


            model.setValueAt(nombre, filaSeleccionada, 0);
            model.setValueAt(apellido, filaSeleccionada, 1);
            model.setValueAt(cedula, filaSeleccionada, 2);
            model.setValueAt(id, filaSeleccionada, 3);
            model.setValueAt(direccion, filaSeleccionada, 4);
            model.setValueAt(telefono, filaSeleccionada, 5);
            model.setValueAt(rol, filaSeleccionada, 6);


            sociosGYM.modificarSocio(filaSeleccionada, nombre, apellido, cedula, id, direccion, telefono, rol);
            grabar();
        }
    }

    private void Eliminar(int filaSeleccionada) {
        int response = JOptionPane.showConfirmDialog(null, "¿Desea eliminar este socio?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            sociosGYM.eliminarSocio(filaSeleccionada);
            model.removeRow(filaSeleccionada);
            grabar();
        }
    }

    public void colocar(int pos) {
        if (pos >= 0 && pos < SociosGYM.getInstancia().getPersonas().size()) {
            Persona persona = SociosGYM.getInstancia().getPersonas().get(pos);
            System.out.println("Persona encontrada: " + persona.getNombre()); // Depuración adicional

            vista.textArea1.setText("\n \tInformacion Socio " +
                    "\n Nombre: " + persona.getNombre() +
                    "\n Apellido: " + persona.getApellido() +
                    "\n Cedula: " + persona.getCedula() +
                    "\n Id: " + persona.getId() +
                    "\n Direccion: " + persona.getDireccion() +
                    "\n Telefono: " + persona.getTelefono() +
                    "\n Rol: " + persona.getRol());

        } else {
            JOptionPane.showMessageDialog(null, "Persona no encontrada");
        }
    }

    private void ordenarTabla(String criterio) {
        Comparator<Persona> comparador = null;
        switch (criterio) {
            case "Nombre":
                comparador = Comparator.comparing(Persona::getNombre, String.CASE_INSENSITIVE_ORDER);
                break;
            case "Apellido":
                comparador = Comparator.comparing(Persona::getApellido, String.CASE_INSENSITIVE_ORDER);
                break;
            case "Cedula":
                comparador = Comparator.comparing(Persona::getCedula);
                break;
            case "Id":
                comparador = Comparator.comparingInt(p -> Integer.parseInt(p.getId()));
                break;
            case "Direccion":
                comparador = Comparator.comparing(Persona::getDireccion, String.CASE_INSENSITIVE_ORDER);
                break;
            case "Telefono":
                comparador = Comparator.comparing(Persona::getTelefono);
                break;
            case "Rol":
                comparador = Comparator.comparing(Persona::getRol);
                break;
        }
        if (comparador != null) {
            sociosGYM.ordenarPersonas(comparador);
            llenarTabla(sociosGYM);
        }
    }
}
