package controlador;

import modelo.*;
import vista.ventanaGestionEquiposYEspacios;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CtrlEquiposYEspacios implements ActionListener {

    private ventanaGestionEquiposYEspacios vista;
    private CtrlVentanaGeneral v7;
    private DefaultTableModel model;
    private DefaultTableModel model2;
    private DefaultTableModel model3;
    private DefaultTableModel model4;
    private DefaultTableModel model5;
    private DefaultTableModel model6;
    private DefaultTableModel model7;
    private Duenio duenio;
    private GestionEquipo gestionEquipo;
    private Equipo equipo;
    private GestionMaquinas gestionMaquinas;
    private Maquinas maquinas;
    private CtrlMantenimiento v8;
    public CtrlEquiposYEspacios(){
        this.vista=new ventanaGestionEquiposYEspacios();
        vista.btnregresar.addActionListener(this);
        duenio=Duenio.getInstancia();
        gestionEquipo = GestionEquipo.getInstancia();
        this.equipo = new Equipo();
        gestionMaquinas = GestionMaquinas.getInstancia();
        this.maquinas = new Maquinas();
        vista.darMantenimientoButton.addActionListener(this);
        //vista.historialDeMantemientosButton.addActionListener(this);
        vista.eliminarButton2.addActionListener(this);

        model = new DefaultTableModel();
        inicializarComponentes1();
        cargar();
        vista.tableRegistroEquipo.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.tableRegistroEquipo.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocarDatosEquipo(filaSeleccionada);
                    }
                }
            }
        });

        model2 = new DefaultTableModel();
        inicializarComponentes2();
        recuperarEquipos();
        vista.buscarEquipo.addActionListener(this);
        vista.registrarEquipo.addActionListener(this);
        vista.actualizarEquipo.addActionListener(this);
        vista.eliminarEquipo.addActionListener(this);
        //-------------------------------------------------------
        model3 = new DefaultTableModel();
        inicializarComponentes3();
        cargar3();
        vista.comboBoxMaqTipo.addActionListener(this);
        vista.comboBoxMaqNom1.addActionListener(this);
        vista.comboBoxMaqNom2.addActionListener(this);
        vista.comboBoxMaqNom3.addActionListener(this);
        vista.comboBoxMaqNom4.addActionListener(this);
        vista.comboBoxMaqNom5.addActionListener(this);
        vista.tableMaqRegistro.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int filaSeleccionada = vista.tableMaqRegistro.getSelectedRow();
                    if (filaSeleccionada != -1) {
                        colocarDatosMaquinas(filaSeleccionada);
                    }
                }
            }
        });

        model4 = new DefaultTableModel();
        inicializarComponentes4();
        recuperarMaquinas();
        vista.buscarMaq.addActionListener(this);
        vista.registrarMaq.addActionListener(this);
        vista.actualizarMaq.addActionListener(this);
        vista.eliminarMaq.addActionListener(this);
        vista.limpiarMap.addActionListener(this);
        //------------------------------------------------

        model5 = new DefaultTableModel();
        inicializarComponentes5();
        recuperarEquiposMantenimiento();

        model6 = new DefaultTableModel();
        inicializarComponentes6();
        recuperarMaquinasMatenimiento();

        model7 = new DefaultTableModel();
        inicializarComponentes7();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnregresar){
            v7=new CtrlVentanaGeneral();
            vista.dispose();
        }
        if(e.getSource()==vista.registrarEquipo){
            int filaSeleccionada = vista.tableGimnasioEquipo.getSelectedRow();
            if(CamposCompletados()&& CamposValidos()){
                if (filaSeleccionada != -1) {
                    agregar(filaSeleccionada);
                }else {
                    JOptionPane.showMessageDialog(null,"Seleccione un gimnasio" );
                }
            }else{
                JOptionPane.showMessageDialog(null,"Campos imcompletos");
            }
        }
        if (e.getSource() == vista.eliminarEquipo) {
            int filaSeleccionada = vista.tableRegistroEquipo.getSelectedRow();
            if (filaSeleccionada != -1) {
                Eliminar(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null," Eliminar \n Seleccione una fila de la tabla de registro ");
            }
        }

        if (e.getSource() == vista.actualizarEquipo) {
            int filaSeleccionada = vista.tableRegistroEquipo.getSelectedRow();
            if (filaSeleccionada != -1) {
                if(CamposCompletados() && CamposValidos()){
                    Modificar(filaSeleccionada);
                }else{
                    JOptionPane.showMessageDialog(null,"Campos imcompletos");
                }
            }else{
                JOptionPane.showMessageDialog(null,"Actualizar \n Seleccione la fila de la tabla de registro ");
            }
        }
        if (e.getSource() == vista.buscarEquipo) {
            String BuscarDato = (String) JOptionPane.showInputDialog(null, "Ingrese la nombre o ID");
            int i = gestionEquipo.buscarCed(BuscarDato);
            System.out.println(i);
            colocarEquipo(i);
        }
        if(e.getSource()==vista.limpiarEquipo){
            limpiar();
        }
//------------------------------------------------------------
        if(e.getSource()==vista.comboBoxMaqTipo){
            String opc = (String) vista.comboBoxMaqTipo.getSelectedItem();
            habilitar(opc);
        }
        if(e.getSource()==vista.comboBoxMaqNom1){
            String opc = (String) vista.comboBoxMaqNom1.getSelectedItem();
            DescripcionMaquinas(opc);
        }
        if(e.getSource()==vista.comboBoxMaqNom2){
            String opc = (String) vista.comboBoxMaqNom2.getSelectedItem();
            DescripcionMaquinas(opc);
        }
        if(e.getSource()==vista.comboBoxMaqNom3){
            String opc = (String) vista.comboBoxMaqNom3.getSelectedItem();
            DescripcionMaquinas(opc);
        }
        if(e.getSource()==vista.comboBoxMaqNom4){
            String opc = (String) vista.comboBoxMaqNom4.getSelectedItem();
            DescripcionMaquinas(opc);
        }
        if(e.getSource()==vista.comboBoxMaqNom5){
            String opc = (String) vista.comboBoxMaqNom5.getSelectedItem();
            DescripcionMaquinas(opc);
        }
        if(e.getSource()==vista.registrarMaq){
            int filaSeleccionada = vista.tablaGimnasiosMaq.getSelectedRow();

            if(CamposCompletadosMaq()){
                if (filaSeleccionada != -1) {
                    agregarMaquinas(filaSeleccionada);
                }else {
                    JOptionPane.showMessageDialog(null,"Seleccione un gimnasio" );
                }
            }else{
                JOptionPane.showMessageDialog(null,"Campos imcompletos");
            }
        }
        if (e.getSource() == vista.actualizarMaq) {
            int filaSeleccionada = vista.tableMaqRegistro.getSelectedRow();
            if (filaSeleccionada != -1) {
                if(CamposCompletadosMaq()){
                    ModificaMaq(filaSeleccionada);
                }else{
                    JOptionPane.showMessageDialog(null,"Campos imcompletos");
                }
            }else{
                JOptionPane.showMessageDialog(null,"Actualizar \n Seleccione la fila de la tabla de registro ");
            }
        }
        if (e.getSource() == vista.eliminarMaq) {
            int filaSeleccionada = vista.tableMaqRegistro.getSelectedRow();
            if (filaSeleccionada != -1) {
                EliminarMaquinas(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null," Eliminar \n Seleccione una fila de la tabla de registro ");
            }
        }
        if (e.getSource() == vista.buscarMaq) {
            String BuscarDato = (String) JOptionPane.showInputDialog(null, "Ingrese la nombre o ID");
            int i = gestionMaquinas.buscarCed(BuscarDato);
            System.out.println(i);
            colocarMaquinas(i);
        }
        if(e.getSource()==vista.limpiarMap){
            limpiarMaq();
        }
        if(e.getSource()==vista.darMantenimientoButton){
            int filaSeleccionada = vista.tableMaqRegistro.getSelectedRow();
            int filaSeleccionada2 = vista.tableRegistroEquipo.getSelectedRow();
            if (filaSeleccionada != -1 || filaSeleccionada2 !=-1) {
                //EliminarMaquinas(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null," Seleccione una fila para dar mantenimiento ");
            }
        }
        if(e.getSource()==vista.eliminarButton2){
            int filaSeleccionada = vista.tableMaqRegistro.getSelectedRow();
            if (filaSeleccionada != -1) {
                EliminarMaquinas(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null," Eliminar \n Seleccione una fila de la tabla de registro ");
            }
            int filaSeleccionadaw = vista.tableRegistroEquipo.getSelectedRow();
            if (filaSeleccionadaw != -1) {
                Eliminar(filaSeleccionadaw);
            }else{
                JOptionPane.showMessageDialog(null," Eliminar \n Seleccione una fila de la tabla de registro ");
            }
        }
//        if(e.getSource()==vista.historialDeMantemientosButton){
//            v8 = new CtrlMantenimiento();
//            vista.dispose();
//        }

    }

    //Empieza CRUDS Equipos
    private void inicializarComponentes1(){
        model.setColumnCount(2);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Ubicaion"," Codigo"});
        vista.tableGimnasioEquipo.setModel(model);
    }
    public void cargar(){
        try {
            Duenio duenio1 = duenio.recuperar("GYMs");
            llenarTabla(duenio1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }
    private void llenarTabla(Duenio duenio) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Gimnasio gimnasio1: duenio.getGimnasios()) {
            model.addRow(new Object[]{
                    gimnasio1.getNombreCalles(),gimnasio1.getCodigo(),
                    });
        }
    }
    private void inicializarComponentes2(){
        model2.setColumnCount(9);
        model2.setRowCount(0);
        model2.setColumnIdentifiers(new Object[]{"Tipo"," Nombre","Descripcion", " Fecha de adquisicion","Codigo","Estado"," Fecha de Mantenimiento","Ubicaion"," Codigo"});
        vista.tableRegistroEquipo.setModel(model2);
    }
    private void agregar(int filasSelecionada) {
        String tipo= (String) vista.comboBoxEquipoTipo.getSelectedItem();
        String nombre = vista.EquipoNombre.getText();
        String descripcion = vista.EquipoDescripcion.getText();
        //String fAdq = vista.fechaAdEquipo.getDateFormatString() ;
        String codigo = vista.EquipoCodigo.getText();
        String estado = (String) vista.comboBoxEquipoEstado.getSelectedItem();
        //String fMan = vista.fechaMateniminetoEquipo.getDateFormatString();

        String ubi = (String) vista.tableGimnasioEquipo.getValueAt(filasSelecionada,0);
        String codGym= (String) vista.tableGimnasioEquipo.getValueAt(filasSelecionada,1);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaAdquisicion = vista.fechaAdEquipo.getDate();
        Date fechaMantenimiento = vista.fechaMateniminetoEquipo.getDate();

        String fechaAdq = dateFormat.format(fechaAdquisicion);
        String fechaMant = dateFormat.format(fechaMantenimiento);

        gestionEquipo.agregarEquipo(tipo,nombre, descripcion,fechaAdq,codigo,estado,fechaMant,ubi,codGym);
        grabarEquipos();
        model2.addRow(new Object[]{tipo,nombre, descripcion,fechaAdq,codigo,estado,fechaMant,ubi,codGym});
    }
    public void grabarEquipos(){
        gestionEquipo.grabar("Equipos");
    }
    public boolean CamposCompletados(){
        if(     vista.comboBoxEquipoTipo.getSelectedItem().toString().isEmpty()
                || vista.EquipoNombre.getText().isEmpty()
                || vista.EquipoDescripcion.getText().isEmpty()
                || vista.EquipoCodigo.getText().isEmpty()
                ||  vista.comboBoxEquipoEstado.getSelectedItem().toString().isEmpty()
                || vista.fechaAdEquipo.getDate() == null
                || vista.fechaMateniminetoEquipo.getDate() == null
        ){
            return false;
        }else{
            return true;
        }
    }
    public boolean CamposValidos(){
        if(!equipo.NombreCorrecto(vista.EquipoNombre.getText())){
            JOptionPane.showMessageDialog(null,"Incorrecto, min 3 caracteres para el nombre ");
            return false;
        }
        if(!equipo.DescripcionCorrecta(new String(vista.EquipoDescripcion.getText()))){
            JOptionPane.showMessageDialog(null,"Incorrecto, min 3 caracteres para la descripcion");
            return false;
        }
        if (!equipo.CodigoCorrecto(vista.EquipoCodigo.getText())) {
            JOptionPane.showMessageDialog(null, "Incorrecto, min 3 caracteres para el codigo.");
            return false;
        }
        return true;
    }

    private void colocarDatosEquipo(int filaSeleccionada) {
        String tipo = (String) vista.tableRegistroEquipo.getValueAt(filaSeleccionada, 0);
        String nombreActividad = (String) vista.tableRegistroEquipo.getValueAt(filaSeleccionada, 1);
        String descripcion = (String) vista.tableRegistroEquipo.getValueAt(filaSeleccionada, 2);
        String fechaAdq = (String) vista.tableRegistroEquipo.getValueAt(filaSeleccionada, 3);
        String codigo = (String) vista.tableRegistroEquipo.getValueAt(filaSeleccionada, 4);
        String estado = (String) vista.tableRegistroEquipo.getValueAt(filaSeleccionada, 5);
        String fechaMant = (String) vista.tableRegistroEquipo.getValueAt(filaSeleccionada, 6);

        vista.comboBoxEquipoTipo.setSelectedItem(tipo);
        vista.EquipoNombre.setText(nombreActividad);
        vista.EquipoDescripcion.setText(descripcion);
        vista.EquipoCodigo.setText(codigo);
        vista.comboBoxEquipoEstado.setSelectedItem(estado);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaInicioDate = vista.fechaAdEquipo.getDate();
        Date fechaFinDate = vista.fechaMateniminetoEquipo.getDate();

        vista.fechaAdEquipo.setDate(fechaInicioDate);
        vista.fechaMateniminetoEquipo.setDate(fechaFinDate);
    }

    private void Modificar(int filaSeleccionada) {
        if (CamposCompletados() && CamposValidos()) {

            String tipo= (String) vista.comboBoxEquipoTipo.getSelectedItem();
            String nombre = vista.EquipoNombre.getText();
            String descripcion = vista.EquipoDescripcion.getText();
            String codigo = vista.EquipoCodigo.getText();
            String estado = (String) vista.comboBoxEquipoEstado.getSelectedItem();

            String ubi =null;
           // String codGym= (String) vista.tableGimnasioEquipo.getValueAt(filaSeleccionada,1);
            String codGym= null;

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date fechaAdquisicion = vista.fechaAdEquipo.getDate();
            Date fechaMantenimiento = vista.fechaMateniminetoEquipo.getDate();

            String fechaAdq = dateFormat.format(fechaAdquisicion);
            String fechaMant = dateFormat.format(fechaMantenimiento);

            model2.setValueAt(tipo, filaSeleccionada, 0);
            model2.setValueAt(nombre, filaSeleccionada, 1);
            model2.setValueAt(descripcion, filaSeleccionada, 2);
            model2.setValueAt(fechaAdq, filaSeleccionada, 3);
            model2.setValueAt(codigo, filaSeleccionada, 4);
            model2.setValueAt(estado, filaSeleccionada, 5);
            model2.setValueAt(fechaMant, filaSeleccionada, 6);
            //model2.setValueAt(ubi, filaSeleccionada, 7);
            //model2.setValueAt(codGym, filaSeleccionada, 8);

            gestionEquipo.modificarEquipo(filaSeleccionada,tipo,nombre,descripcion,fechaAdq,codigo,estado,fechaMant,ubi,codGym);
            grabarEquipos();
        }
    }
    private void Eliminar(int filaSeleccionada) {
        int response = JOptionPane.showConfirmDialog(null, "¿Desea eliminar esta actividad?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            gestionEquipo.eliminarEquipo(filaSeleccionada);
            model2.removeRow(filaSeleccionada);
            grabarEquipos();
        }
    }
    public void colocarEquipo(int pos) {
        if (pos >= 0 && pos < GestionEquipo.getInstancia().getEquipos().size()) {
            Equipo equipo1 = GestionEquipo.getInstancia().getEquipos().get(pos);

            vista.textArea1.setText("\n \tInformacion Equipo" +
                    "\n Tipo " + equipo1.getTipo()+
                    "\n Nombre: " +equipo1.getNombre()+
                    "\n Apellido: " +equipo1.getDescripcion()+
                    "\n Cedula: " + equipo1.getFechadeAdquisicion()+
                    "\n Codigo: " + equipo1.getCodigo()+
                    "\n Estado: " +equipo1.getEstado()+
                    "\n Fecha de Mantenimiento: " +equipo1.getFechadeMantenimiento()+
                    "\n Ubicacion: " +equipo1.getUbicaionGym()+
                    "\n Codigo:" +equipo1.getCodigoGym());

        } else {
            JOptionPane.showMessageDialog(null, "Equipo no encontrada");
        }
    }

    public void limpiar(){
        vista.comboBoxEquipoEstado.setSelectedItem(0);
        vista.EquipoNombre.setText("");
        vista.EquipoDescripcion.setText("");
        vista.fechaAdEquipo.setDate(null);
        vista.EquipoCodigo.setText("");
        vista.comboBoxEquipoEstado.setSelectedItem(0);
        vista.fechaMateniminetoEquipo.setDate(null);
        vista.textArea1.setText("");
    }
    public void recuperarEquipos() {
        try {
            GestionEquipo gestionEquipo1 = gestionEquipo.recuperarEquipos("Equipos");
            llenarTablaDeEquipos(gestionEquipo1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        //JOptionPane.showMessageDialog(null, "Datos Recuperados");
    }

    private void llenarTablaDeEquipos(GestionEquipo gestionEquipo1) {
        model2.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Equipo equipo1 : gestionEquipo1.getEquipos()) {
            model2.addRow(new Object[]{
                    equipo1.getTipo(),
                    equipo1.getNombre(),
                    equipo1.getDescripcion(),
                    equipo1.getFechadeAdquisicion(),
                    equipo1.getCodigo(),
                    equipo1.getEstado(),
                    equipo1.getFechadeMantenimiento(),
                    equipo1.getUbicaionGym(),
                    equipo1.getCodigoGym()
            });
        }
    }
    //Termina CRUDs equipos
    //------------------------------------------------------------------------------------------------------------------------------------
    //Empieza manejo CRUDS maquinas
    private void inicializarComponentes3(){
        model3.setColumnCount(2);
        model3.setRowCount(0);
        model3.setColumnIdentifiers(new Object[]{"Ubicaion"," Codigo"});
        vista.tablaGimnasiosMaq.setModel(model3);
    }
    public void cargar3(){
        try {
            Duenio duenio1 = duenio.recuperar("GYMs");
            llenarTabla3(duenio1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        //JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }
    private void llenarTabla3(Duenio duenio) {
        model3.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Gimnasio gimnasio1: duenio.getGimnasios()) {
            model3.addRow(new Object[]{
                    gimnasio1.getNombreCalles(),gimnasio1.getCodigo(),
            });
        }
    }
    private void inicializarComponentes4(){
        model4.setColumnCount(9);
        model4.setRowCount(0);
        model4.setColumnIdentifiers(new Object[]{"Tipo"," Nombre","Descripcion", " Fecha de adquisicion","Codigo","Estado"," Fecha de Mantenimiento","Ubicaion"," Codigo"});
        vista.tableMaqRegistro.setModel(model4);
    }

    public  void habilitar(String opc){
        if("Máquinas de Cardio".equals(opc)){
            vista.comboBoxMaqNom1.setEnabled(true);
            vista.comboBoxMaqNom2.setEnabled(false);
            vista.comboBoxMaqNom3.setEnabled(false);
            vista.comboBoxMaqNom4.setEnabled(false);
            vista.comboBoxMaqNom5.setEnabled(false);
        }
        if("Máquinas de Pesas".equals(opc)){
            vista.comboBoxMaqNom2.setEnabled(true);
            vista.comboBoxMaqNom1.setEnabled(false);
            vista.comboBoxMaqNom3.setEnabled(false);
            vista.comboBoxMaqNom4.setEnabled(false);
            vista.comboBoxMaqNom5.setEnabled(false);
        }
        if("Máquinas de Cable".equals(opc)){
            vista.comboBoxMaqNom3.setEnabled(true);
            vista.comboBoxMaqNom1.setEnabled(false);
            vista.comboBoxMaqNom2.setEnabled(false);
            vista.comboBoxMaqNom4.setEnabled(false);
            vista.comboBoxMaqNom5.setEnabled(false);
        }
        if("Máquinas de Abdominales".equals(opc)){
            vista.comboBoxMaqNom4.setEnabled(true);
            vista.comboBoxMaqNom1.setEnabled(false);
            vista.comboBoxMaqNom2.setEnabled(false);
            vista.comboBoxMaqNom3.setEnabled(false);
            vista.comboBoxMaqNom5.setEnabled(false);
        }
        if("Máquinas de Funcionalidad".equals(opc)){
            vista.comboBoxMaqNom5.setEnabled(true);
            vista.comboBoxMaqNom1.setEnabled(false);
            vista.comboBoxMaqNom2.setEnabled(false);
            vista.comboBoxMaqNom3.setEnabled(false);
            vista.comboBoxMaqNom4.setEnabled(false);
        }
    }

    public void DescripcionMaquinas(String opc) {
        //1
        if ("Cintas de correr".equals(opc)) {
            vista.textMaqDescripcion.setText("Para correr o caminar.");
            vista.textMaqCodigo.setText("101");
        }
        if ("Bicicletas estáticas".equals(opc)) {
            vista.textMaqDescripcion.setText("Pueden ser verticales o reclinadas.");
            vista.textMaqCodigo.setText("102");
        }
        if ("Elíptica".equals(opc)) {
            vista.textMaqDescripcion.setText("Simulan una combinación de correr y escalar.");
            vista.textMaqCodigo.setText("103");
        }
        if ("Máquinas de remo".equals(opc)) {
            vista.textMaqDescripcion.setText("Para ejercicios de cuerpo completo que simulan el remo en el agua.");
            vista.textMaqCodigo.setText("104");
        }
        if ("Escaladoras".equals(opc)) {
            vista.textMaqDescripcion.setText("Para simular subir escaleras.");
            vista.textMaqCodigo.setText("105");
        }
        //2
        if ("Máquinas de prensa de pecho".equals(opc)) {
            vista.textMaqDescripcion.setText("Para trabajar los músculos del pecho.");
            vista.textMaqCodigo.setText("201");
        }
        if ("Máquinas de jalón al pecho".equals(opc)) {
            vista.textMaqDescripcion.setText("Para trabajar la espalda.");
            vista.textMaqCodigo.setText("202");
        }
        if ("Máquinas de extensión de piernas".equals(opc)) {
            vista.textMaqDescripcion.setText("Para los cuádriceps.");
            vista.textMaqCodigo.setText("203");
        }
        if ("Máquinas de curl de piernas".equals(opc)) {
            vista.textMaqDescripcion.setText(" Para los isquiotibiales.");
            vista.textMaqCodigo.setText("204");
        }
        if ("Máquinas de prensa de pierna".equals(opc)) {
            vista.textMaqDescripcion.setText("Para trabajar los músculos de las piernas y glúteos.");
            vista.textMaqCodigo.setText("205");
        }
        if ("Máquinas de aducción y abducción de cadera".equals(opc)) {
            vista.textMaqDescripcion.setText("Para los músculos de la cadera.");
            vista.textMaqCodigo.setText("206");
        }
        //3
        if ("Torres de cable ajustables".equals(opc)) {
            vista.textMaqDescripcion.setText("Permiten una amplia variedad de ejercicios para diferentes grupos musculares.");
            vista.textMaqCodigo.setText("301");
        }
        if ("Máquinas de polea alta".equals(opc)) {
            vista.textMaqDescripcion.setText("Para ejercicios de jalón al pecho y tríceps.");
            vista.textMaqCodigo.setText("302");
        }
        if ("Máquinas de polea baja".equals(opc)) {
            vista.textMaqDescripcion.setText("Para ejercicios de remo y bíceps.");
            vista.textMaqCodigo.setText("303");
        }
        //4
        if ("Máquinas de crunch abdominal".equals(opc)) {
            vista.textMaqDescripcion.setText("Para trabajar los músculos abdominales.");
            vista.textMaqCodigo.setText("401");
        }
        if ("Máquinas de giro de torso".equals(opc)) {
            vista.textMaqDescripcion.setText("Para trabajar los oblicuos.");
            vista.textMaqCodigo.setText("402");
        }
        //5
        if ("Máquinas de Smith".equals(opc)) {
            vista.textMaqDescripcion.setText(" Para hacer levantamientos con una barra guiada.");
            vista.textMaqCodigo.setText("501");
        }
        if ("Máquinas de fuerza multifuncional".equals(opc)) {
            vista.textMaqDescripcion.setText("Permiten realizar una variedad de ejercicios en una sola máquina.");
            vista.textMaqCodigo.setText("502");
        }
    }
    private void agregarMaquinas(int filasSelecionada) {
        String nombre="";
        String tipo= (String) vista.comboBoxMaqTipo.getSelectedItem();
        if(vista.comboBoxMaqNom1.isEnabled()){
            nombre = (String) vista.comboBoxMaqNom1.getSelectedItem();
        }
        if(vista.comboBoxMaqNom2.isEnabled()){
            nombre = (String) vista.comboBoxMaqNom2.getSelectedItem();
        }
        if(vista.comboBoxMaqNom3.isEnabled()){
            nombre = (String) vista.comboBoxMaqNom3.getSelectedItem();
        }
        if(vista.comboBoxMaqNom4.isEnabled()){
            nombre = (String) vista.comboBoxMaqNom4.getSelectedItem();
        }
        if(vista.comboBoxMaqNom5.isEnabled()){
            nombre = (String) vista.comboBoxMaqNom5.getSelectedItem();
        }

        String descripcion = vista.textMaqDescripcion.getText();
        String codigo = vista.textMaqCodigo.getText();
        String estado = (String) vista.comboBoxMaqEstado.getSelectedItem();

        String ubi = (String) vista.tablaGimnasiosMaq.getValueAt(filasSelecionada,0);
        String codGym= (String) vista.tablaGimnasiosMaq.getValueAt(filasSelecionada,1);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaAdquisicion = vista.fechaAdMaq.getDate();
        Date fechaMantenimiento = vista.fechaMatMaq.getDate();

        String fechaAdq = dateFormat.format(fechaAdquisicion);
        String fechaMant = dateFormat.format(fechaMantenimiento);

        gestionMaquinas.agregarMaquina(tipo,nombre, descripcion,fechaAdq,codigo,estado,fechaMant,ubi,codGym);
        grabarMaquinas();
        model4.addRow(new Object[]{tipo,nombre, descripcion,fechaAdq,codigo,estado,fechaMant,ubi,codGym});
    }
    public void grabarMaquinas(){
        gestionMaquinas.grabarMaquinas("Maquinas");
    }
    public boolean CamposCompletadosMaq(){
        if(     vista.comboBoxMaqTipo.getSelectedItem().toString().isEmpty()
                || vista.textMaqDescripcion.getText().isEmpty()
                || vista.textMaqCodigo.getText().isEmpty()
                ||  vista.comboBoxMaqEstado.getSelectedItem().toString().isEmpty()
                || vista.fechaAdMaq.getDate() == null
                || vista.fechaMatMaq.getDate() == null
        ){
            return false;
        }else{
            return true;
        }
    }

    private void colocarDatosMaquinas(int filaSeleccionada) {
        String tipo = (String) vista.tableMaqRegistro.getValueAt(filaSeleccionada, 0);
        String nombreActividad = (String) vista.tableMaqRegistro.getValueAt(filaSeleccionada, 1);
        String descripcion = (String) vista.tableMaqRegistro.getValueAt(filaSeleccionada, 2);
        String fechaAdq = (String) vista.tableMaqRegistro.getValueAt(filaSeleccionada, 3);
        String codigo = (String) vista.tableMaqRegistro.getValueAt(filaSeleccionada, 4);
        String estado = (String) vista.tableMaqRegistro.getValueAt(filaSeleccionada, 5);
        String fechaMant = (String) vista.tableMaqRegistro.getValueAt(filaSeleccionada, 6);

        vista.comboBoxMaqTipo.setSelectedItem(tipo);

        if("Máquinas de Cardio".equals(nombreActividad)){
            vista.comboBoxMaqNom1.setSelectedItem(nombreActividad);
        }
        if("Máquinas de Pesas".equals(nombreActividad)){
            vista.comboBoxMaqNom2.setSelectedItem(nombreActividad);
        }
        if("Máquinas de Cable".equals(nombreActividad)){
            vista.comboBoxMaqNom3.setSelectedItem(nombreActividad);
        }
        if("Máquinas de Abdominales".equals(nombreActividad)){
            vista.comboBoxMaqNom4.setSelectedItem(nombreActividad);
        }
        if("Máquinas de Funcionalidad".equals(nombreActividad)){
            vista.comboBoxMaqNom5.setSelectedItem(nombreActividad);
        }
        vista.textMaqDescripcion.setText(descripcion);
        vista.textMaqCodigo.setText(codigo);
        vista.comboBoxMaqEstado.setSelectedItem(estado);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaInicioDate = vista.fechaAdEquipo.getDate();
        Date fechaFinDate = vista.fechaMateniminetoEquipo.getDate();

        vista.fechaAdMaq.setDate(fechaInicioDate);
        vista.fechaMatMaq.setDate(fechaFinDate);
    }
    private void ModificaMaq(int filaSeleccionada) {
        if (CamposCompletadosMaq() ) {

            String tipo= (String) vista.comboBoxEquipoTipo.getSelectedItem();
            String nombre="";
            if(vista.comboBoxMaqNom1.isEnabled()){
                nombre = (String) vista.comboBoxMaqNom1.getSelectedItem();
            }
            if(vista.comboBoxMaqNom2.isEnabled()){
                nombre = (String) vista.comboBoxMaqNom2.getSelectedItem();
            }
            if(vista.comboBoxMaqNom3.isEnabled()){
                nombre = (String) vista.comboBoxMaqNom3.getSelectedItem();
            }
            if(vista.comboBoxMaqNom4.isEnabled()){
                nombre = (String) vista.comboBoxMaqNom4.getSelectedItem();
            }
            if(vista.comboBoxMaqNom5.isEnabled()){
                nombre = (String) vista.comboBoxMaqNom5.getSelectedItem();
            }

            String descripcion = vista.textMaqDescripcion.getText();
            String codigo = vista.textMaqCodigo.getText();
            String estado = (String) vista.comboBoxMaqEstado.getSelectedItem();
            String ubi =null;
            String codGym= null;

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date fechaAdquisicion = vista.fechaAdMaq.getDate();
            Date fechaMantenimiento = vista.fechaMatMaq.getDate();

            String fechaAdq = dateFormat.format(fechaAdquisicion);
            String fechaMant = dateFormat.format(fechaMantenimiento);

            model4.setValueAt(tipo, filaSeleccionada, 0);
            model4.setValueAt(nombre, filaSeleccionada, 1);
            model4.setValueAt(descripcion, filaSeleccionada, 2);
            model4.setValueAt(fechaAdq, filaSeleccionada, 3);
            model4.setValueAt(codigo, filaSeleccionada, 4);
            model4.setValueAt(estado, filaSeleccionada, 5);
            model4.setValueAt(fechaMant, filaSeleccionada, 6);
            //model2.setValueAt(ubi, filaSeleccionada, 7);
            //model2.setValueAt(codGym, filaSeleccionada, 8);

            gestionMaquinas.modificarMaquinas(filaSeleccionada,tipo,nombre,descripcion,fechaAdq,codigo,estado,fechaMant,ubi,codGym);
            grabarMaquinas();
        }
    }

    private void EliminarMaquinas(int filaSeleccionada) {
        int response = JOptionPane.showConfirmDialog(null, "¿Desea eliminar esta actividad?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            gestionMaquinas.eliminarMaquina(filaSeleccionada);
            model4.removeRow(filaSeleccionada);
            grabarMaquinas();
        }
    }
    public void colocarMaquinas(int pos) {
        if (pos >= 0 && pos < GestionMaquinas.getInstancia().getMaquinas().size()) {
            Maquinas maquinas1 = GestionMaquinas.getInstancia().getMaquinas().get(pos);
            System.out.println("Persona encontrada: " + maquinas1.getNombre()); // Depuración adicional

            vista.textArea2.setText("\n \tInformacion Equipo" +
                    "\n Tipo " + maquinas1.getTipo()+
                    "\n Nombre: " +maquinas1.getNombre()+
                    "\n Descripcio: " +maquinas1.getDescripcion()+
                    "\n Fecha Adquisicion: " + maquinas1.getFechadeAdquisicion()+
                    "\n Codigo: " + maquinas1.getCodigo()+
                    "\n Estado: " +maquinas1.getEstado()+
                    "\n Fecha mantenimiento: " +maquinas1.getFechadeMantenimiento()+
                    "\n Ubicacion: " +maquinas1.getUbicaionGym()+
                    "\n Codigo:"+maquinas1.getCodigoGym());

        } else {
            JOptionPane.showMessageDialog(null, "Maquina no encontrada");
        }
    }
    public void limpiarMaq(){
        vista.comboBoxMaqTipo.setSelectedItem(0);
        vista.comboBoxMaqEstado.setSelectedItem(0);
        vista.comboBoxMaqNom1.setEnabled(false);
        vista.comboBoxMaqNom2.setEnabled(false);
        vista.comboBoxMaqNom3.setEnabled(false);
        vista.comboBoxMaqNom4.setEnabled(false);
        vista.comboBoxMaqNom5.setEnabled(false);

        vista.textMaqDescripcion.setText("");
        vista.textMaqCodigo.setText("");
        vista.fechaAdMaq.setDate(null);
        vista.fechaMatMaq.setDate(null);
        vista.textArea2.setText("");
    }
    public void recuperarMaquinas() {
        try {
            GestionMaquinas gestionMaquinas1 = gestionMaquinas.recuperarMaquinas("Maquinas");
            llenarTablaDeMaquinas(gestionMaquinas1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        //JOptionPane.showMessageDialog(null, "Datos Recuperados");
    }

    private void llenarTablaDeMaquinas(GestionMaquinas gestionMaquinas1) {
        model4.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Maquinas maquinas1 : gestionMaquinas1.getMaquinas()) {
            model4.addRow(new Object[]{
                    maquinas1.getTipo(),
                    maquinas1.getNombre(),
                    maquinas1.getDescripcion(),
                    maquinas1.getFechadeAdquisicion(),
                    maquinas1.getCodigo(),
                    maquinas1.getEstado(),
                    maquinas1.getFechadeMantenimiento(),
                    maquinas1.getUbicaionGym(),
                    maquinas1.getCodigoGym()
            });
        }
    }
    //Termina CRUDs equipos
    //------------------------------------------------------------------------------------------------------------------------------------
    private void inicializarComponentes5(){
        model5.setColumnCount(9);
        model5.setRowCount(0);
        model5.setColumnIdentifiers(new Object[]{"Tipo"," Nombre","Descripcion", " Fecha de adquisicion","Codigo","Estado"," Fecha de Mantenimiento","Ubicaion"," Codigo"});
        vista.tablaEquiMante.setModel(model5);
    }

    public void recuperarMaquinasMatenimiento() {
        try {
            GestionMaquinas gestionMaquinas1 = gestionMaquinas.recuperarMaquinas("Maquinas");
            llenarTablaDeMaquinasMatenimiento(gestionMaquinas1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        //JOptionPane.showMessageDialog(null, "Datos Recuperados");
    }
    private void llenarTablaDeMaquinasMatenimiento(GestionMaquinas gestionMaquinas1) {
        model5.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Maquinas maquinas1 : gestionMaquinas1.getMaquinas()) {
            if ("En mantenimiento".equals(maquinas1.getEstado())) {
                model5.addRow(new Object[]{
                        maquinas1.getTipo(),
                        maquinas1.getNombre(),
                        maquinas1.getDescripcion(),
                        maquinas1.getFechadeAdquisicion(),
                        maquinas1.getCodigo(),
                        maquinas1.getEstado(),
                        maquinas1.getFechadeMantenimiento(),
                        maquinas1.getUbicaionGym(),
                        maquinas1.getCodigoGym()
                });
            }
        }
    }
    //-----------------------------------------------------------------------------
    private void inicializarComponentes6(){
        model6.setColumnCount(9);
        model6.setRowCount(0);
        model6.setColumnIdentifiers(new Object[]{"Tipo"," Nombre","Descripcion", " Fecha de adquisicion","Codigo","Estado"," Fecha de Mantenimiento","Ubicaion"," Codigo"});
        vista.tablaMaqMant.setModel(model6);
    }

    public void recuperarEquiposMantenimiento() {
        try {
            GestionEquipo gestionEquipo1 = gestionEquipo.recuperarEquipos("Equipos");
            llenarTablaDeEquiposMantenimiento(gestionEquipo1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        //JOptionPane.showMessageDialog(null, "Datos Recuperados");
    }

    private void llenarTablaDeEquiposMantenimiento(GestionEquipo gestionEquipo1) {
        model6.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Equipo equipo1 : gestionEquipo1.getEquipos()) {
            if ("En mantenimiento".equals(equipo1.getEstado())) {
                model6.addRow(new Object[]{
                        equipo1.getTipo(),
                        equipo1.getNombre(),
                        equipo1.getDescripcion(),
                        equipo1.getFechadeAdquisicion(),
                        equipo1.getCodigo(),
                        equipo1.getEstado(),
                        equipo1.getFechadeMantenimiento(),
                        equipo1.getUbicaionGym(),
                        equipo1.getCodigoGym()
                });
            }
        }
    }

    //-------------------------------------------
    private void inicializarComponentes7(){
        model7.setColumnCount(9);
        model7.setRowCount(0);
        model7.setColumnIdentifiers(new Object[]{"Tipo"," Nombre","Descripcion", " Fecha de adquisicion","Codigo","Estado"," Fecha de Mantenimiento","Ubicaion"," Codigo"});
        vista.tablaInventario.setModel(model7);
    }
}
