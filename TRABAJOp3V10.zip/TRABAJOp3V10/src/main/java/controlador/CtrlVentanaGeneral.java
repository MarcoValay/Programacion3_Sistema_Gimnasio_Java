package controlador;

import modelo.Gimnasio;
import vista.VentanaGeneral;
import vista.ventanaGestionSocios;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlVentanaGeneral implements ActionListener {

    private VentanaGeneral vista;
    private CtrlActividades v2;
    private CtrlGestioSocios v1;
   // private CtrlPagosDefinidos v3;
    private CtrlPagos v3;
    private CtrlEquiposYEspacios v4;
    private CtrlAnalisisEInfo v5;
    private CtrlGimnasio v6;
    private CtrlAccederAlGym v7;
    private Gimnasio gimnasio;
    public CtrlVentanaGeneral(){
        this.vista=new VentanaGeneral();
        this.gimnasio = new Gimnasio();

        vista.btnActi.addActionListener(this);
        vista.btnGesEquipos.addActionListener(this);
        vista.btnGesPagos.addActionListener(this);
        vista.btnGesSocios.addActionListener(this);
        vista.btnInfoAnalisis.addActionListener(this);
        vista.regresarButton.addActionListener(this);
        vista.cerraSesionButton.addActionListener(this);
        vista.ingresarAlGYMButton.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==vista.regresarButton){
            v6=new CtrlGimnasio(gimnasio.getRuc());
            vista.dispose();
        }
        if(e.getSource()==vista.btnGesSocios){
            v1=new CtrlGestioSocios();
            vista.dispose();
        }
        if(e.getSource()==vista.btnActi){
            v2=new CtrlActividades();
            vista.dispose();
        }
        if(e.getSource()==vista.btnGesPagos){
            v3=new CtrlPagos();
            vista.dispose();
        }
        if(e.getSource()==vista.btnGesEquipos){
            v4=new CtrlEquiposYEspacios();
            vista.dispose();
        }
        if(e.getSource()==vista.btnInfoAnalisis){
            v5=new CtrlAnalisisEInfo();
            vista.dispose();
        }
        if(e.getSource()==vista.cerraSesionButton){
            System.exit(1);
        }
        if(e.getSource()==vista.ingresarAlGYMButton){
            v7 = new CtrlAccederAlGym();
            vista.dispose();
        }

    }
}
