package controlador;

import modelo.*;
import vista.ventanaGimnasio;
import vista.ventanaVERingresos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class CtrlverIngresos implements ActionListener {

    private CtrlGimnasio v1;
    private ventanaVERingresos vista;
    private DefaultTableModel model;
    private ventanaGimnasio gimnasio;
    private Duenio duenio;
    private Gimnasio gimnasio1;


    public CtrlverIngresos(ventanaGimnasio gimnasio){
        this.vista=new ventanaVERingresos();
        this.gimnasio1 = new Gimnasio();
        this.gimnasio=gimnasio;
        this.duenio=new Duenio();
        model=new DefaultTableModel();
        vista.regresarButton.addActionListener(this);
        inicializarComponentes();
        cargar();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.regresarButton){
            v1=new CtrlGimnasio(gimnasio1.getRuc());
            vista.dispose();
        }
    }

    private void inicializarComponentes(){
        model.setColumnCount(9);
        model.setRowCount(0);
        model.setColumnIdentifiers(new Object[]{"Nombre","Direccion","Telefono","Ubicacion","Codigo","Fecha-Inicio","Fecha-Fin","Hora-inicio","Hora-Fin"});
        vista.table1.setModel(model);
        //agregar();
    }
    private void agregar(){
         String ruc=gimnasio.textRuc.getText();
         String nombre=gimnasio.textNombre.getText();
         String dir=gimnasio.textDireccion.getText();
         String telf=gimnasio.textTelefono.getText();
         String ubi=gimnasio.textFieldNomCalles.getText();
         String cog=gimnasio.textCodigo.getText();
         String fechaIni=gimnasio.fechaInicio.getDateFormatString().toString();
         String Ffin=gimnasio.fechafin.getDateFormatString().toString();
         String Hini = gimnasio.comboBox1.getSelectedItem().toString();
         String Hfin = gimnasio.comboBox2.getSelectedItem().toString();

        model.addRow(new Object[]{ruc,nombre,dir,telf,ubi,cog,fechaIni,Ffin,Hini,Hfin});
    }

    public void cargar(){
        try {
            Duenio duenio1 = duenio.recuperar("GYMs");
            llenarTabla(duenio1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JOptionPane.showMessageDialog(null,"Datos Recuperados");
    }

    private void llenarTabla(Duenio duenio) {
        model.setRowCount(0); // Limpiar la tabla antes de llenarla
        for (Gimnasio gimnasio1: duenio.getGimnasios()) {
            model.addRow(new Object[]{gimnasio1.getNombre(),gimnasio1.getDireccion(),gimnasio1.getTelefono(),gimnasio1.getNombreCalles(),gimnasio1.getCodigo(),
                    gimnasio1.getFechaInicio(),gimnasio1.getFechaFin(),gimnasio1.getHoraInicio(),gimnasio1.getHoraFin()});
        }
    }
    public void Modificar(int pos) {
        System.out.println("Posición recibida para modificar: " + pos);



        if (pos >= 0 && pos < Duenio.getInstancia().getGimnasios().size()) {
            Gimnasio gimnasio1 = Duenio.getInstancia().getGimnasios().get(pos);

            // Confirmar la modificación
            int response = JOptionPane.showConfirmDialog(null, "¿Desea modificar los datos de esta persona?", "Confirmación", JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) {

                // Actualizar los datos de la persona
                gimnasio1.setNombre(gimnasio.textNombre.getText());
                gimnasio1.setDireccion(gimnasio.textDireccion.getText());
                gimnasio1.setTelefono(gimnasio.textTelefono.getText());
                gimnasio1.setNombreCalles(gimnasio.textFieldNomCalles.getText());
                gimnasio1.setCodigo(gimnasio.textCodigo.getText());
                gimnasio1.setFechaInicio(gimnasio.fechaInicio.getDateFormatString().toString());
                gimnasio1.setFechaFin(gimnasio.fechafin.getDateFormatString().toString());
                gimnasio1.setHoraInicio(gimnasio.comboBox1.getSelectedItem().toString());
                gimnasio1.setHoraFin(gimnasio.comboBox2.getSelectedItem().toString());

                // Actualizar la tabla

                model.setValueAt(gimnasio1.getNombre(), pos, 0);
                model.setValueAt(gimnasio1.getDireccion(), pos, 1);
                model.setValueAt(gimnasio1.getTelefono(), pos, 2);
                model.setValueAt(gimnasio1.getNombreCalles(), pos, 3);
                model.setValueAt(gimnasio1.getCodigo(), pos, 4);
                model.setValueAt(gimnasio1.getFechaInicio(), pos, 5);
                model.setValueAt(gimnasio1.getFechaFin(), pos, 6);
                model.setValueAt(gimnasio1.getHoraInicio(), pos, 7);
                model.setValueAt(gimnasio1.getHoraFin(), pos, 8);


                // Guardar cambios
               // grabar();
                JOptionPane.showMessageDialog(null, "Datos modificados correctamente");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Persona no encontrada");
        }
    }

}
