package vista;

import javax.swing.*;

public class ventanaInformeAnalisis extends JFrame{
    public JPanel Punto5;
    public JButton analisisDeRegistroButton;
    public JButton informeAsistenciaButton;
    public JButton btnregresar;
    public JComboBox comboBox1;
    public JTextField textField1;
    public JComboBox comboBox2;
    public JTabbedPane tabbedPane1;
    public JTable table1;

    public ventanaInformeAnalisis(){
        pack();
        setVisible(true);
        setSize(800,400);
        setLocationRelativeTo(null);
        setTitle("Informes y Análisis");
        setContentPane(Punto5);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
