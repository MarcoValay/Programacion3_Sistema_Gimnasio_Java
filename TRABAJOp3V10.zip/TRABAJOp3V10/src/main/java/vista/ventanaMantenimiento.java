package vista;

import javax.swing.*;

public class ventanaMantenimiento extends JFrame{
    public JPanel panel1;
    public JButton regresarButton;
    public JButton guardarButton;
    public JButton modificarButton;
    public JTable table1;

    public ventanaMantenimiento(){
        pack();
        setVisible(true);
        setContentPane(panel1);
        setSize(600,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
