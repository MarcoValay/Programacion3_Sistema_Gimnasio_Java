package vista;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ventanaRegistroAdministrador extends JFrame {
    public JPanel panelRegistroAdmin;
    public JTextField textNombre;
    public JTextField textDireccion;
    public JTextField textCorreo;
    public JButton guardarButton;
    public JButton cancelButton;
    public JTextField textCedula;
    public JPasswordField passwordAdmin;
    public JButton regresarButton;

    public ventanaRegistroAdministrador() {
        pack();
        setVisible(true);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setContentPane(panelRegistroAdmin);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        textNombre.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textCedula.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textCedula.getText().length() > 9) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
    }
}
