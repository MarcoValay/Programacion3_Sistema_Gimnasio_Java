package vista;

import javax.swing.*;

public class ventanaVERingresos extends  JFrame{
    public JPanel panelVerIngresos;
    public JTable table1;
    public JButton regresarButton;

    public ventanaVERingresos(){
        pack();
        setVisible(true);
        setSize(800,600);
        setLocationRelativeTo(null);
        setContentPane(panelVerIngresos);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
