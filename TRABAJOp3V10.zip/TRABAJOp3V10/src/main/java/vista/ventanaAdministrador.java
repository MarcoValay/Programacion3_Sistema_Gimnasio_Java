package vista;

import javax.swing.*;

public class ventanaAdministrador extends JFrame {
    public JPanel panelAdministrador;
    public JTextField textFieldUsuario;
    public JPasswordField passwordField;
    public JButton registrarBtn;
    public JButton okBtnAdmin;

    public ventanaAdministrador(){
        pack();
        setVisible(true);
        setContentPane(panelAdministrador);
        setSize(800,600);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
