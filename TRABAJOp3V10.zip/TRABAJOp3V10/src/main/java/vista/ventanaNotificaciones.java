package vista;

import javax.swing.*;

public class ventanaNotificaciones extends JFrame{
    public JPanel panel1;
    public JButton regresarButton;
    public JButton enviarCorreoButton;
    public JButton cancelarButton;
    public JButton enviarWhastAppButton;
    public JButton cancelarButton1;
    public JTextField textDestinoCorreo;
    public JTextField textAsuntoCorreo;
    public JTextArea textMensajeCorreo;
    public JTextField textDestinoWhastapp;
    public JTextField textField4;
    public JTextArea textMensajeW;
    public JButton adjuntarButton;
    public JTextField ruta;

    public ventanaNotificaciones(){
        pack();
        setVisible(true);
        setContentPane(panel1);
        setSize(600,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
