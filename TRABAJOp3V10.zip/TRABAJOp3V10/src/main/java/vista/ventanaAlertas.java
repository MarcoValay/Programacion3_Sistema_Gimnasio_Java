package vista;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.util.Date;

public class ventanaAlertas extends JFrame{
    public JPanel panel1;
    public JButton regresarButton;
    public JButton adjuntarButton;
    public JButton configurarButton;
    public JButton cancelarButton;
    public JTextField textDestinoCorreo;
    public JTextField textAsuntoCorreo;
    public JTextArea textMensajeCorreo;
    public JTextField ruta;
    public JPanel PanelFecha;
    public JDateChooser fecha;

    public ventanaAlertas(){
        colocarFecha();
        pack();
        setVisible(true);
        setContentPane(panel1);
        setSize(600,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void colocarFecha() {
        fecha = new JDateChooser();
        fecha.setDateFormatString("dd/MM/yy HH:mm:ss");
        fecha.setMinSelectableDate(new Date());

        if (PanelFecha != null) {
            PanelFecha.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            PanelFecha.add(fecha);
        } else {
            System.err.println("PanleFechaInicio es nulo!");
        }
    }
}
