package vista;

import javax.swing.*;

public class ventanaEnviarCorreo extends JFrame{
    public JPanel panel1;
    public JTextField textDestino;
    public JTextField textAsunto;
    public JTextArea textMensaje;
    public JButton seleccionarArchivoButton;
    public JButton enviarButton;
    public JButton cancelarButton;
    public JButton regresarButton;
    public JTextField rutaFactura;
    public JTextField rutaRecibo;
    public JButton seleccionarReciboButton;

    public ventanaEnviarCorreo(){
        pack();
        setVisible(true);
        setContentPane(panel1);
        setSize(600,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
