package vista;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Date;

public class ventanaGestionEquiposYEspacios extends JFrame{
    public JPanel Punto4;
    public JButton btnregresar;
    public JTable tablaInventario;
    public JTabbedPane tabbedPane1;
    public JComboBox comboBoxEquipoTipo;
    public JTextField EquipoNombre;
    public JTextField EquipoCodigo;
    public JButton registrarEquipo;
    public JButton limpiarEquipo;
    public JButton actualizarEquipo;
    public JButton eliminarEquipo;
    public JTextField EquipoDescripcion;
    public JTable tableGimnasioEquipo;
    public JTable tableRegistroEquipo;
    public JButton buscarEquipo;
    public JTextArea textArea1;
    public JComboBox comboBoxMaqTipo;
    public JComboBox comboBoxMaqNom1;
    public JComboBox comboBoxMaqNom2;
    public JComboBox comboBoxMaqNom3;
    public JComboBox comboBoxMaqNom4;
    public JComboBox comboBoxMaqNom5;
    public JTextField textMaqDescripcion;
    public JTextField textMaqCodigo;
    public JTable tablaGimnasiosMaq;
    public JTable tableMaqRegistro;
    public JButton buscarMaq;
    public JButton registrarMaq;
    public JButton limpiarMap;
    public JButton actualizarMaq;
    public JButton eliminarMaq;
    public JComboBox comboBoxEquipoEstado;
    public JComboBox comboBoxMaqEstado;
    public JTable tablaEquiMante;
    public JTable tablaMaqMant;
    public JButton darMantenimientoButton;
    public JButton eliminarButton2;
    public JButton cancelarButton;
    public JPanel EquipoFechaAd;
    public JPanel EquipoFMantenimiento;
    public JPanel MaqFAdquisicion;
    public JPanel MaqFMantenimiento;
    public JTextArea textArea2;
//    public JButton historialDeMantemientosButton;
    public JDateChooser fechaAdEquipo;
    public JDateChooser fechaMateniminetoEquipo;
    public JDateChooser fechaAdMaq;
    public JDateChooser fechaMatMaq;

    public ventanaGestionEquiposYEspacios(){
        colocarFechaAdquisicion();
        colocarFechaMantenimiento();
        pack();
        setVisible(true);
        setSize(900,800);
        setLocationRelativeTo(null);
        setTitle("Gestión de Equipos y espacios");
        setContentPane(Punto4);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        camposEquipos();

        colocarFechaAdquisicionMaq();
        colocarFechaMantenimientoMaq();
    }

    public void colocarFechaAdquisicion() {
        fechaAdEquipo = new JDateChooser();
        fechaAdEquipo.setDateFormatString("dd/MM/yy");
        fechaAdEquipo.setMaxSelectableDate(new Date());

        if (EquipoFechaAd != null) {
            EquipoFechaAd.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            EquipoFechaAd.add(fechaAdEquipo);
        } else {
            System.err.println("PanleFechaInicio es nulo!");
        }
    }

    public void colocarFechaMantenimiento() {
        fechaMateniminetoEquipo = new JDateChooser();
        fechaMateniminetoEquipo.setDateFormatString("dd/MM/yy");
        fechaMateniminetoEquipo.setMinSelectableDate(new Date());

        if (EquipoFMantenimiento != null) {
            EquipoFMantenimiento.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            EquipoFMantenimiento.add(fechaMateniminetoEquipo);
        } else {
            System.err.println("PanleFechaInicio es nulo!");
        }
    }

    public void camposEquipos(){
        EquipoNombre.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });

        EquipoCodigo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || EquipoCodigo.getText().length() > 2) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });

        EquipoDescripcion.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
    }
    //-*------*-*-*-*-*-*-*-*-*-*-*-*-**-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*-*-*-**--*-*-*-*-*-*-*-*-
    public void colocarFechaAdquisicionMaq() {
        fechaAdMaq = new JDateChooser();
        fechaAdMaq.setDateFormatString("dd/MM/yy");
        fechaAdMaq.setMaxSelectableDate(new Date());

        if (MaqFAdquisicion!= null) {
            MaqFAdquisicion.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            MaqFAdquisicion.add(fechaAdMaq);
        } else {
            System.err.println("PanleFechaInicio es nulo!");
        }
    }

    public void colocarFechaMantenimientoMaq() {
        fechaMatMaq = new JDateChooser();
        fechaMatMaq.setDateFormatString("dd/MM/yy");
        fechaMatMaq.setMinSelectableDate(new Date());

        if (MaqFMantenimiento != null) {
            MaqFMantenimiento.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            MaqFMantenimiento.add(fechaMatMaq);
        } else {
            System.err.println("PanleFechaInicio es nulo!");
        }
    }
}
