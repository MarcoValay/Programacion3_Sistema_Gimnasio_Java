package vista;

import javax.swing.*;

public class ventanaGestionPagos extends JFrame{
    public JPanel Punto2pagos;
    public JComboBox comboBox1;
    public JTextField textValorCancelar;
    public JButton PagarButton;
    public JButton cancelButton;
    public JButton generarFacturaButton;
    public JButton configuracionDeAlertasButton;
    public JButton btnEquipo;
    public JButton regresarButton;
    public JComboBox comboBox2;
    public JTextField textValor;
    public JTextArea textArea1;
    public JTable table1;
    public JTable table2;
    public JTextArea textArea2;
    public JButton crudButton;
    public JButton enviarArchivosDePagoButton;
    public JButton historialPagoButton;
    public JTable table3;
    public JButton asignarButton;
    public JTable table4;
    public JButton inicioButton;

    public ventanaGestionPagos(){
        pack();
        setVisible(true);
        setSize(1000,800);
        setLocationRelativeTo(null);
        //setTitle("Gestión de Pagos");
        setContentPane(Punto2pagos);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
