package vista;

import javax.swing.*;

public class ventanaRegistroMiembro extends JFrame{
    public JPanel Punto1Miembro;
    public JTextField textField1;
    public JTextField textField2;
    public JButton btnguardar;
    public JButton btnCancelar;
    public JButton regresarButton;

    public ventanaRegistroMiembro(){
        pack();
        setVisible(true);
        setSize(400,600);
        setLocationRelativeTo(null);
        setTitle("Registro Miembro");
        setContentPane(Punto1Miembro);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
