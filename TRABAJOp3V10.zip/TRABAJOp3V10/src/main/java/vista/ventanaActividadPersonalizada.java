package vista;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ventanaActividadPersonalizada extends JFrame{
    public JPanel ActividadesPersonales;
    public JButton regresarButton;
    public JButton crearButton;
    public JButton LimpiarButton;
    public JButton guardarButton;
    public JTabbedPane tabbedPane1;
    public JTextField textDescripcion;
    public JTextField textCodigo;
    public JTextField textCupo;
    public JTabbedPane tabbedPane2;
    public JCheckBox juevesCheckBox;
    public JCheckBox viernesCheckBox;
    public JCheckBox miercolesCheckBox;
    public JCheckBox martesCheckBox;
    public JCheckBox lunesCheckBox;
    public JCheckBox domingoCheckBox;
    public JCheckBox sabadoCheckBox;
    public JComboBox lunesInicio;
    public JComboBox lunesFin;
    public JTextField textNombre;
    public JButton modificarButton;
    public JButton eliminarButton;
    public JTable table1;
    public JComboBox martesInicio;
    public JComboBox martesFin;
    public JComboBox miercolesInicio;
    public JComboBox miercolesFin;
    public JComboBox juevesInicio;
    public JComboBox juevesFin;
    public JComboBox viernesInicio;
    public JComboBox viernesFin;
    public JComboBox sabadoInicio;
    public JComboBox sabadoFin;
    public JComboBox domingoInicio;
    public JComboBox domingoFin;
    public JRadioButton siRadioButton;
    public JRadioButton noRadioButton;
    public JTextField textCosto;
    public JComboBox comboBox1;
    public JRadioButton siRadioButton2;
    public JRadioButton noRadioButton2;
    public JComboBox comboBoxEntrenador;

    public ventanaActividadPersonalizada(){
        pack();
        setVisible(true);
        setSize(900,800);
        setLocationRelativeTo(null);
        setTitle("ActividadesPersonales");
        setContentPane(ActividadesPersonales);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        textNombre.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });

        textDescripcion.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textCodigo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textCodigo.getText().length() > 3) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textCupo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textCupo.getText().length() > 2) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
    }
}
