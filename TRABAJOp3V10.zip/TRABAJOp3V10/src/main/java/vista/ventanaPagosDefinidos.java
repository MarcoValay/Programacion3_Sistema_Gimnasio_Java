package vista;

import javax.swing.*;

public class ventanaPagosDefinidos extends JFrame{
    public JPanel PagosDefinidos;
    public JComboBox comboBox1Actividad;
    public JComboBox comboBox2TipoPago;
    public JTextField textField1;
    public JButton regresarButton;
    private JComboBox comboBox1;

    public ventanaPagosDefinidos(){
        pack();
        setVisible(true);
        setSize(400,400);
        setLocationRelativeTo(null);
        setTitle("Ver precio Actividades");
        setContentPane(PagosDefinidos);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
