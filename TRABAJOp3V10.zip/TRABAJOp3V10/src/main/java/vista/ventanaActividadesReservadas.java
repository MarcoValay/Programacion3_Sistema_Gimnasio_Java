package vista;

import javax.swing.*;

public class ventanaActividadesReservadas extends JFrame {
    public JPanel panel1;
    public JButton Regresar;
    public JTable table1;
    public JButton cancelarButton;
    public JButton notificarButton;
    public JTextArea textArea1;

    public ventanaActividadesReservadas(){
        pack();
        setVisible(true);
        setContentPane(panel1);
        setSize(900,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
