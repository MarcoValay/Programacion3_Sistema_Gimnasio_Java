package vista;

import com.toedter.calendar.JDateChooser;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Objects;

public class ventanaGestionSocios extends JFrame {
    public JTextField textNombre;
    public JTextField textApellido;
    public JTextField textDireccion;
    public JTextField textCedula;
    public JTextField textTelefono;
    public JButton btnActualizar;
    public JButton btnRegistrar;
    public JButton btnCancel;
    public JTable table1;
    public JComboBox comboBox1;
    public JPanel Punto1Registro;
    public JButton btnRegresar;
    public JTextArea textArea1;
    public JPanel PanelFechaInicio;
    public JPanel PanelFechaFin;
    public JButton eliminarButton;
    public JButton progActividadesMButton;
    public JButton buscarButton;
    public JTextField textId;
    public JButton seleccionarFotografiaButton;
    public JLabel foto;
    public JDateChooser fechaInicio;
    public JDateChooser fechafin;
    public String FotoUsuario;

    public ventanaGestionSocios(){

        colocarFecha();
        //setIcono();

        FotoUsuario = "src/Iconos/foto.png";
        //foto.setIcon(new ImageIcon(Objects.requireNonNull(getClass().getResource(FotoUsuario))));
        setFotoUsuario(FotoUsuario);

        pack();
        setVisible(true);
        setSize(900,700);
        setLocationRelativeTo(null);
        setTitle("Gestión de Socios");
        setContentPane(Punto1Registro);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public void setIcono() {
        // Cambiamos el icono de la ventana
        try {
            // Cargamos la imagen desde el recurso
            InputStream resourceAsStream = getClass().getResourceAsStream("/vistas/Complements/pata.png");
            BufferedImage icon = ImageIO.read(resourceAsStream);

            // Establecemos el icono de la ventana
            setIconImage(icon);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void colocarFecha() {
        fechaInicio = new JDateChooser();
        fechaInicio.setDateFormatString("dd/MM/yy");
        fechaInicio.setMaxSelectableDate(new Date());

        fechafin = new JDateChooser();
        fechafin.setDateFormatString("dd/MM/yy");
        fechafin.setMaxSelectableDate(new Date());

        if (PanelFechaInicio != null || PanelFechaFin != null) {
            PanelFechaInicio.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            PanelFechaInicio.add(fechaInicio);

            PanelFechaFin.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            PanelFechaFin.add(fechafin);
        } else {
            System.err.println("PanleFechaInicio es nulo!");
        }

        textNombre.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });

        textApellido.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textCedula.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textCedula.getText().length() > 9) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textTelefono.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textTelefono.getText().length() > 9) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
    }

    public void setPathFotoUsuario(){
        String[] extensionesImagen = {"png", "jpg", "jpeg", "gif"};

        JFileChooser fotoUsuario = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de Imagen", extensionesImagen);

        try {
            int result = fotoUsuario.showOpenDialog(this);

            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fotoUsuario.getSelectedFile();

                if (selectedFile.exists()) {
                    FotoUsuario = selectedFile.getPath().replace('\\', '/');
                } else {
                    // El archivo seleccionado no existe
                    throw new Exception("El archivo seleccionado no existe.");
                }
            } else {
                // El usuario canceló la selección, puedes manejarlo según tus necesidades
                throw new Exception("Selección cancelada por el usuario.");
            }
        } catch (Exception e) {
            // Manejar la excepción (por ejemplo, mostrar un mensaje de error o establecer un valor predeterminado)
            System.err.println("Error al seleccionar el archivo: " + e.getMessage());
            FotoUsuario = "src/Iconos/foto.png";
        }

        setFotoUsuario(FotoUsuario);


    }
    public void setFotoUsuario(String pathFoto){

        if(pathFoto == null)
            //pathFoto = "src/vistas/complements/defaultProfileIcono.png";
            pathFoto = "src/Iconos/foto.png";

        // Se carga la imagen original
        ImageIcon originalIcon = new ImageIcon(pathFoto);
        Image originalImage = originalIcon.getImage();

        // Se ajusta el tamaño de la imagen a 100x80 pixeles
        Image resizedImage = originalImage.getScaledInstance(80, 100, Image.SCALE_SMOOTH);

        // Se crea un nuevo ImageIcon con la imagen ajustada
        ImageIcon resizedIcon = new ImageIcon(resizedImage);

        // Se establece el nuevo tamaño y se asigna al JLabel
        foto.setSize(80, 100);
        foto.setIcon(resizedIcon);
    }


}
