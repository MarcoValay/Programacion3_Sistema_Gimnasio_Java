package vista;

import javax.swing.*;

public class ventanaAccederAlGym extends  JFrame{
    public JPanel panel1;
    public JTable table1;
    public JButton asignarSocioButton;
    public JButton cancelarButton;
    public JButton regresarButton;
    public JTable tablaGYM;
    public JTextField textField1;

    public ventanaAccederAlGym(){
        pack();
        setVisible(true);
        setSize(600,700);
        setLocationRelativeTo(null);
        setTitle("Gestión de Socios");
        setContentPane(panel1);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
