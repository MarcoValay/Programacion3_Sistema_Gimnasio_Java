package vista;

import javax.swing.*;

public class ventanaCrudsFacturas extends JFrame{
    public JPanel panel1;
    public JButton regresarButton;
    public JTable table1;
    public JButton leerButton;
    public JTextArea textArea1;
    public JTextArea textArea2;
    public JButton modificarButton;
    public JButton eliminarButton;
    public JTextField buscartextField;
    public JButton buscarButton;

    public ventanaCrudsFacturas(){
        pack();
        setVisible(true);
        setSize(900,800);
        setLocationRelativeTo(null);
        setContentPane(panel1);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
