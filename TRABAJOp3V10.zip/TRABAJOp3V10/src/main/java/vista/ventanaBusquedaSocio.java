package vista;

import javax.swing.*;

public class ventanaBusquedaSocio {
    private JPanel panel1;
    private JTextField textField1;
    private JButton buscarInformacionButton;
    private JButton cancelarButton;
    private JButton regresarButton;
}
