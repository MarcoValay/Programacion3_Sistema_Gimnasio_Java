package vista;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Date;

public class ventanaGimnasio extends JFrame{
    public JPanel panelGimnasio;
    public JTabbedPane tabbedPane1;
    public JTextField textNombre;
    public JTextField textDireccion;
    public JTextField textTelefono;
    public JButton cancelButton;
    public JTextField textRuc;
    public JTextField textFieldNomCalles;
    public JTextField textCodigo;
    public JButton agregarGYMButton;
    public JButton ModificarButton;
    public JButton continuarButton;
    public JTabbedPane tabbedPane2;
    public JTabbedPane tabbedPane3;
    public JButton BuscarButton;
    public JPanel FechaInicioPanel;
    public JPanel FEchaFinPanel;
    public JComboBox comboBox1;
    public JComboBox comboBox2;
    public JTable tablaGYMs;
    public JButton regresarButton;
    public JButton eliminarButton;
    public JDateChooser fechaInicio;
    public JDateChooser fechafin;

    public ventanaGimnasio(){
        colocarFecha ();

        pack();
        setVisible(true);
        setSize(900,800);
        setLocationRelativeTo(null);
        setContentPane(panelGimnasio);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public void colocarFecha() {
        fechaInicio = new JDateChooser();
        fechaInicio.setDateFormatString("dd/MM/yy");
        fechaInicio.setMaxSelectableDate(new Date());

        fechafin = new JDateChooser();
        fechafin.setDateFormatString("dd/MM/yy");
        fechafin.setMaxSelectableDate(new Date());

        if (FechaInicioPanel != null || FEchaFinPanel != null) {
            FechaInicioPanel.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            FechaInicioPanel.add(fechaInicio);

            FEchaFinPanel.setLayout(new GridLayout(1, 1));// O cualquier layout que desees usar
            FEchaFinPanel.add(fechafin);
        } else {
            System.err.println("FechaInicioPanel es nulo!");
        }


        textNombre.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textTelefono.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textTelefono.getText().length() > 9) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textFieldNomCalles.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isLetter(e.getKeyChar())) && !(e.getKeyChar()== KeyEvent.VK_SPACE)) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textCodigo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textCodigo.getText().length() > 4) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });

       /* textHini.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textTelefono.getText().length() > 5) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
        textHfin.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textTelefono.getText().length() > 5) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });*/
        textRuc.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textRuc.getText().length() > 9) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
    }
}
