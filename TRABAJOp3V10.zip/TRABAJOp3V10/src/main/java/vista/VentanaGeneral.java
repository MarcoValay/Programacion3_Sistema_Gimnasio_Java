package vista;

import javax.swing.*;

public class VentanaGeneral extends JFrame {
    public JPanel vtnGeneral;
    public JButton btnGesSocios;
    public JButton btnGesPagos;
    public JButton btnGesEquipos;
    public JButton btnInfoAnalisis;
    public JButton btnActi;
    public JButton regresarButton;
    public JButton cerraSesionButton;
    public JButton ingresarAlGYMButton;


    public VentanaGeneral(){
        pack();
        setVisible(true);
        setSize(400,400);
        setLocationRelativeTo(null);
        setTitle("Pricipal");
        setContentPane(vtnGeneral);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public void cerrarVentana(){
        dispose();
    }
}
