package vista;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ventanaActividades extends JFrame{
    public JPanel Punto3reservas;
    public JButton btnAgregar;
    public JComboBox comboBoxRol;
    public JComboBox comboBoxHinicio;
    public JComboBox comboBoxHfin;
    public JButton btnPago;
    public JButton regresarButton;
    public JTextField textDescripcion;
    public JTextField textCodigo;
    public JTextField textCupo;
    public JRadioButton siRadioButton;
    public JRadioButton noRadioButton;
    public JRadioButton lunesAViernesRadioButton;
    public JRadioButton sabadoYDomingoRadioButton;
    public JButton personalizarActividadButton;
    public JButton notificarCambiosHorarioButton;
    public JTable table1;
    public JButton modificarButton;
    public JButton eliminarButton;
    public JTextField textCosto;
    public JComboBox comboBoxClase;
    public JRadioButton siResevadoButton;
    public JRadioButton noRadioButton2;
    public JComboBox comboBoxEntrenador;
    public JButton actividadesReservadasButton;
    public JTextArea textArea1;
    public JButton limpiarButton;

    public ventanaActividades(){
        pack();
        setVisible(true);
        setSize(1300,800);
        setLocationRelativeTo(null);
       // setTitle("Programación de Clases o Actividades");
        setContentPane(Punto3reservas);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        textCupo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(!(Character.isDigit(e.getKeyChar())) || textCupo.getText().length() > 9) {
                    e.consume();
                }
                super.keyTyped(e);
            }
        });
    }

    public void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
