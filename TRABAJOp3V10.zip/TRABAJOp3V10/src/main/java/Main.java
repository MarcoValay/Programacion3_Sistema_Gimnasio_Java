import controlador.CtrlAdministrador;

public class Main {

    public static void main(String[] args) {
        System.out.println("usuario: mrcvalarezo@gmail.com, contrasenia: 1234");
        CtrlAdministrador app=new CtrlAdministrador();
    }
}
