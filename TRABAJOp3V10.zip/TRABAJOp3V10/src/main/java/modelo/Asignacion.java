package modelo;

import modelo.Gimnasio;
import modelo.Persona;
import modelo.RegistroActividad;

import java.io.Serializable;
import java.util.ArrayList;

public class Asignacion implements Serializable {

    private Persona persona;
    private Gimnasio gimnasio;
    private ArrayList<RegistroActividad> actividades;

    public Asignacion(Persona persona, Gimnasio gimnasio) {
        this.persona = persona;
        this.gimnasio = gimnasio;
        this.actividades = new ArrayList<>();
    }

    public void agregarActividad(RegistroActividad actividad) {
        actividades.add(actividad);
    }

    public Persona getPersona() {
        return persona;
    }

    public Gimnasio getGimnasio() {
        return gimnasio;
    }

    public ArrayList<RegistroActividad> getActividades() {
        return actividades;
    }
}



/*package modelo;

import java.util.ArrayList;

public class Asignacion {
   *//* private ArrayList<RegistroActividad> actividades;

    public Asignacion(Persona persona) {
        this.persona = persona;
        this.actividades = new ArrayList<>();
    }

    private Gimnasio gimnasio;
    private ArrayList<RegistroActividad> actividades;

    public Asignacion(Persona persona, Gimnasio gimnasio) {
        this.persona = persona;
        this.gimnasio = gimnasio;
        this.actividades = new ArrayList<>();
    }*//*

    private Persona persona;
    private Gimnasio gimnasio;
    private ArrayList<RegistroActividad> actividades;

    public Asignacion(Persona persona, Gimnasio gimnasio, RegistroActividad actividad) {
        this.persona = persona;
        this.gimnasio = gimnasio;
        this.actividades = new ArrayList<>();
        this.actividades.add(actividad); // Agregar la actividad inicialmente
    }

    public void agregarActividad(RegistroActividad actividad) {
        actividades.add(actividad);
    }

    public Persona getPersona() {
        return persona;
    }

    public ArrayList<RegistroActividad> getActividades() {
        return actividades;
    }
}*/

