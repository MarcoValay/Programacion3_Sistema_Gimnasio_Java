package modelo;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;

public class SociosGYM extends Persona implements  Serializable{

    private ArrayList<Persona> personas;
    public SociosGYM(){
        this.personas=new ArrayList<>();
    }
    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    private static SociosGYM instancia = null;

    public static  SociosGYM getInstancia() {
        if (instancia == null) {
            instancia = new SociosGYM();
        }
        return instancia;
    }

    public  void agregarPersona2(String nombre,String apellido,
                                 String cedula,String id,String direccion,
                                 String telefono,String rol){
        SociosGYM.instancia.personas.add(new Persona(nombre,apellido,cedula,id,direccion,telefono,rol));
    }

    public void grabar(String nombreArchivo){
        try{
            ObjectOutputStream archivo= new ObjectOutputStream(new FileOutputStream(nombreArchivo));
            archivo.writeObject(instancia);
            archivo.flush();
            archivo.close();
            System.out.println("Datos grabados correctamente en " + nombreArchivo);
        } catch (IOException e) {
            //System.out.println(e.getMessage());
            System.out.println("Error al grabar archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public SociosGYM recuperar (String nombreArchivo) throws IOException {
        try {
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if (path.exists()) {
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                instancia = (SociosGYM) archivo.readObject();

                archivo.close();
            }
        } catch (ClassNotFoundException | IOException e) {

        }
        return instancia;
    }
    public int buscarCed(String dato) {
        int index=-1;
        for (int i = 0;i< instancia.personas.size(); i++) {
            if(Objects.equals(dato, instancia.personas.get(i).getNombre())
                    || Objects.equals(dato, instancia.personas.get(i).getApellido())
                    || Objects.equals(dato, instancia.personas.get(i).getCedula())
                    || Objects.equals(dato, instancia.personas.get(i).getId())
                    || Objects.equals(dato, instancia.personas.get(i).getDireccion())
                    || Objects.equals(dato, instancia.personas.get(i).getTelefono())
                    || Objects.equals(dato, instancia.personas.get(i).getRol())
            ){
                System.out.println("Encontrada");
                index = i;
                break;
            }
        }
        return index;
    }

    public void ordenarPersonas(Comparator<Persona> comparador) {
        personas.sort(comparador);
    }
    public void modificarSocio(int index,String nombre,String apellido,
                                   String cedula,String id,String direccion,
                                   String telefono,String rol) {
        System.out.println("index: "+index);
        System.out.println("per : "+personas.size());

        System.out.println("Numper2 : "+ instancia.personas.size());
        if (index >= 0 && index < instancia.personas.size()) {
            Persona persona = instancia.personas.get(index);
            persona.setNombre(nombre);
            persona.setApellido(apellido);
            persona.setCedula(cedula);
            persona.setId(id);
            persona.setDireccion(direccion);
            persona.setTelefono(telefono);
            persona.setRol(rol);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }

    public void eliminarSocio(int index) {
        if (index >= 0 && index < instancia.personas.size()) {
            instancia.personas.remove(index);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }
    public boolean existePersona(String cedula) {
        return personas.stream().anyMatch(persona -> persona.getCedula().equals(cedula));
    }


}
