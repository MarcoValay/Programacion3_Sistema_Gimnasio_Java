package modelo;

import java.util.ArrayList;

public class Administradores {

    private ArrayList<RegistroAdministrador> administradors;
    private static Administradores instancia = null;
    public Administradores(){
        this.administradors = new ArrayList<>();
    }
    public static Administradores getInstancia() {
        if (instancia == null) {
            instancia = new Administradores();
        }
        return instancia;
    }
    public  void agregarAdmin(RegistroAdministrador admin){
        this.administradors.add(admin);
    }
    public  void agregarAdmin2 (String nombre, String cedula, String direccion, String correo, String contrasenia){
        //this.administradors.add(admin);
        Administradores.getInstancia().administradors.add(new RegistroAdministrador(nombre, cedula, direccion,
                                                                                    correo, contrasenia));
    }
}
