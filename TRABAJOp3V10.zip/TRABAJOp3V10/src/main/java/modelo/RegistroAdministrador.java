package modelo;

import javax.swing.*;
import java.io.Serializable;

public class RegistroAdministrador implements Serializable {

    private String Nombre;
    private String Cedula;
    private String Direccion;
    private String Correo;
    private String Contrasenia;

    public RegistroAdministrador(){

    }
    public RegistroAdministrador(String nombre, String cedula, String direccion, String correo, String contrasenia) {
        Nombre = nombre;
        Cedula = cedula;
        Direccion = direccion;
        Correo = correo;
        Contrasenia = contrasenia;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String cedula) {
        Cedula = cedula;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        Direccion = direccion;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String getContrasenia() {
        return Contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        Contrasenia = contrasenia;
    }

    public boolean NombreCorrecto(String nombre){
        if(nombre.contains(" ") && nombre.length() > 3){
            return true;
        }else{
            return  false;
        }
    }
    public boolean CedulaCorrecta(String cedula){
        if(cedula.length() != 10) return false;

        int validador = 0;
        int[] mascara = {2, 1, 2, 1, 2, 1, 2, 1, 2};

        for(int i = 0; i < cedula.length() - 1; i++){
            if(mascara[i] * Integer.parseInt("" + cedula.charAt(i)) > 9){
                validador += (mascara[i] * Integer.parseInt("" + cedula.charAt(i))) - 9;
            }
            else{
                validador += mascara[i] * Integer.parseInt("" + cedula.charAt(i));
            }
        }

        if(validador % 10 == 0 && cedula.charAt(9) == '0') return true;

        validador = 10 - (validador % 10);

        if(validador == Integer.parseInt("" + cedula.charAt(9))) return  true;

        return false;

    }
    public boolean DireccionCorrecta(String direccion){
        if(direccion.length() >= 4){
            return true;
        }else{
            return false;
        }
    }
    public boolean CorreoCorrecto(String correo){
        String[] correoSplit = correo.split("[@.]");
        if(correoSplit.length >= 3){
            if(correoSplit[correoSplit.length - 1].equals("@") || correoSplit[correoSplit.length - 1].length() > 3){
                return false;
            }else{
                return true;
            }
        }
        return false;
    }

    public boolean ContraseniaCorrecta(String contrasenia){
        if(contrasenia.length() >= 4){
            return true;
        }else{
            return false;
        }
    }
}
