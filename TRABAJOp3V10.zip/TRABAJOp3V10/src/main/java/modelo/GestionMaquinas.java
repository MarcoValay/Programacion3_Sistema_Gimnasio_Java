package modelo;

import java.io.*;
import java.util.ArrayList;
import java.util.Objects;

public class GestionMaquinas implements Serializable {
    private ArrayList<Maquinas> maquinas;
    public GestionMaquinas(){
        this.maquinas=new ArrayList<>();
    }
    public ArrayList<Maquinas> getMaquinas() {
        return maquinas;
    }

    private static GestionMaquinas instancia = null;

    public static  GestionMaquinas getInstancia() {
        if (instancia == null) {
            instancia = new GestionMaquinas();
        }
        return instancia;
    }

    public  void agregarMaquina(String tipo, String nombre, String descripcion,
                               String fechadeAdquisicion, String codigo,
                               String estado, String fechadeMantenimiento,
                               String ubicaionGym, String codigoGym){
        GestionMaquinas.instancia.maquinas.add(new Maquinas(tipo, nombre, descripcion,
                fechadeAdquisicion, codigo,estado,fechadeMantenimiento, ubicaionGym, codigoGym));
    }

    public int buscarCed(String dato) {
        int index=-1;
        for (int i = 0;i< instancia.maquinas.size(); i++) {
            if(Objects.equals(dato, instancia.maquinas.get(i).getNombre())
                    || Objects.equals(dato, instancia.maquinas.get(i).getCodigo())
                    || Objects.equals(dato, instancia.maquinas.get(i).getEstado())
                    || Objects.equals(dato, instancia.maquinas.get(i).getCodigoGym())
                    || Objects.equals(dato, instancia.maquinas.get(i).getUbicaionGym())
            ){
                System.out.println("Encontrada");
                index = i;
                break;
            }
        }
        return index;
    }

    public void grabarMaquinas(String nombreArchivo){
        try{
            ObjectOutputStream archivo= new ObjectOutputStream(new FileOutputStream(nombreArchivo));
            archivo.writeObject(instancia);
            archivo.flush();
            archivo.close();
            System.out.println("Datos grabados correctamente en " + nombreArchivo);
        } catch (IOException e) {
            //System.out.println(e.getMessage());
            System.out.println("Error al grabar archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public GestionMaquinas recuperarMaquinas (String nombreArchivo) throws IOException {
        try {
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if (path.exists()) {
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                instancia = (GestionMaquinas) archivo.readObject();

                archivo.close();
            }
        } catch (ClassNotFoundException | IOException e) {

        }
        return instancia;
    }

    public void modificarMaquinas(int index,String tipo, String nombre, String descripcion,
                                String fechadeAdquisicion, String codigo,
                                String estado, String fechadeMantenimiento,
                                String ubicaionGym, String codigoGym) {

        if (index >= 0 && index < instancia.maquinas.size()) {
            Maquinas Maquinas = instancia.maquinas.get(index);
            Maquinas.setTipo(tipo);
            Maquinas.setNombre(nombre);
            Maquinas.setDescripcion(descripcion);
            Maquinas.setFechadeAdquisicion(fechadeAdquisicion);
            Maquinas.setCodigo(codigo);
            Maquinas.setEstado(estado);
            Maquinas.setFechadeMantenimiento(fechadeMantenimiento);
            Maquinas.setUbicaionGym(ubicaionGym);
            Maquinas.setCodigo(codigoGym);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }

    public void eliminarMaquina(int index) {
        if (index >= 0 && index < instancia.maquinas.size()) {
            instancia.maquinas.remove(index);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }
}
