package modelo;

import java.io.*;
import java.util.ArrayList;
import java.util.Objects;

public class Duenio implements Serializable{

    private ArrayList<Gimnasio> gimnasios;
    public Duenio(){
        this.gimnasios = new ArrayList<>();
    }

    public ArrayList<Gimnasio> getGimnasios() {
        return gimnasios;
    }

    private static Duenio instancia = null;

    public static  Duenio getInstancia() {
        if (instancia == null) {
            instancia = new Duenio();
        }
        return instancia;
    }

    public  void agregarGYM2(String nombre, String direccion, String telefono,
                             String nombreCalles, String codigo,
                             String fechaInicio, String fechaFin,
                             String horaInicio, String horaFin,
                             String ruc){
        Duenio.instancia.gimnasios.add(new Gimnasio(nombre,direccion, telefono,
                nombreCalles,codigo, fechaInicio, fechaFin,
                horaInicio, horaFin, ruc));
    }

    public int buscarCod(String codigo) {
        int index=-1;
        for (int i = 0;i< instancia.gimnasios.size(); i++) {
            if (Objects.equals(codigo, instancia.gimnasios.get(i).getCodigo())) {
                System.out.println("Encontrado");
                index = i;
                break;
            }
        }
        return index;
    }

    public void modificarGyms(int index,String nombre, String direccion, String telefono,
                                   String nombreCalles, String codigo,
                                   String fechaInicio, String fechaFin,
                                   String horaInicio, String horaFin,
                                   String ruc) {

        if (index >= 0 && index < instancia.gimnasios.size()) {
            Gimnasio gimnasio = instancia.gimnasios.get(index);
            gimnasio.setNombre(nombre);
            gimnasio.setDireccion(direccion);
            gimnasio.setTelefono(telefono);
            gimnasio.setNombreCalles(nombreCalles);
            gimnasio.setCodigo(codigo);
            gimnasio.setFechaInicio(fechaInicio);
            gimnasio.setFechaFin(fechaFin);
            gimnasio.setHoraInicio(horaInicio);
            gimnasio.setHoraFin(horaFin);
            gimnasio.setRuc(ruc);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }

    public void eliminarGyms(int index) {
        if (index >= 0 && index < instancia.gimnasios.size()) {
            instancia.gimnasios.remove(index);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }
    

    public void grabar(String nombreArchivo){
        try{
            ObjectOutputStream archivo= new ObjectOutputStream(new FileOutputStream(nombreArchivo));
            archivo.writeObject(instancia);
            archivo.flush();
            archivo.close();
            System.out.println("Datos grabados correctamente en " + nombreArchivo);
        } catch (IOException e) {
            //System.out.println(e.getMessage());
            System.out.println("Error al grabar archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public Duenio recuperar(String nombreArchivo) throws IOException {
        try {
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if (path.exists()) {
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                instancia = (Duenio) archivo.readObject();
                archivo.close();
            }
        } catch (ClassNotFoundException | IOException e) {
        }
        return instancia;
    }
    public boolean existeGimnasio(String nombre, String direccion, String telefono, String nombreCalles, String codigo, String ruc) {
        return gimnasios.stream().anyMatch(gimnasio ->
                gimnasio.getNombre().equals(nombre) &&
                        gimnasio.getDireccion().equals(direccion) &&
                        gimnasio.getTelefono().equals(telefono) &&
                        gimnasio.getNombreCalles().equals(nombreCalles) &&
                        gimnasio.getCodigo().equals(codigo) &&
                        gimnasio.getRuc().equals(ruc)
        );
    }

}
