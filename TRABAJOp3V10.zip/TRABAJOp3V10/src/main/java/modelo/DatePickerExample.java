package modelo;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.SqlDateModel;

import javax.swing.*;
import java.util.Properties;

public class DatePickerExample {

    public static void main(String[] args) {
        // Crear el modelo de la fecha
        SqlDateModel model = new SqlDateModel();
        model.setDate(2024, 5, 20); // Establecer fecha inicial (Año, Mes, Día)
        model.setSelected(true);

        // Crear las propiedades
        Properties p = new Properties();
        p.put("text.today", "Hoy");
        p.put("text.month", "Mes");
        p.put("text.year", "Año");

        // Crear el panel de fecha
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        // Crear el picker de fecha
        JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());

        // Crear el frame y añadir el JDatePicker
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(datePicker);
        frame.pack();
        frame.setVisible(true);
    }
}


