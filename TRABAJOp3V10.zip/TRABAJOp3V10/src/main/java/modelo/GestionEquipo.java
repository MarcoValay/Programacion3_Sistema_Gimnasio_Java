package modelo;

import java.io.*;
import java.util.ArrayList;
import java.util.Objects;

public class GestionEquipo implements Serializable {
    private ArrayList<Equipo> equipos;
    public GestionEquipo(){
        this.equipos=new ArrayList<>();
    }
    public ArrayList<Equipo> getEquipos() {
        return equipos;
    }

    private static GestionEquipo instancia = null;

    public static  GestionEquipo getInstancia() {
        if (instancia == null) {
            instancia = new GestionEquipo();
        }
        return instancia;
    }

    public  void agregarEquipo(String tipo, String nombre, String descripcion,
                               String fechadeAdquisicion, String codigo,
                               String estado, String fechadeMantenimiento,
                               String ubicaionGym, String codigoGym){
        GestionEquipo.instancia.equipos.add(new Equipo(tipo, nombre, descripcion,
                fechadeAdquisicion, codigo,estado,fechadeMantenimiento, ubicaionGym, codigoGym));
    }

    public int buscarCed(String dato) {
        int index=-1;
        for (int i = 0;i< instancia.equipos.size(); i++) {
            if(Objects.equals(dato, instancia.equipos.get(i).getNombre())
                    || Objects.equals(dato, instancia.equipos.get(i).getCodigo())
                    || Objects.equals(dato, instancia.equipos.get(i).getEstado())
                    || Objects.equals(dato, instancia.equipos.get(i).getCodigoGym())
                    || Objects.equals(dato, instancia.equipos.get(i).getUbicaionGym())
            ){
                System.out.println("Encontrada");
                index = i;
                break;
            }
        }
        return index;
    }

    public void grabar(String nombreArchivo){
        try{
            ObjectOutputStream archivo= new ObjectOutputStream(new FileOutputStream(nombreArchivo));
            archivo.writeObject(instancia);
            archivo.flush();
            archivo.close();
            System.out.println("Datos grabados correctamente en " + nombreArchivo);
        } catch (IOException e) {
            //System.out.println(e.getMessage());
            System.out.println("Error al grabar archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public GestionEquipo recuperarEquipos (String nombreArchivo) throws IOException {
        try {
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if (path.exists()) {
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                instancia = (GestionEquipo) archivo.readObject();

                archivo.close();
            }
        } catch (ClassNotFoundException | IOException e) {

        }
        return instancia;
    }

    public void modificarEquipo(int index,String tipo, String nombre, String descripcion,
                                String fechadeAdquisicion, String codigo,
                                String estado, String fechadeMantenimiento,
                                String ubicaionGym, String codigoGym) {

        if (index >= 0 && index < instancia.equipos.size()) {
            Equipo equipo = instancia.equipos.get(index);
            equipo.setTipo(tipo);
            equipo.setNombre(nombre);
            equipo.setDescripcion(descripcion);
            equipo.setFechadeAdquisicion(fechadeAdquisicion);
            equipo.setCodigo(codigo);
            equipo.setEstado(estado);
            equipo.setFechadeMantenimiento(fechadeMantenimiento);
            equipo.setUbicaionGym(ubicaionGym);
            equipo.setCodigo(codigoGym);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }

    public void eliminarEquipo(int index) {
        if (index >= 0 && index < instancia.equipos.size()) {
            instancia.equipos.remove(index);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }
}
