package modelo;

import java.io.*;
import java.util.*;

public class GestionAsignarGimnasios implements Serializable {

    private Map<Gimnasio,  List<Asignacion>> asignaciones;

    public GestionAsignarGimnasios() {
        this.asignaciones = new HashMap<>();
    }

    public void agregarAsignacion(Gimnasio gimnasio, Asignacion asignacion) {
        if (asignaciones.containsKey(gimnasio)) {
            asignaciones.get(gimnasio).add(asignacion);
        } else {
            List<Asignacion> listaAsignaciones = new ArrayList<>();
            listaAsignaciones.add(asignacion);
            asignaciones.put(gimnasio, listaAsignaciones);
        }
    }
    public List<Asignacion> obtenerAsignaciones(Gimnasio gimnasio) {
        return asignaciones.get(gimnasio);
    }

    public Map<Gimnasio, List<Asignacion>> getAsignaciones() {
        return asignaciones;
    }


    public void guardarAsignaciones(String nombreArchivo) {
        try {
            ObjectOutputStream archivo = new ObjectOutputStream(new FileOutputStream(nombreArchivo));
            archivo.writeObject(asignaciones);
            archivo.flush();
            archivo.close();
            System.out.println("Asignaciones guardadas correctamente en " + nombreArchivo);
        } catch (IOException e) {
            System.out.println("Error al guardar las asignaciones: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void cargarAsignaciones(String nombreArchivo) {
        try {
            ObjectInputStream archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
            asignaciones = (Map<Gimnasio, List<Asignacion>>) archivo.readObject();
            archivo.close();
            System.out.println("Asignaciones cargadas correctamente desde " + nombreArchivo);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar las asignaciones: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /*public void setAsignaciones(Map<Gimnasio, List<Asignacion>> asignaciones) {
        this.asignaciones = asignaciones;
    }

    public Asignacion obtenerAsignacion(Gimnasio gimnasio) {
        return asignaciones.get(gimnasio);
    }

    public Map<Gimnasio, Asignacion> getAsignaciones() {
        return asignaciones;
    }*/

    /*public void setAsignaciones(Map<Gimnasio, Asignacion> asignaciones) {
        this.asignaciones = asignaciones;
    }*/
    // Nuevo método para asignar una actividad a un gimnasio y socio específicos
    /*public void asignarActividadASocio(Gimnasio gimnasio, Persona socio, RegistroActividad actividad) {
        // Obtener la asignación actual o crear una nueva si no existe
        Asignacion asignacion = obtenerAsignacion(gimnasio);
        if (asignacion == null) {
            asignacion = new Asignacion(socio, gimnasio, actividad);
            agregarAsignacion(gimnasio, asignacion);
        } else {
            asignacion.agregarActividad(actividad);
        }
    }*/

    /*
    // Nuevo método para asignar una actividad a un gimnasio y socio específicos
    public void asignarActividadASocio(Gimnasio gimnasio, Persona socio, RegistroActividad actividad) {
        // Crear la asignación
        Asignacion asignacion = new Asignacion(socio, actividad);

        // Agregar la asignación al gimnasio
        agregarAsignacion(gimnasio, asignacion);
    }

    // Método para guardar datos en un archivo
    public void guardarAsignaciones(String nombreArchivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            oos.writeObject(this.asignaciones);
            System.out.println("Asignaciones guardadas correctamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar asignaciones: " + e.getMessage());
        }
    }

    // Método para cargar datos desde un archivo
    public void cargarAsignaciones(String nombreArchivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            this.asignaciones = (Map<Gimnasio, Asignacion>) ois.readObject();
            System.out.println("Asignaciones cargadas correctamente.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar asignaciones: " + e.getMessage());
        }
    }*/

    /*private Map<Gimnasio, ArrayList<Persona>> personasAsignadas;
    private Map<Gimnasio, ArrayList<RegistroActividad>> actividadesAsignadas;

    public GestionAsignarGimnasios() {
        this.personasAsignadas = new HashMap<>();
        this.actividadesAsignadas = new HashMap<>();
    }


    // Métodos para trabajar con el mapa
    public void agregarPersona(Gimnasio gimnasio, Persona persona) {
        if (personasAsignadas.containsKey(gimnasio)) {
            personasAsignadas.get(gimnasio).add(persona);
        } else {
            ArrayList<Persona> listaPersonas = new ArrayList<>();
            listaPersonas.add(persona);
            personasAsignadas.put(gimnasio, listaPersonas);
        }
    }

    public void agregarActividad(Gimnasio gimnasio, RegistroActividad actividad) {
        if (actividadesAsignadas.containsKey(gimnasio)) {
            actividadesAsignadas.get(gimnasio).add(actividad);
        } else {
            ArrayList<RegistroActividad> listaActividades = new ArrayList<>();
            listaActividades.add(actividad);
            actividadesAsignadas.put(gimnasio, listaActividades);
        }
    }

    public ArrayList<Persona> obtenerPersonasAsignadas(Gimnasio gimnasio) {
        return personasAsignadas.getOrDefault(gimnasio, new ArrayList<>());
    }

    public ArrayList<RegistroActividad> obtenerActividadesAsignadas(Gimnasio gimnasio) {
        return actividadesAsignadas.getOrDefault(gimnasio, new ArrayList<>());
    }

    public Map<Gimnasio, ArrayList<Persona>> getPersonasAsignadas() {
        return personasAsignadas;
    }

    public void setPersonasAsignadas(Map<Gimnasio, ArrayList<Persona>> personasAsignadas) {
        this.personasAsignadas = personasAsignadas;
    }

    public Map<Gimnasio, ArrayList<RegistroActividad>> getActividadesAsignadas() {
        return actividadesAsignadas;
    }

    public void setActividadesAsignadas(Map<Gimnasio, ArrayList<RegistroActividad>> actividadesAsignadas) {
        this.actividadesAsignadas = actividadesAsignadas;
    }*/
}