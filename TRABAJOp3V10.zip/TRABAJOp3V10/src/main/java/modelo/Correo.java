package modelo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Date;
import java.util.Properties;
import java.util.TimerTask;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.*;
import java.util.Timer;



public class Correo implements Runnable{
    private String correoDeOrigen;
    private String correoDeDestino;
    private String asunto;
    private String mensajeDeTexto;
    private String archivoAdjunto;
    private String archivoAdjunto2;
    private String contraseña16Digitos;


    public Correo(String destino, String asunto, String txt) {
            this.correoDeOrigen = "marcof.valarezoy@ucuenca.edu.ec";
            this.correoDeDestino = destino;
            this.asunto = asunto;
            this.mensajeDeTexto = txt;
            this.contraseña16Digitos = "melbvhossoojeedn";
    }

    public void setArchivoAdjunto(String dirAdjunto) {
            this.archivoAdjunto = dirAdjunto;
        }
    public void setArchivoAdjunto2(String dirAdjunto2) {
            this.archivoAdjunto2 = dirAdjunto2;
        }

    public void envioDeCorreos() {
            envioDeMensajes();
        }

    private void envioDeMensajes() {
            try {
                Properties p = new Properties();
                p.put("mail.smtp.host", "smtp.gmail.com");
                p.setProperty("mail.smtp.starttls.enable", "true");
                p.put("mail.smtp.ssl.trust", "smtp.gmail.com");
                p.setProperty("mail.smtp.port", "587");
                p.setProperty("mail.smtp.user", correoDeOrigen);
                p.setProperty("mail.smtp.auth", "true");
                Session s = Session.getDefaultInstance(p);

                MimeMultipart m = new MimeMultipart();

                BodyPart texto = new MimeBodyPart();
                texto.setText(mensajeDeTexto);
                m.addBodyPart(texto);

                if (archivoAdjunto != null && !archivoAdjunto.isEmpty()) {
                    BodyPart adjunto = new MimeBodyPart();
                    adjunto.setDataHandler(new DataHandler(new FileDataSource(archivoAdjunto)));
                    adjunto.setFileName(new File(archivoAdjunto).getName());
                    m.addBodyPart(adjunto);
                }

                if (archivoAdjunto2 != null && !archivoAdjunto2.isEmpty()) {
                    BodyPart adjunto2 = new MimeBodyPart();
                    adjunto2.setDataHandler(new DataHandler(new FileDataSource(archivoAdjunto2)));
                    adjunto2.setFileName(new File(archivoAdjunto2).getName());
                    m.addBodyPart(adjunto2);
                }

                MimeMessage mensaje = new MimeMessage(s);
                mensaje.setFrom(new InternetAddress(correoDeOrigen));
                mensaje.addRecipient(Message.RecipientType.TO, new InternetAddress(correoDeDestino));
                mensaje.setSubject(asunto);
                if (archivoAdjunto == null && archivoAdjunto2 == null) {
                    mensaje.setText(mensajeDeTexto);
                } else {
                    mensaje.setContent(m);
                }

                Transport t = s.getTransport("smtp");
                t.connect(correoDeOrigen, contraseña16Digitos);
                t.sendMessage(mensaje, mensaje.getAllRecipients());
                t.close();

                JOptionPane.showMessageDialog(null, "Mensaje enviado.");
            } catch (MessagingException e) {
                JOptionPane.showMessageDialog(null, "Error al enviar el mensaje.");
            }
   }

    @Override
    public void run() {
        envioDeMensajes();
    }

    public void programarEnvio(Date fechaEnvio) {
        Timer timer = new Timer();
        TimerTask tarea = new TimerTask() {
            @Override
            public void run() {
                envioDeMensajes();
            }
        };
        timer.schedule(tarea, fechaEnvio);
    }
}
