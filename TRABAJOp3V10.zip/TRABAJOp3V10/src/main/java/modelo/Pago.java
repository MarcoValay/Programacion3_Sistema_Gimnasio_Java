package modelo;

import controlador.CtrlPagos;
import vista.ventanaGestionPagos;

import java.io.Serializable;

public class Pago implements Serializable {
        private String nombre;
        private String apellido;
        private String cedula;
        private String id;
        private String direccion;
        private String telefono;
        private String monto;
        private String membresia;
        private String fecha;

        public Pago(){
        }
        public Pago(String nombre, String apellido, String cedula,
                    String id, String direccion,
                    String telefono, String monto,
                    String membresia, String fecha) {
            this.nombre = nombre;
            this.apellido = apellido;
            this.cedula = cedula;
            this.id = id;
            this.direccion = direccion;
            this.telefono = telefono;
            this.monto = monto;
            this.membresia = membresia;
            this.fecha = fecha;
        }

        // Getters y Setters

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getApellido() {
            return apellido;
        }

        public void setApellido(String apellido) {
            this.apellido = apellido;
        }

        public String getCedula() {
            return cedula;
        }

        public void setCedula(String cedula) {
            this.cedula = cedula;
        }

        public String getDireccion() {
            return direccion;
        }

        public void setDireccion(String direccion) {
            this.direccion = direccion;
        }

        public String getTelefono() {
            return telefono;
        }

        public void setTelefono(String telefono) {
            this.telefono = telefono;
        }

        public String getMonto() {
        return monto;
    }

        public void setMonto(String monto) {
        this.monto = monto;
    }

        public String getFecha() {
        return fecha;
    }

        public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMembresia() {
        return membresia;
    }

    public void setMembresia(String membresia) {
        this.membresia = membresia;
    }
}
