package modelo;

public class Personal {
    String rol;
}
