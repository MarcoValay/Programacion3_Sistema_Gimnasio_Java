package modelo;

import java.util.HashMap;
import java.util.Map;

public class UsuarioActividad {
    private String nombreUsuario;
    private String apellidoUsuario;
    private String cedulaUsuario;
    private String direccionUsuario;
    private String telefonoUsuario;
    private String rolUsuario;

    private String nombreActividad;
    private String descripcionActividad;
    private String codigoActividad;
    private String cupoActividad;
    private String costoActividad;
    private String disponibleActividad;
    private String diasActividad;
    private String claseActividad;
    private String hInicioActividad;
    private String hFinActividad;

    public UsuarioActividad(String nombreUsuario, String apellidoUsuario, String cedulaUsuario,
                            String direccionUsuario, String telefonoUsuario, String rolUsuario,
                            String nombreActividad, String descripcionActividad, String codigoActividad,
                            String cupoActividad, String costoActividad, String disponibleActividad,
                            String diasActividad, String claseActividad, String hInicioActividad,
                            String hFinActividad) {
        this.nombreUsuario = nombreUsuario;
        this.apellidoUsuario = apellidoUsuario;
        this.cedulaUsuario = cedulaUsuario;
        this.direccionUsuario = direccionUsuario;
        this.telefonoUsuario = telefonoUsuario;
        this.rolUsuario = rolUsuario;
        this.nombreActividad = nombreActividad;
        this.descripcionActividad = descripcionActividad;
        this.codigoActividad = codigoActividad;
        this.cupoActividad = cupoActividad;
        this.costoActividad = costoActividad;
        this.disponibleActividad = disponibleActividad;
        this.diasActividad = diasActividad;
        this.claseActividad = claseActividad;
        this.hInicioActividad = hInicioActividad;
        this.hFinActividad = hFinActividad;
    }

    public UsuarioActividad() {

    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getApellidoUsuario() {
        return apellidoUsuario;
    }

    public void setApellidoUsuario(String apellidoUsuario) {
        this.apellidoUsuario = apellidoUsuario;
    }

    public String getCedulaUsuario() {
        return cedulaUsuario;
    }

    public void setCedulaUsuario(String cedulaUsuario) {
        this.cedulaUsuario = cedulaUsuario;
    }

    public String getDireccionUsuario() {
        return direccionUsuario;
    }

    public void setDireccionUsuario(String direccionUsuario) {
        this.direccionUsuario = direccionUsuario;
    }

    public String getTelefonoUsuario() {
        return telefonoUsuario;
    }

    public void setTelefonoUsuario(String telefonoUsuario) {
        this.telefonoUsuario = telefonoUsuario;
    }

    public String getRolUsuario() {
        return rolUsuario;
    }

    public void setRolUsuario(String rolUsuario) {
        this.rolUsuario = rolUsuario;
    }

    public String getNombreActividad() {
        return nombreActividad;
    }

    public void setNombreActividad(String nombreActividad) {
        this.nombreActividad = nombreActividad;
    }

    public String getDescripcionActividad() {
        return descripcionActividad;
    }

    public void setDescripcionActividad(String descripcionActividad) {
        this.descripcionActividad = descripcionActividad;
    }

    public String getCodigoActividad() {
        return codigoActividad;
    }

    public void setCodigoActividad(String codigoActividad) {
        this.codigoActividad = codigoActividad;
    }

    public String getCupoActividad() {
        return cupoActividad;
    }

    public void setCupoActividad(String cupoActividad) {
        this.cupoActividad = cupoActividad;
    }

    public String getCostoActividad() {
        return costoActividad;
    }

    public void setCostoActividad(String costoActividad) {
        this.costoActividad = costoActividad;
    }

    public String getDisponibleActividad() {
        return disponibleActividad;
    }

    public void setDisponibleActividad(String disponibleActividad) {
        this.disponibleActividad = disponibleActividad;
    }

    public String getDiasActividad() {
        return diasActividad;
    }

    public void setDiasActividad(String diasActividad) {
        this.diasActividad = diasActividad;
    }

    public String getClaseActividad() {
        return claseActividad;
    }

    public void setClaseActividad(String claseActividad) {
        this.claseActividad = claseActividad;
    }

    public String gethInicioActividad() {
        return hInicioActividad;
    }

    public void sethInicioActividad(String hInicioActividad) {
        this.hInicioActividad = hInicioActividad;
    }

    public String gethFinActividad() {
        return hFinActividad;
    }

    public void sethFinActividad(String hFinActividad) {
        this.hFinActividad = hFinActividad;
    }

    public Map<String, String> llenarMapa() {
        Map<String, String> mapa = new HashMap<>();

        mapa.put("nombreUsuario", this.nombreUsuario);
        mapa.put("apellidoUsuario", this.apellidoUsuario);
        mapa.put("cedulaUsuario", this.cedulaUsuario);
        mapa.put("direccionUsuario", this.direccionUsuario);
        mapa.put("telefonoUsuario", this.telefonoUsuario);
        mapa.put("rolUsuario", this.rolUsuario);
        mapa.put("nombreActividad", this.nombreActividad);
        mapa.put("descripcionActividad", this.descripcionActividad);
        mapa.put("codigoActividad", this.codigoActividad);
        mapa.put("cupoActividad", this.cupoActividad);
        mapa.put("costoActividad", this.costoActividad);
        mapa.put("disponibleActividad", this.disponibleActividad);
        mapa.put("diasActividad", this.diasActividad);
        mapa.put("claseActividad", this.claseActividad);
        mapa.put("hInicioActividad", this.hInicioActividad);
        mapa.put("hFinActividad", this.hFinActividad);

        return mapa;
    }
}
