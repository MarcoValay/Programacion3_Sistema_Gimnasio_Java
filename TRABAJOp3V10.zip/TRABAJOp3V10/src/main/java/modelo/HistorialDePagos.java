package modelo;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class HistorialDePagos implements Serializable{
    private ArrayList<Pago> pagos;
    public HistorialDePagos() {
        this.pagos = new ArrayList<>();
    }
    public ArrayList<Pago> getPagos() {
        return pagos;
    }
    private static HistorialDePagos instancia = null;
    public static  HistorialDePagos getInstancia() {
        if (instancia == null) {
            instancia = new HistorialDePagos();
        }
        return instancia;
    }
    public void agregarPago(Pago pago) {
        pagos.add(pago);
    }
    public  void agregarPago2(String nombre,String apellido,
                                 String cedula,String id,String direccion,
                                 String telefono, String monto, String membresia, String fecha){
        HistorialDePagos.instancia.pagos.add(new Pago(nombre,apellido,cedula,id,direccion,telefono,monto,membresia,fecha));
    }

    public void grabar(String nombreArchivo){
        try{
            ObjectOutputStream archivo= new ObjectOutputStream(new FileOutputStream(nombreArchivo));
            archivo.writeObject(instancia);
            archivo.flush();
            archivo.close();
            System.out.println("Datos grabados correctamente en " + nombreArchivo);
        } catch (IOException e) {
            //System.out.println(e.getMessage());
            System.out.println("Error al grabar archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public HistorialDePagos recuperar (String nombreArchivo) throws IOException {
        try {
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if (path.exists()) {
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                instancia = (HistorialDePagos) archivo.readObject();

                archivo.close();
            }
        } catch (ClassNotFoundException | IOException e) {

        }
        return instancia;
    }
    public int buscar(String dato) {
        int index=-1;
        for (int i = 0;i< instancia.pagos.size(); i++) {
            if(Objects.equals(dato, instancia.pagos.get(i).getNombre())
                    || Objects.equals(dato, instancia.pagos.get(i).getApellido())
                    || Objects.equals(dato, instancia.pagos.get(i).getCedula())
                    || Objects.equals(dato, instancia.pagos.get(i).getId())
                    || Objects.equals(dato, instancia.pagos.get(i).getDireccion())
                    || Objects.equals(dato, instancia.pagos.get(i).getTelefono())
                    || Objects.equals(dato, instancia.pagos.get(i).getMonto())
                    || Objects.equals(dato, instancia.pagos.get(i).getMembresia())
                    || Objects.equals(dato, instancia.pagos.get(i).getFecha())
            ){
                System.out.println("Encontrada");
                index = i;
                break;
            }
        }
        return index;
    }
    public void ordenarPagos(Comparator<Pago> comparador) {
        pagos.sort(comparador);
    }
    public void modificarHistorial(int index,String nombre,String apellido,
                                   String cedula,String id,String direccion,
                                   String telefono, String monto, String membresia, String fecha) {
        System.out.println("index: "+index);
        //System.out.println("per : "+pago.size());
        System.out.println("Numper2 : "+ instancia.pagos.size());

        if (index >= 0 && index < instancia.pagos.size()) {
            Pago pago = instancia.pagos.get(index);
            pago.setNombre(nombre);
            pago.setApellido(apellido);
            pago.setCedula(cedula);
            pago.setId(id);
            pago.setDireccion(direccion);
            pago.setTelefono(telefono);
            pago.setMonto(monto);
            pago.setMembresia(membresia);
            pago.setFecha(fecha);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }

    public void eliminarHistorial(int index) {
        if (index >= 0 && index < instancia.pagos.size()) {
            instancia.pagos.remove(index);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }
}
