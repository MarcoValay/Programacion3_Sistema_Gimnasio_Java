package modelo;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Actividades implements Serializable{

    private ArrayList<RegistroActividad> actividades;
    private static Actividades instancia = null;

    public Actividades(){
        this.actividades = new ArrayList<>();
    }

    public static Actividades getInstancia() {
        if (instancia == null) {
            instancia = new Actividades();
        }
        return instancia;
    }

    public ArrayList<RegistroActividad> getActividades() {
        return actividades;
    }

    public  void agregarActividad(String nombre, String discripcion,
                                  String codigo, String cupo,String Reserva, String Costo,
                                  String disponible, String dias, String Clase,String Entrenador,
                                  String hinicio, String hfin) {
        Actividades.instancia.actividades.add(new RegistroActividad(nombre, discripcion, codigo, cupo,Reserva,Costo,
                                                                    disponible, dias,Clase,Entrenador, hinicio, hfin));
    }

    public void modificarActividad(int index, String nombre, String descripcion, String codigo, String cupo,String reserva,String Costo,
                                   String disponible, String dias,String Clase,String entrenador, String hinicio, String hfin) {
        if (index >= 0 && index < instancia.actividades.size()) {
            RegistroActividad actividad = instancia.actividades.get(index);
            actividad.setNombre(nombre);
            actividad.setDescripcion(descripcion);
            actividad.setCodigo(codigo);
            actividad.setCupo(cupo);
            actividad.setReservar(reserva);
            actividad.setCosto(Costo);
            actividad.setDisponible(disponible);
            actividad.setDias(dias);
            actividad.setClase(Clase);
            actividad.setEntrenador(entrenador);
            actividad.setHinicio(hinicio);
            actividad.setHfin(hfin);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }

    /*public double calcularCostoTotalActividades() {
        double total = 0;

        for (RegistroActividad registroActividad: Actividades.instancia.getActividades() ) {
            total += Double.parseDouble(registroActividad.getCosto());
        }
        return total;
    }*/

    public List<RegistroActividad> obtenerActividades() {
        return Actividades.instancia.getActividades();
    }

    public void eliminarActividad(int index) {
        if (index >= 0 && index < instancia.actividades.size()) {
            instancia.actividades.remove(index);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }

    public void grabar(String nombreArchivo){
        try{
            ObjectOutputStream archivo= new ObjectOutputStream(new FileOutputStream(nombreArchivo));
            archivo.writeObject(instancia);
            archivo.flush();
            archivo.close();
            System.out.println("Datos grabados correctamente en " + nombreArchivo);
        } catch (IOException e) {
            //System.out.println(e.getMessage());
            System.out.println("Error al grabar archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public Actividades recuperar (String nombreArchivo) throws IOException {
        try {
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if (path.exists()) {
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                instancia = (Actividades) archivo.readObject();
                archivo.close();
            }
        } catch (ClassNotFoundException | IOException e) {

        }
        return instancia;
    }
}
