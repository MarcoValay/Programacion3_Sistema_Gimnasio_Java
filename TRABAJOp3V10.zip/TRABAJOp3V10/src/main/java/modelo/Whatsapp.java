package modelo;

import com.twilio.Twilio;
import com.twilio.converter.Promoter;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
public class Whatsapp {

    public static final String ACCOUNT_SID = "AC0a746ad919002a68b55ddf9fefb4d108";
    public static final String AUTH_TOKEN = "94437dd34781399e6207b2219644d34a";
    private String numeroOrigen;
    private String numeroDestino;

    private String mensaje;

    public Whatsapp( String numeroDestino, String mensaje) {
        this.numeroOrigen = numeroOrigen;
        this.numeroDestino = numeroDestino;
        this.mensaje = mensaje;
    }

    public void setNumeroDestino(String numeroDestino) {
        this.numeroDestino = numeroDestino;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public void envioMensajeWpp(){
        envioWpp(numeroDestino,mensaje);
    }

    private void envioWpp(String numeroDestino,String mensaje){

        Twilio.init(ACCOUNT_SID,AUTH_TOKEN);
        Message message= Message.creator(new PhoneNumber("whatsapp:"+numeroDestino),
                new PhoneNumber("whatsapp:+14155238886"),
                mensaje).create();
    }
}
