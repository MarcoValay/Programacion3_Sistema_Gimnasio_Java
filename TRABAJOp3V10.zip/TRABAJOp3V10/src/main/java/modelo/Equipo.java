package modelo;

import java.io.Serializable;

public class Equipo implements Serializable {
     private String Tipo;
     private String Nombre;
     private String Descripcion;
     private String FechadeAdquisicion;
     private String Codigo;
     private String Estado;
     private String FechadeMantenimiento;
     private String UbicaionGym;
     private String CodigoGym;
    public Equipo(){}

    public Equipo(String tipo, String nombre, String descripcion,
                  String fechadeAdquisicion, String codigo,
                  String estado, String fechadeMantenimiento,
                  String ubicaionGym, String codigoGym) {
        Tipo = tipo;
        Nombre = nombre;
        Descripcion = descripcion;
        FechadeAdquisicion = fechadeAdquisicion;
        Codigo = codigo;
        Estado = estado;
        FechadeMantenimiento = fechadeMantenimiento;
        UbicaionGym = ubicaionGym;
        CodigoGym = codigoGym;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getFechadeAdquisicion() {
        return FechadeAdquisicion;
    }

    public void setFechadeAdquisicion(String fechadeAdquisicion) {
        FechadeAdquisicion = fechadeAdquisicion;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String codigo) {
        Codigo = codigo;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String estado) {
        Estado = estado;
    }

    public String getFechadeMantenimiento() {
        return FechadeMantenimiento;
    }

    public void setFechadeMantenimiento(String fechadeMantenimiento) {
        FechadeMantenimiento = fechadeMantenimiento;
    }

    public String getUbicaionGym() {
        return UbicaionGym;
    }

    public void setUbicaionGym(String ubicaionGym) {
        UbicaionGym = ubicaionGym;
    }

    public String getCodigoGym() {
        return CodigoGym;
    }

    public void setCodigoGym(String codigoGym) {
        CodigoGym = codigoGym;
    }

    public boolean NombreCorrecto(String nombre){
        if(nombre.length() >= 3){
            return true;
        }else{
            return  false;
        }
    }

    public boolean DescripcionCorrecta(String nombre){
        if(nombre.length() >= 3){
            return true;
        }else{
            return  false;
        }
    }

    public boolean CodigoCorrecto(String nombre){
        if(nombre.length() >= 3){
            return true;
        }else{
            return  false;
        }
    }
}
