package modelo;

public class Horario {
    private String fecha;
    private String hInicio;
    private String hFin;
    public Horario() {
    }
    public Horario(String fecha, String hInicio, String hFin) {
        this.fecha = fecha;
        this.hInicio = hInicio;
        this.hFin = hFin;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String gethInicio() {
        return hInicio;
    }

    public void sethInicio(String hInicio) {
        this.hInicio = hInicio;
    }

    public String gethFin() {
        return hFin;
    }

    public void sethFin(String hFin) {
        this.hFin = hFin;
    }
}
