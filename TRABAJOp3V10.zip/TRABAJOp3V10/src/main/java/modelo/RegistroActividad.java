package modelo;

import java.io.Serializable;

public class RegistroActividad implements Serializable {

    private String Nombre;
    private String Descripcion;
    private String Codigo;
    private String Cupo;
    private String Reservar;
    private String Costo;
    private String Disponible;
    private String Dias;
    private String Clase;
    private String Entrenador;
    private String Hinicio;
    private String Hfin;

    public RegistroActividad(String nombre, String descripcion, String codigo, String cupo,String reservar, String costo,
                             String disponible, String dias, String clase,String entrenador, String hinicio, String hfin) {
        Nombre = nombre;
        Descripcion = descripcion;
        Codigo = codigo;
        Cupo = cupo;

        Reservar = reservar;
        Costo = costo;
        Disponible = disponible;
        Dias = dias;

        Clase = clase;
        Entrenador = entrenador;
        Hinicio = hinicio;
        Hfin = hfin;
    }

    public RegistroActividad(){
        
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String codigo) {
        Codigo = codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        Descripcion = Descripcion;
    }

    public String getCupo() {
        return Cupo;
    }

    public void setCupo(String cupo) {
        Cupo = cupo;
    }

    public String getCosto() {
        return Costo;
    }

    public void setCosto(String costo) {
        Costo = costo;
    }

    public String getDisponible() {
        return Disponible;
    }

    public void setDisponible(String disponible) {
        Disponible = disponible;
    }

    public String getHinicio() {
        return Hinicio;
    }

    public void setHinicio(String hinicio) {
        Hinicio = hinicio;
    }

    public String getHfin() {
        return Hfin;
    }

    public void setHfin(String hfin) {
        Hfin = hfin;
    }

    public String getDias() {
        return Dias;
    }

    public void setDias(String dias) {
        Dias = dias;
    }

    public String getClase() {
        return Clase;
    }

    public void setClase(String clase) {
        Clase = clase;
    }

    public String getReservar() {
        return Reservar;
    }

    public void setReservar(String reservar) {
        Reservar = reservar;
    }

    public String getEntrenador() {
        return Entrenador;
    }

    public void setEntrenador(String entrenador) {
        Entrenador = entrenador;
    }

    public boolean CupoCorrecto(String cupo) {
        if (Integer.parseInt(cupo) >= 3 || Integer.parseInt(cupo)  <= 100) {
            return true;
        } else {
            return false;
        }
    }
}