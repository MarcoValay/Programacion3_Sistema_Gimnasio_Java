package modelo;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.List;

public class Gimnasio implements Serializable {

    private String nombre;
    private String direccion;
    private String telefono;
    private String nombreCalles;
    private String codigo;
    private String fechaInicio;
    private String fechaFin;
    private ArrayList<SociosGYM> socios;  // Lista para almacenar los socios
    public Gimnasio() {
    }
    public Gimnasio(String nombre, String direccion, String telefono,
                    String nombreCalles, String codigo,
                    String fechaInicio, String fechaFin,
                    String horaInicio, String horaFin,
                    String ruc) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.nombreCalles = nombreCalles;
        this.codigo = codigo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.ruc = ruc;
        this.socios = new ArrayList<>();  // Inicializar la lista de socios
    }
    private String horaInicio;
    private String horaFin;
    private String ruc;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getNombreCalles() {
        return nombreCalles;
    }
    public void setNombreCalles(String nombreCalles) {
        this.nombreCalles = nombreCalles;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public boolean NombreCorrecto(String nombre){
        if(nombre.length() >= 3){
            return true;
        }else{
            return  false;
        }
    }

    public boolean DireccionCorrecto(String nombre){
        if(nombre.length() >= 3){
            return true;
        }else{
            return  false;
        }
    }
    public boolean TelefonoCorrecto(String telefono){
        if(telefono.length() == 7 || telefono.length() == 10){
            if(telefono.length() == 10){
                if(telefono.charAt(0) != '0') return false;
            }
            return true;
        }
        return false;
    }

    public boolean NombreCallesCorrecto(String nombre){
        if(nombre.length() >= 3){
            return true;
        }else{
            return  false;
        }
    }

    public boolean CodigoCorrecto(String nombre){
        if(nombre.length() >= 3){
            return true;
        }else{
            return  false;
        }
    }

    public List<SociosGYM> getSocios() {
        return socios;
    }

    public void agregarSocio(SociosGYM socio) {
        this.socios.add(socio);
    }

    public boolean eliminarSocio(String cedula) {
        return socios.removeIf(socio -> socio.getCedula().equals(cedula));
    }



}
