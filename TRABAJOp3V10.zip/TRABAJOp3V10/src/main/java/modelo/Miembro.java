package modelo;

public class Miembro {
    private String Finicio;
    private String Ffin;

    public Miembro(String finicio, String ffin) {
        Finicio = finicio;
        Ffin = ffin;
    }

    public String getFinicio() {
        return Finicio;
    }

    public void setFinicio(String finicio) {
        Finicio = finicio;
    }

    public String getFfin() {
        return Ffin;
    }

    public void setFfin(String ffin) {
        Ffin = ffin;
    }
}
