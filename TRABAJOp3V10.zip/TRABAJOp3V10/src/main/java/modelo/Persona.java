package modelo;

import java.io.Serializable;

public class Persona implements Serializable {
    private String nombre;
    private String apellido;
    private String cedula;
    private String id;
    private String direccion;
    private String telefono;
    private String rol;

    public Persona(){}
    public Persona(String nombre, String apellido, String cedula,String id, String direccion, String telefono,String rol) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.id = id;
        this.direccion = direccion;
        this.telefono = telefono;
        this.rol = rol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean NombreCorrecto(String nombre){
        if(nombre.length() >= 3){
            return true;
        }else{
            return  false;
        }
    }

    public boolean ApellidoCorrecto(String nombre){
        if(nombre.length() > 3){
            return true;
        }else{
            return  false;
        }
    }
    public boolean CedulaCorrecta(String cedula){
        if(cedula.length() != 10) return false;

        int validador = 0;
        int[] mascara = {2, 1, 2, 1, 2, 1, 2, 1, 2};

        for(int i = 0; i < cedula.length() - 1; i++){
            if(mascara[i] * Integer.parseInt("" + cedula.charAt(i)) > 9){
                validador += (mascara[i] * Integer.parseInt("" + cedula.charAt(i))) - 9;
            }
            else{
                validador += mascara[i] * Integer.parseInt("" + cedula.charAt(i));
            }
        }
        if(validador % 10 == 0 && cedula.charAt(9) == '0') return true;
        validador = 10 - (validador % 10);
        if(validador == Integer.parseInt("" + cedula.charAt(9))) return  true;
        return false;
    }
    public boolean DireccionCorrecta(String direccion){
        if(direccion.length() >= 4){
            return true;
        }else{
            return false;
        }
    }

    public boolean TelefonoCorrecto(String telefono){
        if(telefono.length() == 7 || telefono.length() == 10){
            if(telefono.length() == 10){
                if(telefono.charAt(0) != '0') return false;
            }
            return true;
        }
        return false;
    }

}
