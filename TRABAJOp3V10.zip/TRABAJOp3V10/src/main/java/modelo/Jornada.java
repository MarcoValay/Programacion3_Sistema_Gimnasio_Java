package modelo;

public class Jornada {
    String nombre;
    String Hinicio;
    String Hfin;
}
